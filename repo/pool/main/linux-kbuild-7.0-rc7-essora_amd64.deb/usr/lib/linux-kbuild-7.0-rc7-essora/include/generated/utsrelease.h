#define UTS_RELEASE "7.0.0-rc7-essora"
