	.file	"devicetable-offsets.c"
# GNU C11 (Debian 14.2.0-19) version 14.2.0 (x86_64-linux-gnu)
#	compiled by GNU C version 14.2.0, GMP version 6.3.0, MPFR version 4.2.1, MPC version 1.3.1, isl version isl-0.27-GMP

# warning: MPFR header version 4.2.1 differs from library version 4.2.2.
# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -mno-sse4a -m64 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -O2 -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -fcf-protection=branch -falign-jumps=1 -falign-loops=1 -fno-asynchronous-unwind-tables -fno-jump-tables -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -fno-allow-store-data-races -fstack-protector-strong -fomit-frame-pointer -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fmin-function-alignment=16 -fstrict-flex-arrays=3 -fms-extensions -fno-strict-overflow -fstack-check=no -fconserve-stack -fno-builtin-wcslen
	.text
	.section	.text.startup,"ax",@progbits
	.align 16
	.globl	main
	.section	__patchable_function_entries,"awo",@progbits,.LPFE154
	.align 8
	.quad	.LPFE154
	.section	.text.startup
.LPFE154:
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	.type	main, @function
main:
	endbr64	
# scripts/mod/devicetable-offsets.c:12: 	DEVID(usb_device_id);
#APP
# 12 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_usb_device_id $32 sizeof(struct usb_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:13: 	DEVID_FIELD(usb_device_id, match_flags);
# 13 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_match_flags $0 offsetof(struct usb_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:14: 	DEVID_FIELD(usb_device_id, idVendor);
# 14 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_idVendor $2 offsetof(struct usb_device_id, idVendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:15: 	DEVID_FIELD(usb_device_id, idProduct);
# 15 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_idProduct $4 offsetof(struct usb_device_id, idProduct)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:16: 	DEVID_FIELD(usb_device_id, bcdDevice_lo);
# 16 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bcdDevice_lo $6 offsetof(struct usb_device_id, bcdDevice_lo)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:17: 	DEVID_FIELD(usb_device_id, bcdDevice_hi);
# 17 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bcdDevice_hi $8 offsetof(struct usb_device_id, bcdDevice_hi)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:18: 	DEVID_FIELD(usb_device_id, bDeviceClass);
# 18 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bDeviceClass $10 offsetof(struct usb_device_id, bDeviceClass)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:19: 	DEVID_FIELD(usb_device_id, bDeviceSubClass);
# 19 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bDeviceSubClass $11 offsetof(struct usb_device_id, bDeviceSubClass)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:20: 	DEVID_FIELD(usb_device_id, bDeviceProtocol);
# 20 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bDeviceProtocol $12 offsetof(struct usb_device_id, bDeviceProtocol)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:21: 	DEVID_FIELD(usb_device_id, bInterfaceClass);
# 21 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bInterfaceClass $13 offsetof(struct usb_device_id, bInterfaceClass)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:22: 	DEVID_FIELD(usb_device_id, bInterfaceSubClass);
# 22 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bInterfaceSubClass $14 offsetof(struct usb_device_id, bInterfaceSubClass)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:23: 	DEVID_FIELD(usb_device_id, bInterfaceProtocol);
# 23 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bInterfaceProtocol $15 offsetof(struct usb_device_id, bInterfaceProtocol)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:24: 	DEVID_FIELD(usb_device_id, bInterfaceNumber);
# 24 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_usb_device_id_bInterfaceNumber $16 offsetof(struct usb_device_id, bInterfaceNumber)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:26: 	DEVID(hid_device_id);
# 26 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_hid_device_id $24 sizeof(struct hid_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:27: 	DEVID_FIELD(hid_device_id, bus);
# 27 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hid_device_id_bus $0 offsetof(struct hid_device_id, bus)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:28: 	DEVID_FIELD(hid_device_id, group);
# 28 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hid_device_id_group $2 offsetof(struct hid_device_id, group)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:29: 	DEVID_FIELD(hid_device_id, vendor);
# 29 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hid_device_id_vendor $4 offsetof(struct hid_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:30: 	DEVID_FIELD(hid_device_id, product);
# 30 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hid_device_id_product $8 offsetof(struct hid_device_id, product)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:32: 	DEVID(ieee1394_device_id);
# 32 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ieee1394_device_id $32 sizeof(struct ieee1394_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:33: 	DEVID_FIELD(ieee1394_device_id, match_flags);
# 33 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ieee1394_device_id_match_flags $0 offsetof(struct ieee1394_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:34: 	DEVID_FIELD(ieee1394_device_id, vendor_id);
# 34 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ieee1394_device_id_vendor_id $4 offsetof(struct ieee1394_device_id, vendor_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:35: 	DEVID_FIELD(ieee1394_device_id, model_id);
# 35 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ieee1394_device_id_model_id $8 offsetof(struct ieee1394_device_id, model_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:36: 	DEVID_FIELD(ieee1394_device_id, specifier_id);
# 36 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ieee1394_device_id_specifier_id $12 offsetof(struct ieee1394_device_id, specifier_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:37: 	DEVID_FIELD(ieee1394_device_id, version);
# 37 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ieee1394_device_id_version $16 offsetof(struct ieee1394_device_id, version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:39: 	DEVID(pci_device_id);
# 39 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_pci_device_id $40 sizeof(struct pci_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:40: 	DEVID_FIELD(pci_device_id, vendor);
# 40 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_vendor $0 offsetof(struct pci_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:41: 	DEVID_FIELD(pci_device_id, device);
# 41 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_device $4 offsetof(struct pci_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:42: 	DEVID_FIELD(pci_device_id, subvendor);
# 42 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_subvendor $8 offsetof(struct pci_device_id, subvendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:43: 	DEVID_FIELD(pci_device_id, subdevice);
# 43 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_subdevice $12 offsetof(struct pci_device_id, subdevice)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:44: 	DEVID_FIELD(pci_device_id, class);
# 44 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_class $16 offsetof(struct pci_device_id, class)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:45: 	DEVID_FIELD(pci_device_id, class_mask);
# 45 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_class_mask $20 offsetof(struct pci_device_id, class_mask)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:46: 	DEVID_FIELD(pci_device_id, override_only);
# 46 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pci_device_id_override_only $32 offsetof(struct pci_device_id, override_only)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:48: 	DEVID(ccw_device_id);
# 48 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ccw_device_id $16 sizeof(struct ccw_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:49: 	DEVID_FIELD(ccw_device_id, match_flags);
# 49 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ccw_device_id_match_flags $0 offsetof(struct ccw_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:50: 	DEVID_FIELD(ccw_device_id, cu_type);
# 50 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ccw_device_id_cu_type $2 offsetof(struct ccw_device_id, cu_type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:51: 	DEVID_FIELD(ccw_device_id, cu_model);
# 51 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ccw_device_id_cu_model $6 offsetof(struct ccw_device_id, cu_model)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:52: 	DEVID_FIELD(ccw_device_id, dev_type);
# 52 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ccw_device_id_dev_type $4 offsetof(struct ccw_device_id, dev_type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:53: 	DEVID_FIELD(ccw_device_id, dev_model);
# 53 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ccw_device_id_dev_model $7 offsetof(struct ccw_device_id, dev_model)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:55: 	DEVID(ap_device_id);
# 55 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ap_device_id $16 sizeof(struct ap_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:56: 	DEVID_FIELD(ap_device_id, dev_type);
# 56 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ap_device_id_dev_type $2 offsetof(struct ap_device_id, dev_type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:58: 	DEVID(css_device_id);
# 58 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_css_device_id $16 sizeof(struct css_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:59: 	DEVID_FIELD(css_device_id, type);
# 59 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_css_device_id_type $1 offsetof(struct css_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:61: 	DEVID(serio_device_id);
# 61 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_serio_device_id $4 sizeof(struct serio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:62: 	DEVID_FIELD(serio_device_id, type);
# 62 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_serio_device_id_type $0 offsetof(struct serio_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:63: 	DEVID_FIELD(serio_device_id, proto);
# 63 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_serio_device_id_proto $3 offsetof(struct serio_device_id, proto)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:64: 	DEVID_FIELD(serio_device_id, id);
# 64 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_serio_device_id_id $2 offsetof(struct serio_device_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:65: 	DEVID_FIELD(serio_device_id, extra);
# 65 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_serio_device_id_extra $1 offsetof(struct serio_device_id, extra)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:67: 	DEVID(acpi_device_id);
# 67 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_acpi_device_id $32 sizeof(struct acpi_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:68: 	DEVID_FIELD(acpi_device_id, id);
# 68 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_acpi_device_id_id $0 offsetof(struct acpi_device_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:69: 	DEVID_FIELD(acpi_device_id, cls);
# 69 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_acpi_device_id_cls $24 offsetof(struct acpi_device_id, cls)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:70: 	DEVID_FIELD(acpi_device_id, cls_msk);
# 70 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_acpi_device_id_cls_msk $28 offsetof(struct acpi_device_id, cls_msk)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:72: 	DEVID(pnp_device_id);
# 72 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_pnp_device_id $16 sizeof(struct pnp_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:73: 	DEVID_FIELD(pnp_device_id, id);
# 73 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pnp_device_id_id $0 offsetof(struct pnp_device_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:75: 	DEVID(pnp_card_device_id);
# 75 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_pnp_card_device_id $80 sizeof(struct pnp_card_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:76: 	DEVID_FIELD(pnp_card_device_id, devs);
# 76 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pnp_card_device_id_devs $16 offsetof(struct pnp_card_device_id, devs)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:78: 	DEVID(pcmcia_device_id);
# 78 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_pcmcia_device_id $80 sizeof(struct pcmcia_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:79: 	DEVID_FIELD(pcmcia_device_id, match_flags);
# 79 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_match_flags $0 offsetof(struct pcmcia_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:80: 	DEVID_FIELD(pcmcia_device_id, manf_id);
# 80 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_manf_id $2 offsetof(struct pcmcia_device_id, manf_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:81: 	DEVID_FIELD(pcmcia_device_id, card_id);
# 81 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_card_id $4 offsetof(struct pcmcia_device_id, card_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:82: 	DEVID_FIELD(pcmcia_device_id, func_id);
# 82 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_func_id $6 offsetof(struct pcmcia_device_id, func_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:83: 	DEVID_FIELD(pcmcia_device_id, function);
# 83 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_function $7 offsetof(struct pcmcia_device_id, function)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:84: 	DEVID_FIELD(pcmcia_device_id, device_no);
# 84 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_device_no $8 offsetof(struct pcmcia_device_id, device_no)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:85: 	DEVID_FIELD(pcmcia_device_id, prod_id_hash);
# 85 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_pcmcia_device_id_prod_id_hash $12 offsetof(struct pcmcia_device_id, prod_id_hash)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:87: 	DEVID(of_device_id);
# 87 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_of_device_id $200 sizeof(struct of_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:88: 	DEVID_FIELD(of_device_id, name);
# 88 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_of_device_id_name $0 offsetof(struct of_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:89: 	DEVID_FIELD(of_device_id, type);
# 89 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_of_device_id_type $32 offsetof(struct of_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:90: 	DEVID_FIELD(of_device_id, compatible);
# 90 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_of_device_id_compatible $64 offsetof(struct of_device_id, compatible)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:92: 	DEVID(vio_device_id);
# 92 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_vio_device_id $64 sizeof(struct vio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:93: 	DEVID_FIELD(vio_device_id, type);
# 93 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_vio_device_id_type $0 offsetof(struct vio_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:94: 	DEVID_FIELD(vio_device_id, compat);
# 94 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_vio_device_id_compat $32 offsetof(struct vio_device_id, compat)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:96: 	DEVID(input_device_id);
# 96 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_input_device_id $200 sizeof(struct input_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:97: 	DEVID_FIELD(input_device_id, flags);
# 97 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_flags $0 offsetof(struct input_device_id, flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:98: 	DEVID_FIELD(input_device_id, bustype);
# 98 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_bustype $8 offsetof(struct input_device_id, bustype)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:99: 	DEVID_FIELD(input_device_id, vendor);
# 99 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_vendor $10 offsetof(struct input_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:100: 	DEVID_FIELD(input_device_id, product);
# 100 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_product $12 offsetof(struct input_device_id, product)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:101: 	DEVID_FIELD(input_device_id, version);
# 101 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_version $14 offsetof(struct input_device_id, version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:102: 	DEVID_FIELD(input_device_id, evbit);
# 102 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_evbit $16 offsetof(struct input_device_id, evbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:103: 	DEVID_FIELD(input_device_id, keybit);
# 103 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_keybit $24 offsetof(struct input_device_id, keybit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:104: 	DEVID_FIELD(input_device_id, relbit);
# 104 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_relbit $120 offsetof(struct input_device_id, relbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:105: 	DEVID_FIELD(input_device_id, absbit);
# 105 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_absbit $128 offsetof(struct input_device_id, absbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:106: 	DEVID_FIELD(input_device_id, mscbit);
# 106 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_mscbit $136 offsetof(struct input_device_id, mscbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:107: 	DEVID_FIELD(input_device_id, ledbit);
# 107 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_ledbit $144 offsetof(struct input_device_id, ledbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:108: 	DEVID_FIELD(input_device_id, sndbit);
# 108 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_sndbit $152 offsetof(struct input_device_id, sndbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:109: 	DEVID_FIELD(input_device_id, ffbit);
# 109 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_ffbit $160 offsetof(struct input_device_id, ffbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:110: 	DEVID_FIELD(input_device_id, swbit);
# 110 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_input_device_id_swbit $176 offsetof(struct input_device_id, swbit)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:112: 	DEVID(eisa_device_id);
# 112 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_eisa_device_id $16 sizeof(struct eisa_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:113: 	DEVID_FIELD(eisa_device_id, sig);
# 113 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_eisa_device_id_sig $0 offsetof(struct eisa_device_id, sig)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:115: 	DEVID(parisc_device_id);
# 115 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_parisc_device_id $8 sizeof(struct parisc_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:116: 	DEVID_FIELD(parisc_device_id, hw_type);
# 116 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_parisc_device_id_hw_type $0 offsetof(struct parisc_device_id, hw_type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:117: 	DEVID_FIELD(parisc_device_id, hversion);
# 117 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_parisc_device_id_hversion $2 offsetof(struct parisc_device_id, hversion)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:118: 	DEVID_FIELD(parisc_device_id, hversion_rev);
# 118 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_parisc_device_id_hversion_rev $1 offsetof(struct parisc_device_id, hversion_rev)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:119: 	DEVID_FIELD(parisc_device_id, sversion);
# 119 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_parisc_device_id_sversion $4 offsetof(struct parisc_device_id, sversion)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:121: 	DEVID(sdio_device_id);
# 121 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_sdio_device_id $16 sizeof(struct sdio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:122: 	DEVID_FIELD(sdio_device_id, class);
# 122 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdio_device_id_class $0 offsetof(struct sdio_device_id, class)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:123: 	DEVID_FIELD(sdio_device_id, vendor);
# 123 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdio_device_id_vendor $2 offsetof(struct sdio_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:124: 	DEVID_FIELD(sdio_device_id, device);
# 124 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdio_device_id_device $4 offsetof(struct sdio_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:126: 	DEVID(ssb_device_id);
# 126 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ssb_device_id $6 sizeof(struct ssb_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:127: 	DEVID_FIELD(ssb_device_id, vendor);
# 127 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssb_device_id_vendor $0 offsetof(struct ssb_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:128: 	DEVID_FIELD(ssb_device_id, coreid);
# 128 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssb_device_id_coreid $2 offsetof(struct ssb_device_id, coreid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:129: 	DEVID_FIELD(ssb_device_id, revision);
# 129 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssb_device_id_revision $4 offsetof(struct ssb_device_id, revision)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:131: 	DEVID(bcma_device_id);
# 131 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_bcma_device_id $6 sizeof(struct bcma_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:132: 	DEVID_FIELD(bcma_device_id, manuf);
# 132 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_bcma_device_id_manuf $0 offsetof(struct bcma_device_id, manuf)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:133: 	DEVID_FIELD(bcma_device_id, id);
# 133 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_bcma_device_id_id $2 offsetof(struct bcma_device_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:134: 	DEVID_FIELD(bcma_device_id, rev);
# 134 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_bcma_device_id_rev $4 offsetof(struct bcma_device_id, rev)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:135: 	DEVID_FIELD(bcma_device_id, class);
# 135 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_bcma_device_id_class $5 offsetof(struct bcma_device_id, class)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:137: 	DEVID(virtio_device_id);
# 137 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_virtio_device_id $8 sizeof(struct virtio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:138: 	DEVID_FIELD(virtio_device_id, device);
# 138 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_virtio_device_id_device $0 offsetof(struct virtio_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:139: 	DEVID_FIELD(virtio_device_id, vendor);
# 139 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_virtio_device_id_vendor $4 offsetof(struct virtio_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:141: 	DEVID(hv_vmbus_device_id);
# 141 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_hv_vmbus_device_id $24 sizeof(struct hv_vmbus_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:142: 	DEVID_FIELD(hv_vmbus_device_id, guid);
# 142 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hv_vmbus_device_id_guid $0 offsetof(struct hv_vmbus_device_id, guid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:144: 	DEVID(rpmsg_device_id);
# 144 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_rpmsg_device_id $40 sizeof(struct rpmsg_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:145: 	DEVID_FIELD(rpmsg_device_id, name);
# 145 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_rpmsg_device_id_name $0 offsetof(struct rpmsg_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:147: 	DEVID(i2c_device_id);
# 147 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_i2c_device_id $32 sizeof(struct i2c_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:148: 	DEVID_FIELD(i2c_device_id, name);
# 148 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i2c_device_id_name $0 offsetof(struct i2c_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:150: 	DEVID(i3c_device_id);
# 150 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_i3c_device_id $16 sizeof(struct i3c_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:151: 	DEVID_FIELD(i3c_device_id, match_flags);
# 151 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i3c_device_id_match_flags $0 offsetof(struct i3c_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:152: 	DEVID_FIELD(i3c_device_id, dcr);
# 152 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i3c_device_id_dcr $1 offsetof(struct i3c_device_id, dcr)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:153: 	DEVID_FIELD(i3c_device_id, manuf_id);
# 153 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i3c_device_id_manuf_id $2 offsetof(struct i3c_device_id, manuf_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:154: 	DEVID_FIELD(i3c_device_id, part_id);
# 154 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i3c_device_id_part_id $4 offsetof(struct i3c_device_id, part_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:155: 	DEVID_FIELD(i3c_device_id, extra_info);
# 155 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_i3c_device_id_extra_info $6 offsetof(struct i3c_device_id, extra_info)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:157: 	DEVID(slim_device_id);
# 157 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_slim_device_id $16 sizeof(struct slim_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:158: 	DEVID_FIELD(slim_device_id, manf_id);
# 158 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_slim_device_id_manf_id $0 offsetof(struct slim_device_id, manf_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:159: 	DEVID_FIELD(slim_device_id, prod_code);
# 159 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_slim_device_id_prod_code $2 offsetof(struct slim_device_id, prod_code)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:161: 	DEVID(spi_device_id);
# 161 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_spi_device_id $40 sizeof(struct spi_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:162: 	DEVID_FIELD(spi_device_id, name);
# 162 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_spi_device_id_name $0 offsetof(struct spi_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:164: 	DEVID(dmi_system_id);
# 164 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_dmi_system_id $344 sizeof(struct dmi_system_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:165: 	DEVID_FIELD(dmi_system_id, matches);
# 165 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_dmi_system_id_matches $16 offsetof(struct dmi_system_id, matches)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:167: 	DEVID(platform_device_id);
# 167 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_platform_device_id $32 sizeof(struct platform_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:168: 	DEVID_FIELD(platform_device_id, name);
# 168 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_platform_device_id_name $0 offsetof(struct platform_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:170: 	DEVID(mdio_device_id);
# 170 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_mdio_device_id $8 sizeof(struct mdio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:171: 	DEVID_FIELD(mdio_device_id, phy_id);
# 171 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mdio_device_id_phy_id $0 offsetof(struct mdio_device_id, phy_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:172: 	DEVID_FIELD(mdio_device_id, phy_id_mask);
# 172 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mdio_device_id_phy_id_mask $4 offsetof(struct mdio_device_id, phy_id_mask)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:174: 	DEVID(zorro_device_id);
# 174 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_zorro_device_id $16 sizeof(struct zorro_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:175: 	DEVID_FIELD(zorro_device_id, id);
# 175 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_zorro_device_id_id $0 offsetof(struct zorro_device_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:177: 	DEVID(isapnp_device_id);
# 177 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_isapnp_device_id $16 sizeof(struct isapnp_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:178: 	DEVID_FIELD(isapnp_device_id, vendor);
# 178 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_isapnp_device_id_vendor $4 offsetof(struct isapnp_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:179: 	DEVID_FIELD(isapnp_device_id, function);
# 179 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_isapnp_device_id_function $6 offsetof(struct isapnp_device_id, function)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:181: 	DEVID(ipack_device_id);
# 181 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ipack_device_id $12 sizeof(struct ipack_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:182: 	DEVID_FIELD(ipack_device_id, format);
# 182 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ipack_device_id_format $0 offsetof(struct ipack_device_id, format)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:183: 	DEVID_FIELD(ipack_device_id, vendor);
# 183 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ipack_device_id_vendor $4 offsetof(struct ipack_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:184: 	DEVID_FIELD(ipack_device_id, device);
# 184 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ipack_device_id_device $8 offsetof(struct ipack_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:186: 	DEVID(amba_id);
# 186 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_amba_id $16 sizeof(struct amba_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:187: 	DEVID_FIELD(amba_id, id);
# 187 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_amba_id_id $0 offsetof(struct amba_id, id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:188: 	DEVID_FIELD(amba_id, mask);
# 188 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_amba_id_mask $4 offsetof(struct amba_id, mask)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:190: 	DEVID(mips_cdmm_device_id);
# 190 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_mips_cdmm_device_id $1 sizeof(struct mips_cdmm_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:191: 	DEVID_FIELD(mips_cdmm_device_id, type);
# 191 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mips_cdmm_device_id_type $0 offsetof(struct mips_cdmm_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:193: 	DEVID(x86_cpu_id);
# 193 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_x86_cpu_id $24 sizeof(struct x86_cpu_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:194: 	DEVID_FIELD(x86_cpu_id, feature);
# 194 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_x86_cpu_id_feature $8 offsetof(struct x86_cpu_id, feature)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:195: 	DEVID_FIELD(x86_cpu_id, family);
# 195 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_x86_cpu_id_family $2 offsetof(struct x86_cpu_id, family)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:196: 	DEVID_FIELD(x86_cpu_id, model);
# 196 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_x86_cpu_id_model $4 offsetof(struct x86_cpu_id, model)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:197: 	DEVID_FIELD(x86_cpu_id, vendor);
# 197 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_x86_cpu_id_vendor $0 offsetof(struct x86_cpu_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:199: 	DEVID(cpu_feature);
# 199 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_cpu_feature $2 sizeof(struct cpu_feature)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:200: 	DEVID_FIELD(cpu_feature, feature);
# 200 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cpu_feature_feature $0 offsetof(struct cpu_feature, feature)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:202: 	DEVID(mcb_device_id);
# 202 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_mcb_device_id $16 sizeof(struct mcb_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:203: 	DEVID_FIELD(mcb_device_id, device);
# 203 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mcb_device_id_device $0 offsetof(struct mcb_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:205: 	DEVID(mei_cl_device_id);
# 205 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_mei_cl_device_id $64 sizeof(struct mei_cl_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:206: 	DEVID_FIELD(mei_cl_device_id, name);
# 206 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mei_cl_device_id_name $0 offsetof(struct mei_cl_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:207: 	DEVID_FIELD(mei_cl_device_id, uuid);
# 207 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mei_cl_device_id_uuid $32 offsetof(struct mei_cl_device_id, uuid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:208: 	DEVID_FIELD(mei_cl_device_id, version);
# 208 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mei_cl_device_id_version $48 offsetof(struct mei_cl_device_id, version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:210: 	DEVID(rio_device_id);
# 210 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_rio_device_id $8 sizeof(struct rio_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:211: 	DEVID_FIELD(rio_device_id, did);
# 211 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_rio_device_id_did $0 offsetof(struct rio_device_id, did)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:212: 	DEVID_FIELD(rio_device_id, vid);
# 212 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_rio_device_id_vid $2 offsetof(struct rio_device_id, vid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:213: 	DEVID_FIELD(rio_device_id, asm_did);
# 213 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_rio_device_id_asm_did $4 offsetof(struct rio_device_id, asm_did)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:214: 	DEVID_FIELD(rio_device_id, asm_vid);
# 214 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_rio_device_id_asm_vid $6 offsetof(struct rio_device_id, asm_vid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:216: 	DEVID(ulpi_device_id);
# 216 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ulpi_device_id $16 sizeof(struct ulpi_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:217: 	DEVID_FIELD(ulpi_device_id, vendor);
# 217 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ulpi_device_id_vendor $0 offsetof(struct ulpi_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:218: 	DEVID_FIELD(ulpi_device_id, product);
# 218 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ulpi_device_id_product $2 offsetof(struct ulpi_device_id, product)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:220: 	DEVID(hda_device_id);
# 220 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_hda_device_id $32 sizeof(struct hda_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:221: 	DEVID_FIELD(hda_device_id, vendor_id);
# 221 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hda_device_id_vendor_id $0 offsetof(struct hda_device_id, vendor_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:222: 	DEVID_FIELD(hda_device_id, rev_id);
# 222 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hda_device_id_rev_id $4 offsetof(struct hda_device_id, rev_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:223: 	DEVID_FIELD(hda_device_id, api_version);
# 223 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_hda_device_id_api_version $8 offsetof(struct hda_device_id, api_version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:225: 	DEVID(sdw_device_id);
# 225 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_sdw_device_id $16 sizeof(struct sdw_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:226: 	DEVID_FIELD(sdw_device_id, mfg_id);
# 226 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdw_device_id_mfg_id $0 offsetof(struct sdw_device_id, mfg_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:227: 	DEVID_FIELD(sdw_device_id, part_id);
# 227 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdw_device_id_part_id $2 offsetof(struct sdw_device_id, part_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:228: 	DEVID_FIELD(sdw_device_id, sdw_version);
# 228 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdw_device_id_sdw_version $4 offsetof(struct sdw_device_id, sdw_version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:229: 	DEVID_FIELD(sdw_device_id, class_id);
# 229 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_sdw_device_id_class_id $5 offsetof(struct sdw_device_id, class_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:231: 	DEVID(fsl_mc_device_id);
# 231 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_fsl_mc_device_id $18 sizeof(struct fsl_mc_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:232: 	DEVID_FIELD(fsl_mc_device_id, vendor);
# 232 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_fsl_mc_device_id_vendor $0 offsetof(struct fsl_mc_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:233: 	DEVID_FIELD(fsl_mc_device_id, obj_type);
# 233 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_fsl_mc_device_id_obj_type $2 offsetof(struct fsl_mc_device_id, obj_type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:235: 	DEVID(tb_service_id);
# 235 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_tb_service_id $40 sizeof(struct tb_service_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:236: 	DEVID_FIELD(tb_service_id, match_flags);
# 236 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tb_service_id_match_flags $0 offsetof(struct tb_service_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:237: 	DEVID_FIELD(tb_service_id, protocol_key);
# 237 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tb_service_id_protocol_key $4 offsetof(struct tb_service_id, protocol_key)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:238: 	DEVID_FIELD(tb_service_id, protocol_id);
# 238 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tb_service_id_protocol_id $16 offsetof(struct tb_service_id, protocol_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:239: 	DEVID_FIELD(tb_service_id, protocol_version);
# 239 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tb_service_id_protocol_version $20 offsetof(struct tb_service_id, protocol_version)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:240: 	DEVID_FIELD(tb_service_id, protocol_revision);
# 240 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tb_service_id_protocol_revision $24 offsetof(struct tb_service_id, protocol_revision)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:242: 	DEVID(typec_device_id);
# 242 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_typec_device_id $16 sizeof(struct typec_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:243: 	DEVID_FIELD(typec_device_id, svid);
# 243 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_typec_device_id_svid $0 offsetof(struct typec_device_id, svid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:245: 	DEVID(tee_client_device_id);
# 245 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_tee_client_device_id $16 sizeof(struct tee_client_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:246: 	DEVID_FIELD(tee_client_device_id, uuid);
# 246 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_tee_client_device_id_uuid $0 offsetof(struct tee_client_device_id, uuid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:248: 	DEVID(wmi_device_id);
# 248 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_wmi_device_id $48 sizeof(struct wmi_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:249: 	DEVID_FIELD(wmi_device_id, guid_string);
# 249 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_wmi_device_id_guid_string $0 offsetof(struct wmi_device_id, guid_string)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:251: 	DEVID(mhi_device_id);
# 251 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_mhi_device_id $40 sizeof(struct mhi_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:252: 	DEVID_FIELD(mhi_device_id, chan);
# 252 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_mhi_device_id_chan $0 offsetof(struct mhi_device_id, chan)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:254: 	DEVID(auxiliary_device_id);
# 254 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_auxiliary_device_id $48 sizeof(struct auxiliary_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:255: 	DEVID_FIELD(auxiliary_device_id, name);
# 255 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_auxiliary_device_id_name $0 offsetof(struct auxiliary_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:257: 	DEVID(ssam_device_id);
# 257 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ssam_device_id $16 sizeof(struct ssam_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:258: 	DEVID_FIELD(ssam_device_id, match_flags);
# 258 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_match_flags $0 offsetof(struct ssam_device_id, match_flags)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:259: 	DEVID_FIELD(ssam_device_id, domain);
# 259 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_domain $1 offsetof(struct ssam_device_id, domain)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:260: 	DEVID_FIELD(ssam_device_id, category);
# 260 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_category $2 offsetof(struct ssam_device_id, category)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:261: 	DEVID_FIELD(ssam_device_id, target);
# 261 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_target $3 offsetof(struct ssam_device_id, target)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:262: 	DEVID_FIELD(ssam_device_id, instance);
# 262 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_instance $4 offsetof(struct ssam_device_id, instance)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:263: 	DEVID_FIELD(ssam_device_id, function);
# 263 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ssam_device_id_function $5 offsetof(struct ssam_device_id, function)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:265: 	DEVID(dfl_device_id);
# 265 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_dfl_device_id $16 sizeof(struct dfl_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:266: 	DEVID_FIELD(dfl_device_id, type);
# 266 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_dfl_device_id_type $0 offsetof(struct dfl_device_id, type)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:267: 	DEVID_FIELD(dfl_device_id, feature_id);
# 267 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_dfl_device_id_feature_id $2 offsetof(struct dfl_device_id, feature_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:269: 	DEVID(ishtp_device_id);
# 269 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_ishtp_device_id $24 sizeof(struct ishtp_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:270: 	DEVID_FIELD(ishtp_device_id, guid);
# 270 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_ishtp_device_id_guid $0 offsetof(struct ishtp_device_id, guid)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:272: 	DEVID(cdx_device_id);
# 272 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_cdx_device_id $20 sizeof(struct cdx_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:273: 	DEVID_FIELD(cdx_device_id, vendor);
# 273 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_vendor $0 offsetof(struct cdx_device_id, vendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:274: 	DEVID_FIELD(cdx_device_id, device);
# 274 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_device $2 offsetof(struct cdx_device_id, device)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:275: 	DEVID_FIELD(cdx_device_id, subvendor);
# 275 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_subvendor $4 offsetof(struct cdx_device_id, subvendor)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:276: 	DEVID_FIELD(cdx_device_id, subdevice);
# 276 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_subdevice $6 offsetof(struct cdx_device_id, subdevice)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:277: 	DEVID_FIELD(cdx_device_id, class);
# 277 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_class $8 offsetof(struct cdx_device_id, class)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:278: 	DEVID_FIELD(cdx_device_id, class_mask);
# 278 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_class_mask $12 offsetof(struct cdx_device_id, class_mask)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:279: 	DEVID_FIELD(cdx_device_id, override_only);
# 279 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_cdx_device_id_override_only $16 offsetof(struct cdx_device_id, override_only)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:281: 	DEVID(vchiq_device_id);
# 281 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_vchiq_device_id $32 sizeof(struct vchiq_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:282: 	DEVID_FIELD(vchiq_device_id, name);
# 282 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_vchiq_device_id_name $0 offsetof(struct vchiq_device_id, name)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:284: 	DEVID(coreboot_device_id);
# 284 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->SIZE_coreboot_device_id $16 sizeof(struct coreboot_device_id)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:285: 	DEVID_FIELD(coreboot_device_id, tag);
# 285 "scripts/mod/devicetable-offsets.c" 1
	
.ascii "->OFF_coreboot_device_id_tag $0 offsetof(struct coreboot_device_id, tag)"	#
# 0 "" 2
# scripts/mod/devicetable-offsets.c:288: }
#NO_APP
	xorl	%eax, %eax	#
	jmp	__x86_return_thunk
	.size	main, .-main
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x1
3:
	.align 8
4:
