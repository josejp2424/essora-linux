#!/usr/bin/env bash
# Essora zramswap-AI (para zram-tools) - Devuan/OpenRC/SysV
# Autor: josejp2424 <puppylinuxjosejp2424@gmail.com>
# Licencia: GPL-2+
#
# Detecta hardware y aplica una politica conservadora de zram swap.
# Pensado para uso publico en la ISO de Essora.

set -euo pipefail

LOG_TAG="zram-ai"
DEFAULTS_FILE="/etc/default/zram-ai"


log() {
  if command -v logger >/dev/null 2>&1; then
    logger -t "$LOG_TAG" "$*"
  fi
  echo "[zram-ai] $*"
}


ram_mib() { awk '/MemTotal:/ {print int($2/1024)}' /proc/meminfo; }

cpu_cores() { nproc --all 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1; }

is_live_session() {

  if grep -qE '^(overlay|aufs|tmpfs) +/ +' /proc/mounts 2>/dev/null; then
    return 0
  fi
  [ -f /etc/live/config.conf ] && return 0
  [ -d /run/live ] && return 0
  return 1
}

load_user_overrides() {
  if [ -r "$DEFAULTS_FILE" ]; then

    . "$DEFAULTS_FILE" || true
  fi
}


decide_policy() {
  local mib="$1" cores="$2" algo pct
  if   (( mib <= 1024 )); then algo=lz4;  pct=50
  elif (( mib <= 2048 )); then algo=lz4;  pct=50
  elif (( mib <= 4096 )); then algo=zstd; pct=50
  elif (( mib <= 8192 )); then algo=zstd; pct=40
  elif (( mib <= 16384 )); then algo=lz4; pct=25
  else                          algo=lz4; pct=20
  fi

  if (( cores <= 2 )); then
    algo=lz4
  fi
  echo "$algo" "$pct"
}

decide_swappiness() {
  local mib="$1" swapn
  if   (( mib <= 2048 )); then swapn=150
  elif (( mib <= 4096 )); then swapn=130
  elif (( mib <= 8192 )); then swapn=100
  else                         swapn=80
  fi
  echo "$swapn"
}

write_zramswap_default() {
  local algo="$1" pct="$2" mib="$3" cores="$4" priority=100
  install -d -m 0755 /etc/default
  cat > /etc/default/zramswap <<EOF
# Autogenerado por zram-ai (Essora) - $(date '+%Y-%m-%d %H:%M:%S')
# No editar a mano: regenerar via /usr/lib/zram-ai/autoconfig.sh
# Para overrides persistentes usar /etc/default/zram-ai
#
# ALGO:     algoritmo de compresion (lz4 = rapido, zstd = mejor compresion)
# PERCENT:  % de RAM a reservar para zram (sobreescribe SIZE)
# PRIORITY: prioridad de swap (mayor = el kernel lo usa primero)
ALGO=${algo}
PERCENT=${pct}
PRIORITY=${priority}
# zram-ai-stamp: ${mib}MiB-${cores}cores
EOF
  log "escrito /etc/default/zramswap (ALGO=${algo}, PERCENT=${pct}, PRIORITY=${priority})"
}

write_sysctl() {
  local mib="$1" swapn
  swapn=$(decide_swappiness "$mib")
  install -d -m 0755 /etc/sysctl.d
  cat > /etc/sysctl.d/99-zram-ai.conf <<EOF
# Autogenerado por zram-ai (Essora)
# Tuning de memoria para sistemas con zram swap
vm.swappiness=${swapn}
vm.vfs_cache_pressure=100
vm.page-cluster=0
vm.watermark_boost_factor=0
vm.watermark_scale_factor=125
EOF
  log "escrito /etc/sysctl.d/99-zram-ai.conf (vm.swappiness=${swapn})"
}

cleanup_baks() {
  rm -f /etc/default/zramswap.bak \
        /etc/default/zramswap.dpkg-bak \
        /etc/default/zramswap.dpkg-old \
        /etc/sysctl.d/99-zram-ai.conf.bak 2>/dev/null || true
}

main() {
  load_user_overrides

  if [ "${DISABLE:-0}" = "1" ]; then
    log "DISABLE=1 en $DEFAULTS_FILE, no se hace nada"
    exit 0
  fi

  if is_live_session; then
    log "sesion live detectada (configuracion igual aplicada)"
  fi


  if ! command -v zramswap >/dev/null 2>&1; then
    log "binario 'zramswap' no encontrado (instalar zram-tools), abortando"
    exit 0
  fi

  local mib cores algo pct
  mib=$(ram_mib)
  cores=$(cpu_cores)


  if (( mib < 256 )) || (( mib > 524288 )); then
    log "RAM detectada fuera de rango razonable (${mib} MiB), abortando"
    exit 0
  fi

  read -r algo pct < <(decide_policy "$mib" "$cores")


  if [ -n "${FORCE_ALGO:-}" ]; then
    algo="$FORCE_ALGO"
    log "override: FORCE_ALGO=${algo}"
  fi
  if [ -n "${FORCE_PERCENT:-}" ]; then
    pct="$FORCE_PERCENT"
    log "override: FORCE_PERCENT=${pct}"
  fi

  log "RAM=${mib}MiB cores=${cores} -> algo=${algo} percent=${pct}"


  if [ -f /etc/default/zramswap ] && [ -z "${FORCE_REGENERATE:-}" ]; then
    expected_stamp="# zram-ai-stamp: ${mib}MiB-${cores}cores"
    if grep -qF "$expected_stamp" /etc/default/zramswap 2>/dev/null \
       && grep -qE "^ALGO=${algo}$" /etc/default/zramswap 2>/dev/null \
       && grep -qE "^PERCENT=${pct}$" /etc/default/zramswap 2>/dev/null; then
      log "config ya esta al dia para este HW, nada que hacer"
      exit 0
    fi
  fi

  write_zramswap_default "$algo" "$pct" "$mib" "$cores"
  write_sysctl "$mib"
  cleanup_baks

  log "configuracion aplicada correctamente"
}

main "$@"
