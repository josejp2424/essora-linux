#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
APP="/usr/local/riseupvpn"
source "$APP/i18n.sh"
load_locale
BASE="/root/.riseupvpn"
CAT="$BASE/remotes.catalog"
OUT="$BASE/remotes.selected"

if ! command -v yad >/dev/null 2>&1; then
  echo "yad no instalado, omitiendo selector" >&2
  exit 0
fi

if [[ ! -s "$CAT" ]]; then
  echo "No hay catalogo de remotos ($CAT)."
  exit 0
fi

rows=()
while IFS=',' read -r cc country city host; do
  [[ -z "$host" || "$host" == "host" ]] && continue
  rows+=("FALSE" "$country" "$city" "$host")
done < "$CAT"

# Mostrar selector
SEL=$(yad --width=720 --height=420 --center --title="$T_TITLE_SEL" --window-icon="/usr/local/riseupvpn/essora-vpn.svg" --image="/usr/local/riseupvpn/essora-vpn.svg" --list --radiolist --column="$T_COL_USE":CHK --column="$T_COL_COUNTRY" --column="$T_COL_CITY" --column="$T_COL_HOST" --print-column=4 --separator="\n" --text="$T_SEL_TEXT"   "${rows[@]}" ) || exit 1


country=$(awk -F',' -v h="$SEL" '$4==h {print $2}' "$CAT" | head -n1)
if [[ -n "$country" ]]; then
  {

    echo "$SEL"

    awk -F',' -v c="$country" -v h="$SEL" 'NR>1 && $2==c && $4!=h {print $4}' "$CAT"
  } | sed '/^$/d' | awk '!seen[$0]++' > "$OUT"
else
  echo "$SEL" > "$OUT"
fi

exit 0
