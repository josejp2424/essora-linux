#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
APP="/usr/local/riseupvpn"
source "$APP/i18n.sh"
load_locale
IP=$(curl -s ifconfig.me || echo "N/A")
yad --center --window-icon="/usr/local/riseupvpn/essora-vpn.svg" --icon="/usr/local/riseupvpn/essora-vpn.svg" --image="/usr/local/riseupvpn/essora-vpn.svg" --title="$T_TITLE_IP" --text="$T_IP_PREFIX <b>$IP</b>" --button="$T_BTN_CLOSE:0"
