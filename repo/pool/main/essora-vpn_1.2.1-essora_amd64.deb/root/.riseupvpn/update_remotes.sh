#!/usr/bin/env bash
# Actualiza la lista oficial de gateways RiseupVPN (EIP) y mantiene el catálogo local.
set -euo pipefail

APP="/usr/local/riseupvpn"
BASE="/root/.riseupvpn"
LOG_UPD="/tmp/riseupvpn.update-remotes.log"

# i18n
source "$APP/i18n.sh"
load_locale

# Forzar un entorno UTF-8 cuando sea posible (evita caracteres raros en YAD/logs)
if command -v locale >/dev/null 2>&1; then
  pick_utf8() {
    local c
    for c in "C.UTF-8" "C.utf8" "en_US.UTF-8" "en_US.utf8" "es_AR.UTF-8" "es_AR.utf8"; do
      if locale -a 2>/dev/null | grep -qi "^${c}$"; then
        echo "$c"; return 0
      fi
    done
    echo "C"
  }
  : "${LC_ALL:=$(pick_utf8)}"
  : "${LANG:=$LC_ALL}"
  export LC_ALL LANG
fi

mkdir -p "$BASE" 2>/dev/null || true

# Si no hay YAD, ejecutar en modo consola
if ! command -v yad >/dev/null 2>&1; then
  "$APP/update-remotes-official.sh" "$BASE" | tee "$LOG_UPD"
  exit ${PIPESTATUS[0]}
fi

# Ventana de progreso (pulsante)
FIFO="$(mktemp -u)"
mkfifo "$FIFO"

yad --progress --pulsate --auto-close --no-cancel --center \
  --title="$T_TITLE_UPDATE" \
  --text="$T_UPDATE_TEXT" \
  --image="$APP/essora-vpn.svg" \
  --window-icon="/usr/local/riseupvpn/essora-vpn.svg" \
  --width=420 --height=120 < "$FIFO" &
YADPID=$!

set +e
"$APP/update-remotes-official.sh" "$BASE" >"$LOG_UPD" 2>&1
RC=$?
set -e

# Cerrar progreso
{ echo "100" > "$FIFO"; } 2>/dev/null || true
sleep 0.2
rm -f "$FIFO" 2>/dev/null || true
wait "$YADPID" 2>/dev/null || true

if [ "$RC" -eq 0 ]; then
  yad --center --title="$T_TITLE_UPDATE" --window-icon="/usr/local/riseupvpn/essora-vpn.svg" --image="$APP/vpn.png" \
      --text="$T_UPDATE_OK" \
      --button="$T_BTN_RECONNECT:0" --button="$T_BTN_CLOSE:1"
  if [ "$?" -eq 0 ]; then
    exec "$BASE/reconnect.sh"
  fi
  exit 0
else
  yad --center --title="$T_TITLE_UPDATE" --window-icon="/usr/local/riseupvpn/essora-vpn.svg" --image="$APP/vpn.png" \
      --text="$T_UPDATE_FAIL" \
      --button="$T_MENU_SHOW_LOG:0" --button="$T_BTN_CLOSE:1"
  if [ "$?" -eq 0 ]; then
    yad --width=780 --height=460 --center --window-icon="/usr/local/riseupvpn/essora-vpn.svg" --title="$T_TITLE_UPDATE" \
        --text-info --filename="$LOG_UPD" --button="$T_BTN_CLOSE:0" || true
  fi
  exit 1
fi
