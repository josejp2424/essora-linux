#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
BASE="/root/.riseupvpn"
OVPN="$BASE/riseup_configuration.ovpn"
PID_OVPN="$BASE/openvpn.pid"
PID_YAD="$BASE/yad.pid"
PID_APP="$BASE/app.pid"
PID_PGID="$BASE/app.pgid"

# Kill OpenVPN by PID if present
if [[ -f "$PID_OVPN" ]]; then
  OVPN_PID=$(cat "$PID_OVPN" 2>/dev/null || echo "")
  if [[ -n "$OVPN_PID" ]] && kill -0 "$OVPN_PID" 2>/dev/null; then
    kill "$OVPN_PID" || true
    sleep 1
    kill -9 "$OVPN_PID" 2>/dev/null || true
  fi
  rm -f "$PID_OVPN"
fi

# Asegurar que el proceso principal (el que abrió gksu/pkexec) se termine,
# para que NO vuelva a aparecer el selector de país.
if [[ -f "$PID_APP" ]]; then
  APP_PID=$(cat "$PID_APP" 2>/dev/null || echo "")
  if [[ -n "$APP_PID" ]] && kill -0 "$APP_PID" 2>/dev/null; then
    kill "$APP_PID" 2>/dev/null || true
    sleep 1
    kill -9 "$APP_PID" 2>/dev/null || true
  fi
  rm -f "$PID_APP" 2>/dev/null || true
fi

# Matar el grupo de procesos completo (app + bash + gksu + openvpn + yad) para evitar relanzos.
# Se hace en background para que este script pueda terminar.
if [[ -f "$PID_PGID" ]]; then
  PGID=$(cat "$PID_PGID" 2>/dev/null || echo "")
  if [[ -n "$PGID" ]]; then
    ( sleep 0.3; kill -TERM -"$PGID" 2>/dev/null || true; sleep 1; kill -KILL -"$PGID" 2>/dev/null || true ) >/dev/null 2>&1 &
  fi
  rm -f "$PID_PGID" 2>/dev/null || true
fi

# Fallback: kill any openvpn processes (por si no hay PID)
pkill -f "openvpn --config $OVPN" 2>/dev/null || true
pkill -x openvpn 2>/dev/null || true

# Bring down and delete tun interfaces
for IFACE in $(ip -o link show | awk -F': ' '/^ *[0-9]+: tun[0-9]+/ {print $2}'); do
  ip link set "$IFACE" down 2>/dev/null || true
  ip link delete "$IFACE" 2>/dev/null || true
done

# Flush common policy routing table if used
ip route flush table 128 2>/dev/null || true

# Kill any Yad tray (preferir PID guardado)
pkill -f "yad --notification" 2>/dev/null || true
if [[ -f "$PID_YAD" ]]; then
  YAD_PID=$(cat "$PID_YAD" 2>/dev/null || echo "")
  if [[ -n "$YAD_PID" ]] && kill -0 "$YAD_PID" 2>/dev/null; then
    kill "$YAD_PID" || true
    sleep 1
    kill -9 "$YAD_PID" 2>/dev/null || true
  fi
  rm -f "$PID_YAD"
fi

exit 0
