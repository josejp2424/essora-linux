#!/bin/bash
set -euo pipefail

BASE="${1:-/root/.riseupvpn}"
URL="${RISEUP_EIP_URL:-https://api.black.riseup.net/3/config/eip-service.json}"

CATALOG="$BASE/remotes.catalog"
LIST="$BASE/remotes.list"
SELECTED="$BASE/remotes.selected"


# Mantener también actualizado el template del paquete (para que no se sobrescriba al relanzar)
TEMPLATE_DIR="/usr/local/riseupvpn/conf-riseupvpn"

mkdir -p "$BASE"
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

fetch() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$URL" -o "$TMP"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO "$TMP" "$URL"
  else
    echo "ERROR: necesitas curl o wget." >&2
    exit 1
  fi
}

fetch

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 no está instalado." >&2
  exit 1
fi

python3 - <<'PY' "$TMP" "$CATALOG"
import json, sys

src, out = sys.argv[1], sys.argv[2]
data = json.load(open(src, "r", encoding="utf-8"))

gateways = data.get("gateways", [])
locations = data.get("locations", {})

# Mapeo simple (si aparece otro país, cae al código)
COUNTRY = {
  "US": "United States",
  "FR": "France",
  "NL": "Netherlands",
  "CA": "Canada",
}

rows = []
seen = set()
for gw in gateways:
  host = (gw.get("host") or "").strip()
  loc_key = (gw.get("location") or "").strip()
  if not host or host in seen:
    continue
  seen.add(host)

  loc = locations.get(loc_key, {})
  cc = (loc.get("country_code") or "").strip()
  city = (loc.get("name") or loc_key or "").strip()
  country = COUNTRY.get(cc, cc or "??")

  # cc,country,city,host
  rows.append((cc, country, city, host))

rows.sort(key=lambda r: (r[0], r[2], r[3]))

with open(out, "w", encoding="utf-8") as f:
  f.write("cc,country,city,host\n")
  for cc, country, city, host in rows:
    # CSV simple (sin comillas) porque tus campos son limpios
    f.write(f"{cc},{country},{city},{host}\n")
PY

# remotes.list = solo hosts (col 4), únicos
awk -F',' 'NR>1 && $4!="" {print $4}' "$CATALOG" | awk '!seen[$0]++' > "$LIST"

echo "[OK] Actualizado:"
echo " - $CATALOG"
echo " - $LIST"

# Mantener la actualización también en la plantilla del sistema (para que no se pierda al relanzar la GUI)
if [ -d "$TEMPLATE_DIR" ] && [ -w "$TEMPLATE_DIR" ]; then
  cp -af "$CATALOG" "$TEMPLATE_DIR/remotes.catalog" 2>/dev/null || true
  cp -af "$LIST" "$TEMPLATE_DIR/remotes.list" 2>/dev/null || true
  chown root:root "$TEMPLATE_DIR/remotes.catalog" "$TEMPLATE_DIR/remotes.list" 2>/dev/null || true
fi


# Si querés forzar que el selector use la lista nueva:
if [ -f "$SELECTED" ]; then
  rm -f "$SELECTED"
  echo "[OK] Eliminado $SELECTED (para forzar recarga)"
fi
