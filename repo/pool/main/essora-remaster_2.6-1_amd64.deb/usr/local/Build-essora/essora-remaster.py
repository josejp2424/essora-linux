#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# AUTOR: josejp2424
# VERSIÓN: 2.1
# LICENCIA: GPL-3.0
"""
Essora Remaster — Snapshot GUI (GTK3) v2.6
- Auto-copia de archivos de configuración al iniciar desde /usr/local/Build-essora/
- SIEMPRE usa archivos de Build-essora como referencia (sin valores hardcodeados)
- "Save config" actualiza solo valores de GUI manteniendo todo lo demás
- Mantiene modificaciones manuales en archivos .conf y .excludes
- Detección automática del idioma del sistema
- Soporte multiidioma completo (12 idiomas)
- Gestión de usuario y contraseñas antes de comprimir (con switch on/off)
- VALIDACIONES DE SEGURIDAD mejoradas
"""

import os
import sys
import time
import locale
import subprocess
from pathlib import Path
import json

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib, Pango

# ----------------- Constants -----------------
VERSION = "2.6"
AUTHOR = "josejp2424"
LICENSE = "GPL-3.0"
PROJECT_NAME = "Essora Remaster"

SNAPSHOT_BASENAME_DEFAULT = "Essora_Live"
SNAPSHOT_DIR_DEFAULT = Path("/home/snapshot")
WORK_DIR_DEFAULT = Path("/home/work")

CONF_FILE = Path("/etc/refractasnapshot.conf")
EXCLUDES_FILE = Path("/etc/refractasnapshot.excludes")
ERROR_LOG = Path("/var/log/refractasnapshot_errors.log")

BRAND_ICON_PATH = Path("/usr/local/Build-essora/essora-remaster.png")
BANNER_PATH = Path("/usr/local/Build-essora/essora-remaster.png")

THEME_CONFIG = Path.home() / ".config/snapshot_theme_config.json"

# ----------------- i18n strings -----------------
LANGS = {
    "en": {
        "title": "Essora Remaster",
        "cfg": "Configuration",
        "name": "ISO name (snapshot_basename):",
        "snap": "Snapshot dir:",
        "work": "Work dir:",
        "clean": "Clean networks (do not copy Wi-Fi/Ethernet to ISO)",
        "save": "Save config",
        "lang_btn": "Language",
        "act": "Action (same as RefractaSnapshot menu)",
        "a1": "1) Create snapshot (UEFI enabled)",
        "a2": "2) Re-squash and make ISO (no-copy)",
        "a3": "3) Re-make EFI files and ISO (no-copy, no-squash)",
        "a4": "4) Re-run xorriso only",
        "b_conf": "Edit conf",
        "b_excl": "Edit excludes",
        "b_open": "Open ISO folder",
        "b_log": "View error log",
        "b_gen": "Generate ISO",
        "tip": "Tip: run as root. The ISO is saved in snapshot_dir.",
        "pick": "Choose language",
        "start": "→ Starting refractasnapshot…",
        "ok": "✔ Finished. Check snapshot_dir.",
        "fail": "✖ Exit code {}. Check {}",
        "user_cfg": "User Configuration",
        "new_user": "New live user:",
        "user_pass": "User password:",
        "root_pass": "Root password:",
        "old_user": "Old user to remove:",
        "modifying": "→ Modifying users and passwords...",
        "mod_ok": "✔ Users modified successfully.",
        "mod_fail": "✖ Failed to modify users: {}",
        "about": "About",
        "about_desc": "Advanced tool for creating customized Devuan live ISOs with user management",
        "version": "Version",
        "author": "Author",
        "license": "License",
        "for": "for",
        "website": "Website",
        "user_info": "Users and passwords will be modified AFTER copying\nthe system and BEFORE compressing it into squashfs.",
        "enable_user_mod": "Enable user modification",
        "user_mod_disabled": "(User modification is disabled)",
        "console": "Console",
        "choose_dir": "Choose folder",
        "close": "Close",
        "old_user_placeholder": "Leave empty to not remove anyone"
    },
    "es": {
        "title": "Essora Remaster",
        "cfg": "Configuración",
        "name": "Nombre de ISO:",
        "snap": "Carpeta de snapshot:",
        "work": "Carpeta de trabajo:",
        "clean": "Limpiar redes (no copiar Wi-Fi/Ethernet a la ISO)",
        "save": "Guardar config",
        "lang_btn": "Idioma",
        "act": "Acción (igual al menú de RefractaSnapshot)",
        "a1": "1) Crear snapshot (UEFI)",
        "a2": "2) Re-squash y crear ISO",
        "a3": "3) Re-crear EFI e ISO",
        "a4": "4) Solo ejecutar xorriso",
        "b_conf": "Editar conf",
        "b_excl": "Editar excludes",
        "b_open": "Abrir carpeta ISO",
        "b_log": "Ver log de errores",
        "b_gen": "Generar ISO",
        "tip": "Consejo: ejecutá como root. La ISO se guarda en snapshot_dir.",
        "pick": "Elegir idioma",
        "start": "→ Iniciando refractasnapshot…",
        "ok": "✔ Listo. Revisá snapshot_dir.",
        "fail": "✖ Código {}. Revisá {}",
        "user_cfg": "Configuración de Usuario",
        "new_user": "Nuevo usuario live:",
        "user_pass": "Contraseña de usuario:",
        "root_pass": "Contraseña de root:",
        "old_user": "Usuario viejo a eliminar:",
        "modifying": "→ Modificando usuarios y contraseñas...",
        "mod_ok": "✔ Usuarios modificados exitosamente.",
        "mod_fail": "✖ Error al modificar usuarios: {}",
        "about": "Acerca de",
        "about_desc": "Herramienta avanzada para crear ISOs live de Devuan personalizadas con gestión de usuarios",
        "version": "Versión",
        "author": "Autor",
        "license": "Licencia",
        "for": "para",
        "website": "Sitio web",
        "user_info": "Los usuarios y contraseñas se modificarán DESPUÉS de copiar\nel sistema y ANTES de comprimirlo en squashfs.",
        "enable_user_mod": "Habilitar modificación de usuarios",
        "user_mod_disabled": "(La modificación de usuarios está deshabilitada)",
        "console": "Consola",
        "choose_dir": "Elegir carpeta",
        "close": "Cerrar",
        "old_user_placeholder": "Dejar vacío para no eliminar ninguno"
    },
    "pt": {
        "title": "Essora Remaster",
        "cfg": "Configuração",
        "name": "Nome da ISO:",
        "snap": "Diretório do snapshot:",
        "work": "Diretório de trabalho:",
        "clean": "Limpar redes (não copiar Wi-Fi/Ethernet)",
        "save": "Salvar config",
        "lang_btn": "Idioma",
        "act": "Ação (menu RefractaSnapshot)",
        "a1": "1) Criar snapshot (UEFI)",
        "a2": "2) Re-squash e criar ISO",
        "a3": "3) Recriar arquivos EFI e ISO",
        "a4": "4) Executar apenas xorriso",
        "b_conf": "Editar conf",
        "b_excl": "Editar excludes",
        "b_open": "Abrir pasta ISO",
        "b_log": "Ver log de erros",
        "b_gen": "Gerar ISO",
        "tip": "Dica: execute como root. A ISO é salva em snapshot_dir.",
        "pick": "Escolher idioma",
        "start": "→ Iniciando refractasnapshot…",
        "ok": "✔ Concluído. Veja snapshot_dir.",
        "fail": "✖ Código {}. Veja {}",
        "user_cfg": "Configuração de Usuário",
        "new_user": "Novo usuário live:",
        "user_pass": "Senha do usuário:",
        "root_pass": "Senha do root:",
        "old_user": "Usuário antigo para remover:",
        "modifying": "→ Modificando usuários e senhas...",
        "mod_ok": "✔ Usuários modificados com sucesso.",
        "mod_fail": "✖ Falha ao modificar: {}",
        "about": "Sobre",
        "about_desc": "Ferramenta avançada para criar ISOs live personalizadas do Devuan com gestão de usuários",
        "version": "Versão",
        "author": "Autor",
        "license": "Licença",
        "for": "para",
        "website": "Site",
        "user_info": "Os usuários e senhas serão modificados DEPOIS de copiar\no sistema e ANTES de comprimi-lo em squashfs.",
        "enable_user_mod": "Habilitar modificação de usuários",
        "user_mod_disabled": "(A modificação de usuários está desabilitada)"
    },
    "fr": {
        "title": "Essora Remaster",
        "cfg": "Configuration",
        "name": "Nom de l'ISO :",
        "snap": "Dossier snapshot :",
        "work": "Dossier de travail :",
        "clean": "Nettoyer les réseaux (ne pas copiar Wi-Fi/Ethernet)",
        "save": "Enregistrer",
        "lang_btn": "Langue",
        "act": "Action (menu RefractaSnapshot)",
        "a1": "1) Créer un snapshot (UEFI)",
        "a2": "2) Re-squash et créer l'ISO",
        "a3": "3) Recréer EFI et ISO",
        "a4": "4) Exécuter uniquement xorriso",
        "b_conf": "Éditer conf",
        "b_excl": "Éditer excludes",
        "b_open": "Ouvrir le dossier ISO",
        "b_log": "Voir le journal d'erreurs",
        "b_gen": "Générer l'ISO",
        "tip": "Astuce : exécutez en root. L'ISO est enregistrée dans snapshot_dir.",
        "pick": "Choisir la langue",
        "start": "→ Démarrage de refractasnapshot…",
        "ok": "✔ Terminé. Voir snapshot_dir.",
        "fail": "✖ Code {}. Voir {}",
        "user_cfg": "Configuration Utilisateur",
        "new_user": "Nouvel utilisateur live :",
        "user_pass": "Mot de passe utilisateur :",
        "root_pass": "Mot de passe root :",
        "old_user": "Ancien utilisateur à supprimer :",
        "modifying": "→ Modification des utilisateurs et mots de passe...",
        "mod_ok": "✔ Utilisateurs modifiés avec succès.",
        "mod_fail": "✖ Échec de modification : {}",
        "about": "À propos",
        "about_desc": "Outil avancé pour créer des ISOs live Devuan personnalisées avec gestion des utilisateurs",
        "version": "Version",
        "author": "Auteur",
        "license": "Licence",
        "for": "pour",
        "website": "Site web",
        "user_info": "Les utilisateurs et mots de passe seront modifiés APRÈS la copie\ndu système et AVANT de le compresser en squashfs.",
        "enable_user_mod": "Activer la modification des utilisateurs",
        "user_mod_disabled": "(La modification des utilisateurs est désactivée)"
    },
    "de": {
        "title": "Essora Remaster",
        "cfg": "Konfiguration",
        "name": "ISO-Name:",
        "snap": "Snapshot-Verzeichnis:",
        "work": "Arbeitsverzeichnis:",
        "clean": "Netzwerke bereinigen (Wi-Fi/Ethernet nicht kopieren)",
        "save": "Konfiguration speichern",
        "lang_btn": "Sprache",
        "act": "Aktion (wie RefractaSnapshot-Menü)",
        "a1": "1) Snapshot erstellen (UEFI)",
        "a2": "2) Neu komprimieren und ISO erstellen",
        "a3": "3) EFI und ISO neu erstellen",
        "a4": "4) Nur xorriso ausführen",
        "b_conf": "Conf bearbeiten",
        "b_excl": "Excludes bearbeiten",
        "b_open": "ISO-Ordner öffnen",
        "b_log": "Fehlerprotokoll anzeigen",
        "b_gen": "ISO generieren",
        "tip": "Tipp: Als root ausführen. Die ISO wird in snapshot_dir gespeichert.",
        "pick": "Sprache wählen",
        "start": "→ Starte refractasnapshot…",
        "ok": "✔ Fertig. Prüfe snapshot_dir.",
        "fail": "✖ Code {}. Siehe {}",
        "user_cfg": "Benutzerkonfiguration",
        "new_user": "Neuer Live-Benutzer:",
        "user_pass": "Benutzerpasswort:",
        "root_pass": "Root-Passwort:",
        "old_user": "Alter Benutzer zum Entfernen:",
        "modifying": "→ Benutzer und Passwörter werden geändert...",
        "mod_ok": "✔ Benutzer erfolgreich geändert.",
        "mod_fail": "✖ Fehler beim Ändern: {}",
        "about": "Über",
        "about_desc": "Erweitertes Tool zum Erstellen angepasster Devuan-Live-ISOs mit Benutzerverwaltung",
        "version": "Version",
        "author": "Autor",
        "license": "Lizenz",
        "for": "für",
        "website": "Webseite",
        "user_info": "Benutzer und Passwörter werden NACH dem Kopieren\ndes Systems und VOR dem Komprimieren in squashfs geändert.",
        "enable_user_mod": "Benutzeränderung aktivieren",
        "user_mod_disabled": "(Benutzeränderung ist deaktiviert)"
    },
    "it": {
        "title": "Essora Remaster",
        "cfg": "Configurazione",
        "name": "Nome ISO:",
        "snap": "Directory snapshot:",
        "work": "Directory di lavoro:",
        "clean": "Pulisci reti (non copiare Wi-Fi/Ethernet)",
        "save": "Salva config",
        "lang_btn": "Lingua",
        "act": "Azione (menu RefractaSnapshot)",
        "a1": "1) Crea snapshot (UEFI)",
        "a2": "2) Re-squash e crea ISO",
        "a3": "3) Ricrea EFI e ISO",
        "a4": "4) Solo xorriso",
        "b_conf": "Modifica conf",
        "b_excl": "Modifica excludes",
        "b_open": "Apri cartella ISO",
        "b_log": "Vedi registro errori",
        "b_gen": "Genera ISO",
        "tip": "Suggerimento: eseguire come root. L'ISO è salvata in snapshot_dir.",
        "pick": "Scegli la lingua",
        "start": "→ Avvio di refractasnapshot…",
        "ok": "✔ Finito. Controlla snapshot_dir.",
        "fail": "✖ Codice {}. Vedi {}",
        "user_cfg": "Configurazione Utente",
        "new_user": "Nuovo utente live:",
        "user_pass": "Password utente:",
        "root_pass": "Password root:",
        "old_user": "Vecchio utente da rimuovere:",
        "modifying": "→ Modifica utenti e password...",
        "mod_ok": "✔ Utenti modificati con successo.",
        "mod_fail": "✖ Errore nella modifica: {}",
        "about": "Informazioni",
        "about_desc": "Strumento avanzato per creare ISO live personalizzate di Devuan con gestione utenti",
        "version": "Versione",
        "author": "Autore",
        "license": "Licenza",
        "for": "per",
        "website": "Sito web",
        "user_info": "Utenti e password saranno modificati DOPO aver copiato\nil sistema e PRIMA di comprimerlo in squashfs.",
        "enable_user_mod": "Abilita modifica utenti",
        "user_mod_disabled": "(La modifica degli utenti è disabilitata)"
    },
    "ar": {
        "title": "Essora Remaster",
        "cfg": "الإعدادات",
        "name": "اسم ملف ISO:",
        "snap": "مجلد اللقطة:",
        "work": "مجلد العمل:",
        "clean": "تنظيف الشبكات (لا تنسخ Wi-Fi/Ethernet إلى ISO)",
        "save": "حفظ الإعداد",
        "lang_btn": "اللغة",
        "act": "الإجراء (مثل قائمة RefractaSnapshot)",
        "a1": "1) إنشاء لقطة (UEFI)",
        "a2": "2) إعادة الضغط وإنشاء ISO",
        "a3": "3) إعادة إنشاء ملفات EFI و ISO",
        "a4": "4) تشغيل xorriso فقط",
        "b_conf": "تحرير conf",
        "b_excl": "تحرير excludes",
        "b_open": "فتح مجلد ISO",
        "b_log": "عرض سجل الأخطاء",
        "b_gen": "إنشاء ISO",
        "tip": "نصيحة: شغّل كـ root. سيتم حفظ ISO في snapshot_dir.",
        "pick": "اختر اللغة",
        "start": "→ بدء refractasnapshot…",
        "ok": "✔ تم. تحقق من snapshot_dir.",
        "fail": "✖ الرمز {}. راجع {}",
        "user_cfg": "إعدادات المستخدم",
        "new_user": "مستخدم live جديد:",
        "user_pass": "كلمة مرور المستخدم:",
        "root_pass": "كلمة مرور الجذر:",
        "old_user": "المستخدم القديم للحذف:",
        "modifying": "→ تعديل المستخدمين وكلمات المرور...",
        "mod_ok": "✔ تم تعديل المستخدمين بنجاح.",
        "mod_fail": "✖ فشل تعديل المستخدمين: {}",
        "about": "حول",
        "about_desc": "أداة متقدمة لإنشاء ISOs live مخصصة من Devuan مع إدارة المستخدمين",
        "version": "الإصدار",
        "author": "المؤلف",
        "license": "الترخيص",
        "for": "لـ",
        "website": "الموقع",
        "user_info": "سيتم تعديل المستخدمين وكلمات المرور بعد نسخ\nالنظام وقبل ضغطه في squashfs."
    },
    "ca": {
        "title": "Essora Remaster",
        "cfg": "Configuració",
        "name": "Nom de la ISO:",
        "snap": "Carpeta de snapshot:",
        "work": "Carpeta de treball:",
        "clean": "Neteja xarxes (no copiïs Wi-Fi/Ethernet a la ISO)",
        "save": "Desa configuració",
        "lang_btn": "Idioma",
        "act": "Acció (igual al menú de RefractaSnapshot)",
        "a1": "1) Crear snapshot (UEFI)",
        "a2": "2) Re-squash i crear ISO",
        "a3": "3) Re-crear EFI i ISO",
        "a4": "4) Només xorriso",
        "b_conf": "Editar conf",
        "b_excl": "Editar excludes",
        "b_open": "Obrir carpeta ISO",
        "b_log": "Veure registre d'errors",
        "b_gen": "Generar ISO",
        "tip": "Consell: executa com a root. La ISO es desa a snapshot_dir.",
        "pick": "Tria l'idioma",
        "start": "→ Iniciant refractasnapshot…",
        "ok": "✔ Fet. Comprova snapshot_dir.",
        "fail": "✖ Codi {}. Revisa {}",
        "user_cfg": "Configuració d'Usuari",
        "new_user": "Nou usuari live:",
        "user_pass": "Contrasenya d'usuari:",
        "root_pass": "Contrasenya de root:",
        "old_user": "Usuari antic a eliminar:",
        "modifying": "→ Modificant usuaris i contrasenyes...",
        "mod_ok": "✔ Usuaris modificats correctament.",
        "mod_fail": "✖ Error en modificar usuaris: {}",
        "about": "Quant a",
        "about_desc": "Eina avançada per crear ISOs live personalitzades de Devuan amb gestió d'usuaris",
        "version": "Versió",
        "author": "Autor",
        "license": "Llicència",
        "for": "per a",
        "website": "Lloc web",
        "user_info": "Els usuaris i contrasenyes es modificaran DESPRÉS de copiar\nel sistema i ABANS de comprimir-lo en squashfs."
    },
    "ja": {
        "title": "Essora Remaster",
        "cfg": "設定",
        "name": "ISO 名:",
        "snap": "スナップショット先:",
        "work": "作業ディレクトリ:",
        "clean": "ネットワークをクリーン（Wi-Fi/Ethernet を ISO にコピーしない）",
        "save": "設定を保存",
        "lang_btn": "言語",
        "act": "操作（RefractaSnapshot メニューと同じ）",
        "a1": "1) スナップショット作成 (UEFI)",
        "a2": "2) 再圧縮して ISO 作成（コピーなし）",
        "a3": "3) EFI/ISO 再作成（コピー/圧縮なし）",
        "a4": "4) xorriso のみ再実行",
        "b_conf": "conf を編集",
        "b_excl": "excludes を編集",
        "b_open": "ISO フォルダを開く",
        "b_log": "エラーログを見る",
        "b_gen": "ISO を生成",
        "tip": "メモ: root で実行。ISO は snapshot_dir に保存されます。",
        "pick": "言語を選択",
        "start": "→ refractasnapshot を開始…",
        "ok": "✔ 完了。snapshot_dir を確認してください。",
        "fail": "✖ 終了コード {}。{} を確認",
        "user_cfg": "ユーザー設定",
        "new_user": "新しいライブユーザー:",
        "user_pass": "ユーザーパスワード:",
        "root_pass": "root パスワード:",
        "old_user": "削除する古いユーザー:",
        "modifying": "→ ユーザーとパスワードを変更中...",
        "mod_ok": "✔ ユーザーの変更が完了しました。",
        "mod_fail": "✖ ユーザー変更に失敗: {}",
        "about": "について",
        "about_desc": "ユーザー管理機能を備えたカスタマイズ可能な Devuan ライブ ISO を作成する高度なツール",
        "version": "バージョン",
        "author": "作者",
        "license": "ライセンス",
        "for": "用",
        "website": "ウェブサイト",
        "user_info": "ユーザーとパスワードは、システムをコピーした後、\nsquashfs に圧縮する前に変更されます。",
        "enable_user_mod": "ユーザー変更を有効にする",
        "user_mod_disabled": "(ユーザー変更は無効です)"
    },
    "hu": {
        "title": "Essora Remaster",
        "cfg": "Beállítások",
        "name": "ISO név:",
        "snap": "Snapshot könyvtár:",
        "work": "Munkakönyvtár:",
        "clean": "Hálózatok tisztítása (ne másolja a Wi-Fi/Ethernet beállításokat)",
        "save": "Beállítás mentése",
        "lang_btn": "Nyelv",
        "act": "Művelet (RefractaSnapshot menü)",
        "a1": "1) Snapshot létrehozása (UEFI)",
        "a2": "2) Újratömörítés és ISO",
        "a3": "3) EFI és ISO újra",
        "a4": "4) Csak xorriso",
        "b_conf": "Conf szerkesztése",
        "b_excl": "Excludes szerkesztése",
        "b_open": "ISO mappa megnyitása",
        "b_log": "Hibanapló megtekintése",
        "b_gen": "ISO készítése",
        "tip": "Tipp: rootként futtasd. Az ISO a snapshot_dir-ben lesz.",
        "pick": "Nyelv választása",
        "start": "→ refractasnapshot indítása…",
        "ok": "✔ Kész. Nézd meg a snapshot_dir-t.",
        "fail": "✖ Kód {}. Nézd meg: {}",
        "user_cfg": "Felhasználó beállítások",
        "new_user": "Új live felhasználó:",
        "user_pass": "Felhasználó jelszó:",
        "root_pass": "Root jelszó:",
        "old_user": "Régi felhasználó törlése:",
        "modifying": "→ Felhasználók és jelszavak módosítása...",
        "mod_ok": "✔ Felhasználók sikeresen módosítva.",
        "mod_fail": "✖ Hiba a módosításnál: {}",
        "about": "Névjegy",
        "about_desc": "Fejlett eszköz testreszabott Devuan élő ISO-k létrehozásához felhasználókezeléssel",
        "version": "Verzió",
        "author": "Szerző",
        "license": "Licenc",
        "for": "számára",
        "website": "Weboldal",
        "user_info": "A felhasználók és jelszavak a rendszer másolása UTÁN\nés a squashfs tömörítése ELŐTT kerülnek módosításra.",
        "enable_user_mod": "Felhasználó módosítás engedélyezése",
        "user_mod_disabled": "(A felhasználó módosítás letiltva)"
    },
    "ru": {
        "title": "Essora Remaster",
        "cfg": "Конфигурация",
        "name": "Имя ISO:",
        "snap": "Каталог снапшота:",
        "work": "Рабочий каталог:",
        "clean": "Очистить сети (не копировать Wi-Fi/Ethernet в ISO)",
        "save": "Сохранить",
        "lang_btn": "Язык",
        "act": "Действие (как в меню RefractaSnapshot)",
        "a1": "1) Создать снапшот (UEFI)",
        "a2": "2) Переупаковать и создать ISO",
        "a3": "3) Пересоздать EFI и ISO",
        "a4": "4) Только запустить xorriso",
        "b_conf": "Правка conf",
        "b_excl": "Правка excludes",
        "b_open": "Открыть папку ISO",
        "b_log": "Просмотр журнала ошибок",
        "b_gen": "Собрать ISO",
        "tip": "Подсказка: запускайте от root. ISO сохраняется в snapshot_dir.",
        "pick": "Выберите язык",
        "start": "→ Запуск refractasnapshot…",
        "ok": "✔ Готово. Проверьте snapshot_dir.",
        "fail": "✖ Код завершения {}. Проверьте {}",
        "user_cfg": "Настройка пользователя",
        "new_user": "Новый live пользователь:",
        "user_pass": "Пароль пользователя:",
        "root_pass": "Пароль root:",
        "old_user": "Старый пользователь для удаления:",
        "modifying": "→ Изменение пользователей и паролей...",
        "mod_ok": "✔ Пользователи успешно изменены.",
        "mod_fail": "✖ Ошибка изменения: {}",
        "about": "О программе",
        "about_desc": "Продвинутый инструмент для создания настраиваемых живых ISO Devuan с управлением пользователями",
        "version": "Версия",
        "author": "Автор",
        "license": "Лицензия",
        "for": "для",
        "website": "Веб-сайт",
        "user_info": "Пользователи и пароли будут изменены ПОСЛЕ копирования\nсистемы и ПЕРЕД сжатием в squashfs.",
        "enable_user_mod": "Включить изменение пользователей",
        "user_mod_disabled": "(Изменение пользователей отключено)"
    },
    "zh": {
        "title": "Essora Remaster",
        "cfg": "配置",
        "name": "ISO 名称：",
        "snap": "快照目录：",
        "work": "工作目录：",
        "clean": "清理网络（不要复制 Wi-Fi/以太网到 ISO）",
        "save": "保存配置",
        "lang_btn": "语言",
        "act": "操作（与 RefractaSnapshot 菜单相同）",
        "a1": "1) 创建快照 (UEFI)",
        "a2": "2) 重新压缩并制作 ISO（无复制）",
        "a3": "3) 重新制作 EFI 文件和 ISO（无复制、无压缩）",
        "a4": "4) 仅重新运行 xorriso",
        "b_conf": "编辑 conf",
        "b_excl": "编辑 excludes",
        "b_open": "打开 ISO 文件夹",
        "b_log": "查看错误日志",
        "b_gen": "生成 ISO",
        "tip": "提示：以 root 身份运行。ISO 保存在 snapshot_dir 中。",
        "pick": "选择语言",
        "start": "→ 启动 refractasnapshot…",
        "ok": "✔ 完成。检查 snapshot_dir。",
        "fail": "✖ 退出代码 {}。检查 {}",
        "user_cfg": "用户配置",
        "new_user": "新 live 用户：",
        "user_pass": "用户密码：",
        "root_pass": "root 密码：",
        "old_user": "要删除的旧用户：",
        "modifying": "→ 正在修改用户和密码...",
        "mod_ok": "✔ 用户修改成功。",
        "mod_fail": "✖ 修改用户失败：{}",
        "about": "关于",
        "about_desc": "用于创建具有用户管理功能的自定义 Devuan live ISO 的高级工具",
        "version": "版本",
        "author": "作者",
        "license": "许可证",
        "for": "为",
        "website": "网站",
        "user_info": "用户和密码将在复制系统之后、\n压缩到 squashfs 之前进行修改。",
        "enable_user_mod": "启用用户修改",
        "user_mod_disabled": "(用户修改已禁用)"
    }
}



def detect_system_language():
    """Detect system language and return appropriate language code"""
    try:
        # Try to get system locale
        lang_code = locale.getdefaultlocale()[0]
        
        if lang_code:
            # Extract language part (e.g., 'es' from 'es_AR')
            lang = lang_code.split('_')[0].lower()
            
            # Return if we have translations for this language
            if lang in LANGS:
                return lang
    except:
        pass
    
    # Default to English
    return "en"

def tr(lang, key):
    """Translate key to current language"""
    return LANGS.get(lang, LANGS["en"]).get(key, LANGS["en"].get(key, key))

# ----------------- Theme management -----------------
def load_theme():
    """Load theme preference"""
    if THEME_CONFIG.exists():
        try:
            with open(THEME_CONFIG) as f:
                data = json.load(f)
                return data.get("theme", "light")
        except:
            pass
    return "light"

def save_theme(theme):
    """Save theme preference"""
    THEME_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    with open(THEME_CONFIG, "w") as f:
        json.dump({"theme": theme}, f)

def which(cmd):
    """Find executable in PATH"""
    for p in os.environ.get("PATH", "").split(":"):
        full = Path(p) / cmd
        if full.exists() and os.access(full, os.X_OK):
            return str(full)
    return None

# ----------------- Config writers -----------------
def write_conf(lang, basename, snapdir, workdir, textbuffer):
    """Update refractasnapshot.conf - only modify GUI-controlled values"""
    try:
        # SIEMPRE leer desde el archivo de referencia de Build-essora
        source_conf = Path("/usr/local/Build-essora/refractasnapshot.conf")
        
        # Leer el archivo existente en /etc/ o usar el de referencia
        if CONF_FILE.exists():
            content = CONF_FILE.read_text()
        elif source_conf.exists():
            # Si no existe en /etc/, copiar desde Build-essora como base
            content = source_conf.read_text()
            log_to_buffer(textbuffer, f"ℹ Usando {source_conf} como base.\n")
        else:
            # ERROR: No existe ni en /etc/ ni en Build-essora
            log_to_buffer(textbuffer, f"✖ ERROR: No se encontró {CONF_FILE} ni {source_conf}\n")
            return
        
        # Actualizar solo los valores que se cambian en la GUI
        import re
        
        # Actualizar snapshot_basename
        content = re.sub(
            r'^snapshot_basename=.*$',
            f'snapshot_basename="{basename}"',
            content,
            flags=re.MULTILINE
        )
        
        # Actualizar snapshot_dir
        content = re.sub(
            r'^snapshot_dir=.*$',
            f'snapshot_dir="{snapdir}"',
            content,
            flags=re.MULTILINE
        )
        
        # Actualizar work_dir
        content = re.sub(
            r'^work_dir=.*$',
            f'work_dir="{workdir}"',
            content,
            flags=re.MULTILINE
        )
        
        # Actualizar efi_work basado en work_dir
        content = re.sub(
            r'^efi_work=.*$',
            f'efi_work="{workdir}/efi-files"',
            content,
            flags=re.MULTILINE
        )
        
        # Guardar
        CONF_FILE.write_text(content)
        log_to_buffer(textbuffer, f"✔ {CONF_FILE} actualizado (solo valores de GUI).\n")
    except Exception as e:
        log_to_buffer(textbuffer, f"✖ Error escribiendo conf: {e}\n")

def write_excludes(lang, clean_networks, textbuffer):
    """Update refractasnapshot.excludes - only modify network cleaning section"""
    try:
        # SIEMPRE leer desde el archivo de referencia de Build-essora
        source_excludes = Path("/usr/local/Build-essora/refractasnapshot.excludes")
        
        # Leer el archivo existente en /etc/ o usar el de referencia
        if EXCLUDES_FILE.exists():
            content = EXCLUDES_FILE.read_text()
        elif source_excludes.exists():
            # Si no existe en /etc/, copiar desde Build-essora como base
            content = source_excludes.read_text()
            log_to_buffer(textbuffer, f"ℹ Usando {source_excludes} como base.\n")
        else:
            # ERROR: No existe ni en /etc/ ni en Build-essora
            log_to_buffer(textbuffer, f"✖ ERROR: No se encontró {EXCLUDES_FILE} ni {source_excludes}\n")
            return
        
        # Definir la sección de redes
        network_section = """
# === Limpieza de redes (controlado desde GUI) ===
/etc/NetworkManager/system-connections/*
/etc/wpa_supplicant/wpa_supplicant.conf
/etc/netplan/*
/etc/network/interfaces
/etc/network/interfaces.d/*
/var/lib/bluetooth/*
/var/lib/NetworkManager/*
/var/lib/iwd/*
"""
        
        # Remover cualquier sección de redes anterior
        import re
        content = re.sub(
            r'# === Limpieza de redes.*?/var/lib/iwd/\*\n',
            '',
            content,
            flags=re.DOTALL
        )
        
        # Agregar la sección de redes si está activada
        if clean_networks:
            content = content.rstrip() + network_section
        
        # Guardar
        EXCLUDES_FILE.write_text(content)
        status = "con" if clean_networks else "sin"
        log_to_buffer(textbuffer, f"✔ {EXCLUDES_FILE} actualizado ({status} limpieza de redes).\n")
    except Exception as e:
        log_to_buffer(textbuffer, f"✖ Error escribiendo excludes: {e}\n")

def log_to_buffer(textbuffer, text):
    """Append text to GTK TextBuffer"""
    if textbuffer:
        end_iter = textbuffer.get_end_iter()
        textbuffer.insert(end_iter, text)

# ----------------- User modification functions -----------------
def modify_users_in_chroot(work_dir, old_user, new_user, user_pass, root_pass, textbuffer, lang):
    """
    Modifica usuarios en el sistema copiado ANTES de comprimir
    """
    myfs = work_dir / "myfs"
    
    if not myfs.exists():
        log_to_buffer(textbuffer, f"✖ Error: {myfs} no existe.\n")
        return False
    
    # VALIDACIÓN DE SEGURIDAD: Verificar que myfs es realmente un directorio de snapshot
    # y no el sistema raíz
    if str(myfs.resolve()) == "/" or not (myfs / "etc").exists():
        log_to_buffer(textbuffer, f"✖ ERROR CRÍTICO: {myfs} no parece ser un snapshot válido. Abortando por seguridad.\n")
        return False
    
    # VALIDACIÓN: Verificar que work_dir contiene "work" o "snapshot" para evitar accidentes
    work_str = str(work_dir).lower()
    if not any(x in work_str for x in ['work', 'snapshot', 'iso', 'build']):
        log_to_buffer(textbuffer, f"⚠ ADVERTENCIA: {work_dir} no parece un directorio de trabajo estándar.\n")
        log_to_buffer(textbuffer, f"   Por seguridad, se recomienda usar directorios como /home/work o /home/snapshot\n")
    
    log_to_buffer(textbuffer, tr(lang, "modifying") + "\n")
    log_to_buffer(textbuffer, f"  → Trabajando en: {myfs}\n")
    
    try:
        # 1. Montar sistemas necesarios para chroot
        subprocess.run(['mount', '--bind', '/dev', str(myfs / 'dev')], check=True)
        subprocess.run(['mount', '--bind', '/proc', str(myfs / 'proc')], check=True)
        subprocess.run(['mount', '--bind', '/sys', str(myfs / 'sys')], check=True)
        
        try:
            # 2. Eliminar usuario viejo (si existe y se especificó)
            # IMPORTANTE: userdel -r (NO -rf) para evitar eliminar archivos fuera del chroot
            if old_user:
                result = subprocess.run(
                    ['chroot', str(myfs), 'userdel', '-r', old_user],
                    stderr=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    text=True
                )
                if result.returncode == 0:
                    log_to_buffer(textbuffer, f"  - Usuario '{old_user}' eliminado del sistema copiado.\n")
                else:
                    log_to_buffer(textbuffer, f"  ⚠ Usuario '{old_user}' no existe o no se pudo eliminar (ignorando).\n")
            
            # 3. Crear nuevo usuario
            subprocess.run(
                ['chroot', str(myfs), 'useradd', '-m', '-s', '/bin/bash', new_user],
                check=True
            )
            log_to_buffer(textbuffer, f"  - Usuario '{new_user}' creado.\n")
            
            # 4. Cambiar contraseñas
            if user_pass:
                proc = subprocess.run(
                    ['chroot', str(myfs), 'chpasswd'],
                    input=f'{new_user}:{user_pass}\n',
                    text=True,
                    check=True
                )
                log_to_buffer(textbuffer, f"  - Contraseña de '{new_user}' establecida.\n")
            
            if root_pass:
                proc = subprocess.run(
                    ['chroot', str(myfs), 'chpasswd'],
                    input=f'root:{root_pass}\n',
                    text=True,
                    check=True
                )
                log_to_buffer(textbuffer, "  - Contraseña de root establecida.\n")
            
            # 5. Agregar usuario a grupos importantes
            subprocess.run(
                ['chroot', str(myfs), 'usermod', '-aG',
                 'sudo,audio,video,plugdev,netdev,cdrom,floppy,scanner', new_user],
                check=True
            )
            log_to_buffer(textbuffer, f"  - Usuario '{new_user}' agregado a grupos.\n")
            
            # 6. Configurar autologin (opcional, para live system)
            # Aquí podrías agregar configuración de autologin según tu DE
            
            log_to_buffer(textbuffer, tr(lang, "mod_ok") + "\n")
            return True
            
        finally:
            # 7. Desmontar siempre
            subprocess.run(['umount', str(myfs / 'sys')], stderr=subprocess.DEVNULL)
            subprocess.run(['umount', str(myfs / 'proc')], stderr=subprocess.DEVNULL)
            subprocess.run(['umount', str(myfs / 'dev')], stderr=subprocess.DEVNULL)
            
    except Exception as e:
        log_to_buffer(textbuffer, tr(lang, "mod_fail").format(str(e)) + "\n")
        return False

def open_with_editor(filepath):
    """Open file with text editor"""
    editors = ["gedit", "mousepad", "leafpad", "geany", "nano", "vi"]
    for ed in editors:
        cmd = which(ed)
        if cmd:
            if ed in ["nano", "vi"]:
                # Terminal editors
                term = which("x-terminal-emulator") or which("xterm")
                if term:
                    subprocess.Popen([term, "-e", cmd, str(filepath)])
            else:
                subprocess.Popen([cmd, str(filepath)])
            return
    # Fallback
    subprocess.Popen(["xdg-open", str(filepath)])

# ----------------- Main GTK Application -----------------
class SnapshotApp(Gtk.Window):
    def __init__(self):
        super().__init__(title="Essora Remaster")
        
        # Set window icon
        if BRAND_ICON_PATH.exists():
            self.set_icon_from_file(str(BRAND_ICON_PATH))
        
        self.set_default_size(800, 440)
        self.set_border_width(4)
        
        # Centrar la ventana en la pantalla
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Language - English is the default (you can change it from the Language button)
        self.lang = "en"
        self.set_title(tr(self.lang, "title"))
        
        # *** COPIAR ARCHIVOS DE CONFIGURACIÓN AL INICIO ***
        self.copy_config_files()
        
        # Load theme
        theme = load_theme()
        self.apply_theme(theme)
        
        # Main container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(main_box)
        
        # Banner
        if BANNER_PATH.exists():
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(BANNER_PATH))
                # Scale to 800x200 maintaining aspect ratio
                scaled = pixbuf.scale_simple(400, 120, GdkPixbuf.InterpType.BILINEAR)
                banner = Gtk.Image.new_from_pixbuf(scaled)
                main_box.pack_start(banner, False, False, 0)
            except Exception as e:
                print(f"No se pudo cargar el banner: {e}")
        
        # Notebook for tabs
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)
        
        # Tab 1: Configuration
        config_page = self.create_config_page()
        self.tab_cfg = Gtk.Label(label=tr(self.lang, "cfg"))
        self.notebook.append_page(config_page, self.tab_cfg)
        
        # Tab 2: User Configuration
        user_page = self.create_user_page()
        self.tab_user = Gtk.Label(label=tr(self.lang, "user_cfg"))
        self.notebook.append_page(user_page, self.tab_user)
        
        # Tab 3: Actions
        action_page = self.create_action_page()
        self.tab_act = Gtk.Label(label=tr(self.lang, "act"))
        self.notebook.append_page(action_page, self.tab_act)
        
        # Console output
        console_frame = Gtk.Frame(label=tr(self.lang, "console"))
        self.console_frame = console_frame
        main_box.pack_start(console_frame, True, True, 8)
        
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(180)
        console_frame.add(scrolled)
        
        self.console_view = Gtk.TextView()
        self.console_view.set_editable(False)
        self.console_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.console_view.modify_font(Pango.FontDescription("Monospace 10"))
        self.console_buffer = self.console_view.get_buffer()
        scrolled.add(self.console_view)
        
        log_to_buffer(self.console_buffer, tr(self.lang, "tip") + "\n\n")
        
        # Bottom buttons
        button_box = Gtk.Box(spacing=6)
        main_box.pack_start(button_box, False, False, 0)
        
        # About button (left)
        self.btn_about = Gtk.Button(label=tr(self.lang, "about"))
        self.btn_about.connect("clicked", self.on_about_clicked)
        button_box.pack_start(self.btn_about, False, False, 0)
        
        self.btn_lang = Gtk.Button(label=tr(self.lang, "lang_btn"))
        self.btn_lang.connect("clicked", self.on_language_clicked)
        button_box.pack_start(self.btn_lang, False, False, 0)
        
        button_box.pack_start(Gtk.Label(), True, True, 0)  # Spacer
        
        self.btn_generate = Gtk.Button(label=tr(self.lang, "b_gen"))
        self.btn_generate.connect("clicked", self.on_generate_clicked)
        button_box.pack_end(self.btn_generate, False, False, 0)
    
    def copy_config_files(self):
        """
        Copia archivos de configuración desde /usr/local/Build-essora/ a /etc/
        Se ejecuta automáticamente al abrir la GUI
        """
        source_conf = Path("/usr/local/Build-essora/refractasnapshot.conf")
        source_excludes = Path("/usr/local/Build-essora/refractasnapshot.excludes")
        
        dest_conf = Path("/etc/refractasnapshot.conf")
        dest_excludes = Path("/etc/refractasnapshot.excludes")
        
        try:
            # Copiar refractasnapshot.conf
            if source_conf.exists():
                subprocess.run(['cp', '-r', str(source_conf), str(dest_conf)], check=True)
                print(f"✔ Copiado: {source_conf} → {dest_conf}")
            else:
                print(f"⚠ No se encontró: {source_conf}")
            
            # Copiar refractasnapshot.excludes
            if source_excludes.exists():
                subprocess.run(['cp', '-r', str(source_excludes), str(dest_excludes)], check=True)
                print(f"✔ Copiado: {source_excludes} → {dest_excludes}")
            else:
                print(f"⚠ No se encontró: {source_excludes}")
                
        except subprocess.CalledProcessError as e:
            print(f"✖ Error al copiar archivos de configuración: {e}")
        except Exception as e:
            print(f"✖ Error inesperado: {e}")
    
    def create_config_page(self):
        """Create configuration tab"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(4)
        
        # ISO name
        hbox = Gtk.Box(spacing=6)
        box.pack_start(hbox, False, False, 0)
        self.lbl_name = Gtk.Label(label=tr(self.lang, "name"))
        self.lbl_name.set_xalign(0)
        hbox.pack_start(self.lbl_name, False, False, 0)
        self.entry_basename = Gtk.Entry()
        self.entry_basename.set_text(SNAPSHOT_BASENAME_DEFAULT)
        hbox.pack_start(self.entry_basename, True, True, 0)
        
        # Snapshot dir
        hbox = Gtk.Box(spacing=6)
        box.pack_start(hbox, False, False, 0)
        self.lbl_snap = Gtk.Label(label=tr(self.lang, "snap"))
        self.lbl_snap.set_xalign(0)
        hbox.pack_start(self.lbl_snap, False, False, 0)
        self.entry_snapdir = Gtk.Entry()
        self.entry_snapdir.set_text(str(SNAPSHOT_DIR_DEFAULT))
        hbox.pack_start(self.entry_snapdir, True, True, 0)
        btn_snap = Gtk.Button(label="󱂵")
        btn_snap.connect("clicked", self.on_choose_dir, self.entry_snapdir)
        hbox.pack_start(btn_snap, False, False, 0)
        
        # Work dir
        hbox = Gtk.Box(spacing=6)
        box.pack_start(hbox, False, False, 0)
        self.lbl_work = Gtk.Label(label=tr(self.lang, "work"))
        self.lbl_work.set_xalign(0)
        hbox.pack_start(self.lbl_work, False, False, 0)
        self.entry_workdir = Gtk.Entry()
        self.entry_workdir.set_text(str(WORK_DIR_DEFAULT))
        hbox.pack_start(self.entry_workdir, True, True, 0)
        btn_work = Gtk.Button(label="󱂵")
        btn_work.connect("clicked", self.on_choose_dir, self.entry_workdir)
        hbox.pack_start(btn_work, False, False, 0)
        
        # Clean networks checkbox
        self.check_clean = Gtk.CheckButton(label=tr(self.lang, "clean"))
        self.check_clean.set_active(True)
        box.pack_start(self.check_clean, False, False, 0)
        # Edit buttons
        btn_box = Gtk.Box(spacing=6)
        box.pack_start(btn_box, False, False, 0)
        
        self.btn_conf = Gtk.Button(label=tr(self.lang, "b_conf"))
        self.btn_conf.connect("clicked", lambda w: open_with_editor(CONF_FILE))
        btn_box.pack_start(self.btn_conf, True, True, 0)
        
        self.btn_excl = Gtk.Button(label=tr(self.lang, "b_excl"))
        self.btn_excl.connect("clicked", lambda w: open_with_editor(EXCLUDES_FILE))
        btn_box.pack_start(self.btn_excl, True, True, 0)
        
        self.btn_open = Gtk.Button(label=tr(self.lang, "b_open"))
        self.btn_open.connect("clicked", self.on_open_iso_folder)
        btn_box.pack_start(self.btn_open, True, True, 0)
        
        self.btn_log = Gtk.Button(label=tr(self.lang, "b_log"))
        self.btn_log.connect("clicked", lambda w: open_with_editor(ERROR_LOG))
        btn_box.pack_start(self.btn_log, True, True, 0)
        
        return box
    
    def create_user_page(self):
        """Create user configuration tab"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(4)
        
        # Switch para habilitar/deshabilitar modificación de usuarios
        switch_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        switch_box.set_border_width(4)
        
        self.switch_label = Gtk.Label(label=tr(self.lang, "enable_user_mod"))
        self.switch_label.set_xalign(0)
        switch_box.pack_start(self.switch_label, False, False, 0)
        
        self.user_mod_switch = Gtk.Switch()
        self.user_mod_switch.set_active(True)  # Activado por defecto
        self.user_mod_switch.connect("notify::active", self.on_user_mod_switch_toggled)
        switch_box.pack_start(self.user_mod_switch, False, False, 0)
        
        box.pack_start(switch_box, False, False, 0)
        
        # Separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        box.pack_start(separator, False, False, 5)
        
        # Grid para los campos de usuario
        self.user_grid = Gtk.Grid()
        self.user_grid.set_column_spacing(10)
        self.user_grid.set_row_spacing(10)
        box.pack_start(self.user_grid, False, False, 0)
        
        # Old user to remove
        self.label_old_user = Gtk.Label(label=tr(self.lang, "old_user"), xalign=0)
        self.user_grid.attach(self.label_old_user, 0, 0, 1, 1)
        self.entry_old_user = Gtk.Entry()
        self.entry_old_user.set_text("essora")
        self.entry_old_user.set_placeholder_text(tr(self.lang, "old_user_placeholder"))
        self.user_grid.attach(self.entry_old_user, 1, 0, 1, 1)
        
        # New user
        self.label_new_user = Gtk.Label(label=tr(self.lang, "new_user"), xalign=0)
        self.user_grid.attach(self.label_new_user, 0, 1, 1, 1)
        self.entry_new_user = Gtk.Entry()
        self.entry_new_user.set_text("live")
        self.user_grid.attach(self.entry_new_user, 1, 1, 1, 1)
        
        # User password
        self.label_user_pass = Gtk.Label(label=tr(self.lang, "user_pass"), xalign=0)
        self.user_grid.attach(self.label_user_pass, 0, 2, 1, 1)
        self.entry_user_pass = Gtk.Entry()
        self.entry_user_pass.set_visibility(False)
        self.entry_user_pass.set_text("live")
        self.user_grid.attach(self.entry_user_pass, 1, 2, 1, 1)
        
        # Root password
        self.label_root_pass = Gtk.Label(label=tr(self.lang, "root_pass"), xalign=0)
        self.user_grid.attach(self.label_root_pass, 0, 3, 1, 1)
        self.entry_root_pass = Gtk.Entry()
        self.entry_root_pass.set_visibility(False)
        self.entry_root_pass.set_text("root")
        self.user_grid.attach(self.entry_root_pass, 1, 3, 1, 1)
        
        # Info label
        self.info_label = Gtk.Label()
        self.info_label.set_markup(f"<i>{tr(self.lang, 'user_info')}</i>")
        self.info_label.set_line_wrap(True)
        box.pack_start(self.info_label, False, False, 10)
        
        return box
    
    def on_user_mod_switch_toggled(self, switch, gparam):
        """Enable/disable user modification fields based on switch state"""
        is_active = switch.get_active()
        
        # Habilitar o deshabilitar todos los campos
        self.entry_old_user.set_sensitive(is_active)
        self.entry_new_user.set_sensitive(is_active)
        self.entry_user_pass.set_sensitive(is_active)
        self.entry_root_pass.set_sensitive(is_active)
        
        # Actualizar el texto de información
        if is_active:
            self.info_label.set_markup(f"<i>{tr(self.lang, 'user_info')}</i>")
        else:
            self.info_label.set_markup(f"<i>{tr(self.lang, 'user_mod_disabled')}</i>")
    
    def create_action_page(self):
        """Create action selection tab"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(4)
        
        self.action_group = None
        self.action_radios = []
        actions = [
            ("create", tr(self.lang, "a1")),
            ("resquash", tr(self.lang, "a2")),
            ("reefi", tr(self.lang, "a3")),
            ("xorriso", tr(self.lang, "a4"))
        ]
        
        for value, label in actions:
            if self.action_group is None:
                radio = Gtk.RadioButton.new_with_label_from_widget(None, label)
                self.action_group = radio
            else:
                radio = Gtk.RadioButton.new_with_label_from_widget(self.action_group, label)
            
            radio.set_name(value)
            self.action_radios.append((value, radio))
            box.pack_start(radio, False, False, 0)
        
        return box
    
    def apply_theme(self, theme):
        """Apply GTK theme"""
        settings = Gtk.Settings.get_default()
        if theme == "dark":
            settings.set_property("gtk-application-prefer-dark-theme", True)
        else:
            settings.set_property("gtk-application-prefer-dark-theme", False)
    
    def on_choose_dir(self, button, entry):
        """Open directory chooser"""
        dialog = Gtk.FileChooserDialog(
            title=tr(self.lang, "choose_dir"),
            parent=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            entry.set_text(dialog.get_filename())
        dialog.destroy()
    
    def on_save_config(self, button):
        """Save configuration"""
        snapdir = Path(self.entry_snapdir.get_text()).expanduser()
        workdir = Path(self.entry_workdir.get_text()).expanduser()
        basename = self.entry_basename.get_text().strip() or SNAPSHOT_BASENAME_DEFAULT
        
        snapdir.mkdir(parents=True, exist_ok=True)
        workdir.mkdir(parents=True, exist_ok=True)
        
        write_conf(self.lang, basename, snapdir, workdir, self.console_buffer)
        write_excludes(self.lang, self.check_clean.get_active(), self.console_buffer)
    
    def on_open_iso_folder(self, button):
        """Open ISO folder"""
        folder = Path(self.entry_snapdir.get_text()).expanduser()
        folder.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(["xdg-open", str(folder)])
    

    def on_language_clicked(self, button):
        """Open language selection dialog"""
        dialog = Gtk.Dialog(title=tr(self.lang, "pick"), parent=self, flags=0)
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )

        box = dialog.get_content_area()

        langs = [
            ("en", "English"),
            ("es", "Español"),
            ("pt", "Português"),
            ("fr", "Français"),
            ("de", "Deutsch"),
            ("it", "Italiano"),
            ("ar", "العربية"),
            ("ca", "Català"),
            ("ja", "日本語"),
            ("hu", "Magyar"),
            ("ru", "Русский"),
            ("zh", "中文")
        ]

        first_radio = None
        for code, name in langs:
            if first_radio is None:
                radio = Gtk.RadioButton.new_with_label_from_widget(None, name)
                first_radio = radio
            else:
                radio = Gtk.RadioButton.new_with_label_from_widget(first_radio, name)

            radio.set_name(code)
            if code == self.lang:
                radio.set_active(True)
            box.pack_start(radio, False, False, 5)

        dialog.show_all()
        response = dialog.run()

        if response == Gtk.ResponseType.OK and first_radio is not None:
            for radio in first_radio.get_group():
                if radio.get_active():
                    new_lang = radio.get_name()
                    if new_lang != self.lang:
                        self.lang = new_lang
                        self.update_ui_language()
                    break

        dialog.destroy()

    def update_ui_language(self):
        """Update all UI elements to the new language"""
        # Window title
        self.set_title(tr(self.lang, "title"))

        # Bottom buttons
        if hasattr(self, "btn_about"):
            self.btn_about.set_label(tr(self.lang, "about"))
        if hasattr(self, "btn_lang"):
            self.btn_lang.set_label(tr(self.lang, "lang_btn"))
        if hasattr(self, "btn_generate"):
            self.btn_generate.set_label(tr(self.lang, "b_gen"))

        # Notebook tab labels
        if hasattr(self, "tab_cfg"):
            self.tab_cfg.set_text(tr(self.lang, "cfg"))
        if hasattr(self, "tab_user"):
            self.tab_user.set_text(tr(self.lang, "user_cfg"))
        if hasattr(self, "tab_act"):
            self.tab_act.set_text(tr(self.lang, "act"))

        # Config page labels/buttons
        if hasattr(self, "lbl_name"):
            self.lbl_name.set_text(tr(self.lang, "name"))
        if hasattr(self, "lbl_snap"):
            self.lbl_snap.set_text(tr(self.lang, "snap"))
        if hasattr(self, "lbl_work"):
            self.lbl_work.set_text(tr(self.lang, "work"))
        if hasattr(self, "check_clean"):
            self.check_clean.set_label(tr(self.lang, "clean"))
        if hasattr(self, "btn_conf"):
            self.btn_conf.set_label(tr(self.lang, "b_conf"))
        if hasattr(self, "btn_excl"):
            self.btn_excl.set_label(tr(self.lang, "b_excl"))
        if hasattr(self, "btn_open"):
            self.btn_open.set_label(tr(self.lang, "b_open"))
        if hasattr(self, "btn_log"):
            self.btn_log.set_label(tr(self.lang, "b_log"))

        # Console frame label
        if hasattr(self, "console_frame"):
            self.console_frame.set_label(tr(self.lang, "console"))

        # Tip (only set if buffer exists; do not wipe logs if there are lines already)
        if hasattr(self, "console_buffer") and self.console_buffer:
            # Keep existing log; only ensure there's at least a tip at top if empty
            if self.console_buffer.get_char_count() == 0:
                self.console_buffer.set_text(tr(self.lang, "tip") + "\n\n")

        # User page
        if hasattr(self, "switch_label"):
            self.switch_label.set_text(tr(self.lang, "enable_user_mod"))
        if hasattr(self, "label_old_user"):
            self.label_old_user.set_text(tr(self.lang, "old_user"))
        if hasattr(self, "label_new_user"):
            self.label_new_user.set_text(tr(self.lang, "new_user"))
        if hasattr(self, "label_user_pass"):
            self.label_user_pass.set_text(tr(self.lang, "user_pass"))
        if hasattr(self, "label_root_pass"):
            self.label_root_pass.set_text(tr(self.lang, "root_pass"))
        if hasattr(self, "entry_old_user"):
            self.entry_old_user.set_placeholder_text(tr(self.lang, "old_user_placeholder"))

        if hasattr(self, "info_label") and hasattr(self, "user_mod_switch"):
            if self.user_mod_switch.get_active():
                self.info_label.set_markup(f"<i>{tr(self.lang, 'user_info')}</i>")
            else:
                self.info_label.set_markup(f"<i>{tr(self.lang, 'user_mod_disabled')}</i>")

        # Action radios
        if hasattr(self, "action_radios"):
            labels = {
                "create": tr(self.lang, "a1"),
                "resquash": tr(self.lang, "a2"),
                "reefi": tr(self.lang, "a3"),
                "xorriso": tr(self.lang, "a4"),
            }
            for value, radio in self.action_radios:
                radio.set_label(labels.get(value, value))

    def on_about_clicked(self, button):
        """Show custom About dialog with banner"""
        dialog = Gtk.Dialog(title=tr(self.lang, "about"), parent=self, flags=0)
        dialog.set_default_size(700, 500)
        
        box = dialog.get_content_area()
        box.set_spacing(15)
        box.set_border_width(4)
        
        # Banner in About dialog
        if BANNER_PATH.exists():
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(BANNER_PATH))
                scaled = pixbuf.scale_simple(400, 120, GdkPixbuf.InterpType.BILINEAR)
                banner = Gtk.Image.new_from_pixbuf(scaled)
                box.pack_start(banner, False, False, 0)
            except Exception as e:
                print(f"No se pudo cargar el banner en About: {e}")
        
        # Project name
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='xx-large' weight='bold'>{PROJECT_NAME}</span>")
        box.pack_start(title_label, False, False, 5)
        
        # Description
        desc_label = Gtk.Label(label=tr(self.lang, "about_desc"))
        desc_label.set_line_wrap(True)
        desc_label.set_max_width_chars(60)
        desc_label.set_justify(Gtk.Justification.CENTER)
        box.pack_start(desc_label, False, False, 5)
        
        # Version
        version_label = Gtk.Label()
        version_label.set_markup(f"<b>{tr(self.lang, 'version')}:</b> {VERSION}")
        box.pack_start(version_label, False, False, 2)
        
        # Author
        author_label = Gtk.Label()
        author_label.set_markup(f"<b>{tr(self.lang, 'author')}:</b> {AUTHOR}")
        box.pack_start(author_label, False, False, 2)
        
        # License
        license_label = Gtk.Label()
        license_label.set_markup(f"<b>{tr(self.lang, 'license')}:</b> {LICENSE}")
        box.pack_start(license_label, False, False, 2)
        
        # For Essora
        for_label = Gtk.Label()
        for_label.set_markup(f"<i>{tr(self.lang, 'for')} Essora</i>")
        box.pack_start(for_label, False, False, 10)
        
        # Close button
        close_btn = Gtk.Button(label=tr(self.lang, "close"))
        close_btn.connect("clicked", lambda w: dialog.destroy())
        box.pack_start(close_btn, False, False, 0)
        
        dialog.show_all()
        dialog.run()
        dialog.destroy()
    
    def on_generate_clicked(self, button):
        """Start ISO generation process"""
        # Save config first
        self.on_save_config(None)
        
        # Get selected action
        action = "create"
        for radio in self.action_group.get_group():
            if radio.get_active():
                action = radio.get_name()
                break
        
        # Get user configuration
        old_user = self.entry_old_user.get_text().strip()
        new_user = self.entry_new_user.get_text().strip() or "live"
        user_pass = self.entry_user_pass.get_text()
        root_pass = self.entry_root_pass.get_text()
        work_dir = Path(self.entry_workdir.get_text()).expanduser()
        
        # Get user modification switch state
        enable_user_mod = self.user_mod_switch.get_active()
        
        # Disable button during process
        button.set_sensitive(False)
        
        # Run in thread to avoid freezing UI
        GLib.idle_add(self.run_snapshot_process, action, old_user, new_user, 
                     user_pass, root_pass, work_dir, enable_user_mod, button)
    
    def run_snapshot_process(self, action, old_user, new_user, user_pass, 
                            root_pass, work_dir, enable_user_mod, button):
        """Run the snapshot creation process"""
        feed_map = {
            "create": "1\n",
            "resquash": "2\n",
            "reefi": "3\n",
            "xorriso": "4\n"
        }
        feed = feed_map.get(action, "1\n")
        
        log_to_buffer(self.console_buffer, tr(self.lang, "start") + "\n")
        
        try:
            # Start refractasnapshot
            proc = subprocess.Popen(
                "refractasnapshot",
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            sent_opt = False
            sent_q = False
            copy_done = False
            
            for line in iter(proc.stdout.readline, ''):
                log_to_buffer(self.console_buffer, line)
                
                # Send option selection
                if not sent_opt and ("Choose a task" in line):
                    time.sleep(0.2)
                    proc.stdin.write(feed)
                    proc.stdin.flush()
                    sent_opt = True
                
                # Detect when rsync is done (before mksquashfs)
                if "rsync completed" in line.lower() or "copying system" in line.lower():
                    copy_done = True
                
                # If copy is done and we're about to squash, modify users
                if copy_done and not sent_q and ("mksquashfs" in line.lower() or "squashing" in line.lower()):
                    # Modify users HERE, before squashfs compression
                    # Solo si el switch está activo y es creación completa
                    if action == "create" and enable_user_mod:
                        success = modify_users_in_chroot(
                            work_dir, old_user, new_user, 
                            user_pass, root_pass, 
                            self.console_buffer, self.lang
                        )
                        if not success:
                            log_to_buffer(self.console_buffer, 
                                        "⚠ Continuando sin modificar usuarios...\n")
                    elif action == "create" and not enable_user_mod:
                        log_to_buffer(self.console_buffer, 
                                    "ℹ Modificación de usuarios deshabilitada. Continuando...\n")
                    copy_done = False  # Reset flag
                
                # Send 'q' to continue when prompted
                if "To proceed, press q." in line and not sent_q:
                    time.sleep(0.2)
                    proc.stdin.write("q\n")
                    proc.stdin.flush()
                    sent_q = True
                
                # Update UI
                while Gtk.events_pending():
                    Gtk.main_iteration()
            
            proc.wait()
            
            if proc.returncode == 0:
                log_to_buffer(self.console_buffer, tr(self.lang, "ok") + "\n")
            else:
                log_to_buffer(self.console_buffer, 
                            tr(self.lang, "fail").format(proc.returncode, ERROR_LOG) + "\n")
        
        except Exception as e:
            log_to_buffer(self.console_buffer, f"✖ Error: {e}\n")
        
        finally:
            button.set_sensitive(True)
        
        return False  # Don't call again

# ----------------- Main -----------------
if __name__ == "__main__":
    # Check if running as root
    if os.geteuid() != 0:
        print("⚠ Advertencia: Se recomienda ejecutar como root")
    
    app = SnapshotApp()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()
