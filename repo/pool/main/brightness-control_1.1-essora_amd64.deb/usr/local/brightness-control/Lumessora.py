#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lumessora - Essora Brightness Control
Screen brightness control with GNOME-style interface
Author: josejp2424
License: GPL-3.0
Version: 1.0
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
import subprocess
import os
import locale

class BrightnessControl(Gtk.Window):
    def __init__(self):
        super().__init__(title="Lumessora")
        
        # Icon path
        self.icon_path = "/usr/local/brightness-control/Lumessora.svg"
        
        # Detect language
        self.setup_translations()
        
        # Window configuration
        self.set_default_size(420, 280)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_resizable(False)
        
        # Set window icon
        if os.path.exists(self.icon_path):
            try:
                self.set_icon_from_file(self.icon_path)
            except:
                pass
        
        # Detect monitor
        self.display_output = self.get_display_output()
        if not self.display_output:
            self.show_error_dialog(self.translations['error_no_display'])
            return
        
        # Get current brightness
        self.current_brightness = self.get_current_brightness()
        
        # Apply CSS
        self.apply_css()
        
        # Create headerbar
        self.create_headerbar()
        
        # Create content
        self.create_content()
        
        # Connect signals
        self.connect("delete-event", self.on_close)
        self.connect("key-press-event", self.on_key_press)
    
    def setup_translations(self):
        """Setup translations based on system language"""
        try:
            lang = locale.getdefaultlocale()[0]
            if lang:
                lang_code = lang.split('_')[0].lower()
            else:
                lang_code = 'en'
        except:
            lang_code = 'en'
        
        translations = {
            'es': {
                'title': 'Lumessora',
                'subtitle': 'Control de brillo',
                'brightness_label': 'Nivel de brillo',
                'apply': 'Aplicar',
                'cancel': 'Cancelar',
                'success_title': 'Configuración guardada',
                'success_message': 'El brillo se aplicará automáticamente al iniciar el sistema.',
                'error_no_display': 'No se detectó ningún monitor conectado',
                'close': 'Cerrar',
                'menu': 'Menú',
                'about': 'Acerca de Lumessora',
                'about_description': 'Control de brillo de pantalla para Essora Linux.\n\nPermite ajustar el brillo de forma gráfica y guardar la configuración para que se aplique automáticamente al iniciar el sistema.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Licenciado bajo GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Licencia'
            },
            'en': {
                'title': 'Lumessora',
                'subtitle': 'Brightness control',
                'brightness_label': 'Brightness level',
                'apply': 'Apply',
                'cancel': 'Cancel',
                'success_title': 'Settings saved',
                'success_message': 'Brightness will be applied automatically at system startup.',
                'error_no_display': 'No monitor detected',
                'close': 'Close',
                'menu': 'Menu',
                'about': 'About Lumessora',
                'about_description': 'Screen brightness control for Essora Linux.\n\nAllows you to adjust brightness graphically and save the configuration to be applied automatically at system startup.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Licensed under GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'License'
            },
            'fr': {
                'title': 'Lumessora',
                'subtitle': 'Contrôle de la luminosité',
                'brightness_label': 'Niveau de luminosité',
                'apply': 'Appliquer',
                'cancel': 'Annuler',
                'success_title': 'Paramètres enregistrés',
                'success_message': 'La luminosité sera appliquée automatiquement au démarrage du système.',
                'error_no_display': 'Aucun moniteur détecté',
                'close': 'Fermer',
                'menu': 'Menu',
                'about': 'À propos de Lumessora',
                'about_description': 'Contrôle de la luminosité de l\'écran pour Essora Linux.\n\nPermet d\'ajuster la luminosité graphiquement et de sauvegarder la configuration pour qu\'elle soit appliquée automatiquement au démarrage du système.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Sous licence GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Licence'
            },
            'pt': {
                'title': 'Lumessora',
                'subtitle': 'Controle de brilho',
                'brightness_label': 'Nível de brilho',
                'apply': 'Aplicar',
                'cancel': 'Cancelar',
                'success_title': 'Configurações salvas',
                'success_message': 'O brilho será aplicado automaticamente na inicialização do sistema.',
                'error_no_display': 'Nenhum monitor detectado',
                'close': 'Fechar',
                'menu': 'Menu',
                'about': 'Sobre o Lumessora',
                'about_description': 'Controle de brilho de tela para Essora Linux.\n\nPermite ajustar o brilho graficamente e salvar a configuração para ser aplicada automaticamente na inicialização do sistema.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Licenciado sob GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Licença'
            },
            'it': {
                'title': 'Lumessora',
                'subtitle': 'Controllo luminosità',
                'brightness_label': 'Livello di luminosità',
                'apply': 'Applica',
                'cancel': 'Annulla',
                'success_title': 'Impostazioni salvate',
                'success_message': "La luminosità verrà applicata automaticamente all'avvio del sistema.",
                'error_no_display': 'Nessun monitor rilevato',
                'close': 'Chiudi',
                'menu': 'Menu',
                'about': 'Informazioni su Lumessora',
                'about_description': 'Controllo della luminosità dello schermo per Essora Linux.\n\nConsente di regolare la luminosità graficamente e salvare la configurazione da applicare automaticamente all\'avvio del sistema.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Sotto licenza GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Licenza'
            },
            'de': {
                'title': 'Lumessora',
                'subtitle': 'Helligkeitssteuerung',
                'brightness_label': 'Helligkeitsstufe',
                'apply': 'Anwenden',
                'cancel': 'Abbrechen',
                'success_title': 'Einstellungen gespeichert',
                'success_message': 'Die Helligkeit wird beim Systemstart automatisch angewendet.',
                'error_no_display': 'Kein Monitor erkannt',
                'close': 'Schließen',
                'menu': 'Menü',
                'about': 'Über Lumessora',
                'about_description': 'Bildschirmhelligkeitssteuerung für Essora Linux.\n\nErmöglicht die grafische Anpassung der Helligkeit und das Speichern der Konfiguration zur automatischen Anwendung beim Systemstart.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Lizenziert unter GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Lizenz'
            },
            'ru': {
                'title': 'Lumessora',
                'subtitle': 'Управление яркостью',
                'brightness_label': 'Уровень яркости',
                'apply': 'Применить',
                'cancel': 'Отмена',
                'success_title': 'Настройки сохранены',
                'success_message': 'Яркость будет автоматически применена при запуске системы.',
                'error_no_display': 'Монитор не обнаружен',
                'close': 'Закрыть',
                'menu': 'Меню',
                'about': 'О программе Lumessora',
                'about_description': 'Управление яркостью экрана для Essora Linux.\n\nПозволяет графически настраивать яркость и сохранять конфигурацию для автоматического применения при запуске системы.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Под лицензией GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Лицензия'
            },
            'ja': {
                'title': 'Lumessora',
                'subtitle': '明るさの調整',
                'brightness_label': '明るさレベル',
                'apply': '適用',
                'cancel': 'キャンセル',
                'success_title': '設定を保存しました',
                'success_message': 'システム起動時に明るさが自動的に適用されます。',
                'error_no_display': 'モニターが検出されませんでした',
                'close': '閉じる',
                'menu': 'メニュー',
                'about': 'Lumessoraについて',
                'about_description': 'Essora Linux用の画面の明るさ調整ツール。\n\nグラフィカルに明るさを調整し、システム起動時に自動的に適用される設定を保存できます。',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'GPL-3.0でライセンスされています',
                'about_website': 'Essora Linux',
                'license': 'ライセンス'
            },
            'zh': {
                'title': 'Lumessora',
                'subtitle': '亮度控制',
                'brightness_label': '亮度级别',
                'apply': '应用',
                'cancel': '取消',
                'success_title': '设置已保存',
                'success_message': '系统启动时将自动应用亮度。',
                'error_no_display': '未检测到显示器',
                'close': '关闭',
                'menu': '菜单',
                'about': '关于 Lumessora',
                'about_description': 'Essora Linux 的屏幕亮度控制工具。\n\n允许以图形方式调整亮度并保存配置，以便在系统启动时自动应用。',
                'about_copyright': '© 2025 josejp2424',
                'about_license': '采用 GPL-3.0 许可',
                'about_website': 'Essora Linux',
                'license': '许可证'
            },
            'ca': {
                'title': 'Lumessora',
                'subtitle': 'Control de brillantor',
                'brightness_label': 'Nivell de brillantor',
                'apply': 'Aplicar',
                'cancel': 'Cancel·lar',
                'success_title': 'Configuració desada',
                'success_message': 'La brillantor s\'aplicarà automàticament en iniciar el sistema.',
                'error_no_display': 'No s\'ha detectat cap monitor',
                'close': 'Tancar',
                'menu': 'Menú',
                'about': 'Quant a Lumessora',
                'about_description': 'Control de brillantor de pantalla per a Essora Linux.\n\nPermet ajustar la brillantor gràficament i desar la configuració perquè s\'apliqui automàticament en iniciar el sistema.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'Llicenciat sota GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'Llicència'
            },
            'hu': {
                'title': 'Lumessora',
                'subtitle': 'Fényerő szabályozás',
                'brightness_label': 'Fényerő szint',
                'apply': 'Alkalmaz',
                'cancel': 'Mégse',
                'success_title': 'Beállítások mentve',
                'success_message': 'A fényerő automatikusan alkalmazva lesz a rendszer indításakor.',
                'error_no_display': 'Nem található monitor',
                'close': 'Bezárás',
                'menu': 'Menü',
                'about': 'A Lumessora-ról',
                'about_description': 'Képernyő fényerő vezérlő az Essora Linuxhoz.\n\nLehetővé teszi a fényerő grafikus beállítását és a konfiguráció mentését, hogy automatikusan alkalmazza a rendszer indulásakor.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'GPL-3.0 licenc alatt',
                'about_website': 'Essora Linux',
                'license': 'Licenc'
            },
            'ar': {
                'title': 'Lumessora',
                'subtitle': 'التحكم في السطوع',
                'brightness_label': 'مستوى السطوع',
                'apply': 'تطبيق',
                'cancel': 'إلغاء',
                'success_title': 'تم حفظ الإعدادات',
                'success_message': 'سيتم تطبيق السطوع تلقائيًا عند بدء تشغيل النظام.',
                'error_no_display': 'لم يتم اكتشاف شاشة',
                'close': 'إغلاق',
                'menu': 'القائمة',
                'about': 'حول Lumessora',
                'about_description': 'أداة التحكم في سطوع الشاشة لـ Essora Linux.\n\nتسمح لك بضبط السطوع بشكل رسومي وحفظ التكوين ليتم تطبيقه تلقائيًا عند بدء تشغيل النظام.',
                'about_copyright': '© 2025 josejp2424',
                'about_license': 'مرخص بموجب GPL-3.0',
                'about_website': 'Essora Linux',
                'license': 'الترخيص'
            }
        }
        
        self.translations = translations.get(lang_code, translations['en'])
        self.set_title(self.translations['title'])
    
    def apply_css(self):
        """Apply custom GNOME-style CSS"""
        css = """
        /* GNOME-style dark theme */
        window {
            background-color: #2d2d2d;
        }
        
        headerbar {
            background: linear-gradient(to bottom, #3c3c3c 0%, #353535 100%);
            border-bottom: 1px solid #1a1a1a;
            box-shadow: inset 0 1px rgba(255, 255, 255, 0.05);
            min-height: 42px;
            padding: 0 6px;
        }
        
        headerbar button {
            background: transparent;
            border: none;
            border-radius: 5px;
            min-height: 32px;
            min-width: 32px;
            padding: 0;
            margin: 0 2px;
            transition: all 200ms ease;
        }
        
        headerbar button:hover {
            background-color: rgba(255, 255, 255, 0.08);
        }
        
        headerbar button:active {
            background-color: rgba(0, 0, 0, 0.2);
        }
        
        headerbar .title {
            color: #ffffff;
            font-weight: 600;
            font-size: 14px;
        }
        
        headerbar .subtitle {
            color: rgba(255, 255, 255, 0.6);
            font-size: 11px;
        }
        
        headerbar image {
            margin: 0;
            padding: 0;
        }
        
        /* Menu popover */
        popover {
            background-color: #353535;
            border: 1px solid #1a1a1a;
            border-radius: 8px;
            padding: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
        }
        
        popover modelbutton {
            background: transparent;
            color: #ffffff;
            border-radius: 4px;
            padding: 8px 12px;
            margin: 2px;
            min-height: 32px;
        }
        
        popover modelbutton:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        /* Main content */
        .main-container {
            background-color: #2d2d2d;
            padding: 30px;
        }
        
        .brightness-box {
            background: linear-gradient(to bottom, #383838 0%, #323232 100%);
            border-radius: 12px;
            border: 1px solid #1a1a1a;
            padding: 28px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }
        
        .brightness-label {
            color: #ffffff;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .brightness-value {
            color: #4a90d9;
            font-size: 32px;
            font-weight: 700;
            font-feature-settings: "tnum";
        }
        
        /* Custom scale */
        scale {
            min-height: 48px;
            margin: 20px 0;
        }
        
        scale trough {
            min-height: 8px;
            border-radius: 4px;
            background: linear-gradient(to bottom, #242424 0%, #2a2a2a 100%);
            border: 1px solid #1a1a1a;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.4);
        }
        
        scale highlight {
            background: linear-gradient(to right, #2e6fa8 0%, #4a90d9 50%, #5ba3ed 100%);
            border-radius: 4px;
            box-shadow: 0 0 8px rgba(74, 144, 217, 0.3);
        }
        
        scale slider {
            min-height: 20px;
            min-width: 20px;
            margin: -6px;
            border-radius: 50%;
            background: linear-gradient(to bottom, #5ba3ed 0%, #4a90d9 100%);
            border: 2px solid #3484d6;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4), 
                        0 0 0 0 rgba(74, 144, 217, 0);
            transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        scale slider:hover {
            background: linear-gradient(to bottom, #6bb4ff 0%, #5ba3ed 100%);
            border-color: #4a90d9;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.5),
                        0 0 0 4px rgba(74, 144, 217, 0.2);
        }
        
        scale slider:active {
            background: linear-gradient(to bottom, #4a90d9 0%, #3484d6 100%);
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.6),
                        0 0 0 6px rgba(74, 144, 217, 0.3);
        }
        
        /* Action buttons */
        .action-button {
            min-height: 38px;
            min-width: 100px;
            border-radius: 6px;
            padding: 0 20px;
            font-weight: 500;
            font-size: 13px;
            transition: all 200ms ease;
        }
        
        .primary-button {
            background: linear-gradient(to bottom, #4a90d9 0%, #3484d6 100%);
            color: #ffffff;
            border: 1px solid #2e6fa8;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3),
                        inset 0 1px rgba(255, 255, 255, 0.1);
        }
        
        .primary-button:hover {
            background: linear-gradient(to bottom, #5ba3ed 0%, #4a90d9 100%);
            border-color: #3484d6;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4),
                        inset 0 1px rgba(255, 255, 255, 0.15);
        }
        
        .primary-button:active {
            background: linear-gradient(to bottom, #3484d6 0%, #2e6fa8 100%);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4),
                        inset 0 1px rgba(0, 0, 0, 0.1);
        }
        
        .secondary-button {
            background: linear-gradient(to bottom, #454545 0%, #3a3a3a 100%);
            color: #ffffff;
            border: 1px solid #2a2a2a;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2),
                        inset 0 1px rgba(255, 255, 255, 0.05);
        }
        
        .secondary-button:hover {
            background: linear-gradient(to bottom, #505050 0%, #454545 100%);
            border-color: #353535;
        }
        
        .secondary-button:active {
            background: linear-gradient(to bottom, #3a3a3a 0%, #2f2f2f 100%);
        }
        
        /* Smooth animations */
        * {
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        }
        """
        
        style_provider = Gtk.CssProvider()
        style_provider.load_from_data(css.encode('utf-8'))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            style_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def create_headerbar(self):
        """Create GNOME-style headerbar with icon and menu"""
        headerbar = Gtk.HeaderBar()
        headerbar.set_show_close_button(False)  
        headerbar.set_title(self.translations['title'])
        headerbar.set_subtitle(self.translations['subtitle'])
        

        if os.path.exists(self.icon_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    self.icon_path, 24, 24, True
                )
                icon_image = Gtk.Image.new_from_pixbuf(pixbuf)
                headerbar.pack_start(icon_image)
            except Exception as e:
                print(f"Error loading icon: {e}")
        

        menu_button = Gtk.MenuButton()
        menu_icon = Gtk.Image.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.BUTTON)
        menu_button.set_image(menu_icon)
        

        popover = Gtk.Popover()
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        

        about_button = Gtk.ModelButton()
        about_button.set_label(self.translations['about'])
        about_button.connect("clicked", self.show_about_dialog)
        vbox.pack_start(about_button, False, True, 0)
        

        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        vbox.pack_start(separator, False, True, 4)
        

        close_button = Gtk.ModelButton()
        close_button.set_label(self.translations['close'])
        close_button.connect("clicked", lambda w: self.destroy())
        vbox.pack_start(close_button, False, True, 0)
        
        popover.add(vbox)
        vbox.show_all() 
        menu_button.set_popover(popover)
        
        headerbar.pack_end(menu_button)
        
        self.set_titlebar(headerbar)
    
    def create_content(self):
        """Create main content"""

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        main_box.get_style_context().add_class("main-container")
        

        brightness_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        brightness_box.get_style_context().add_class("brightness-box")
        

        label = Gtk.Label(label=self.translations['brightness_label'])
        label.set_halign(Gtk.Align.START)
        label.get_style_context().add_class("brightness-label")
        brightness_box.pack_start(label, False, False, 0)
        

        self.value_label = Gtk.Label(label=f"{self.current_brightness}%")
        self.value_label.set_halign(Gtk.Align.START)
        self.value_label.get_style_context().add_class("brightness-value")
        brightness_box.pack_start(self.value_label, False, False, 8)
        

        self.brightness_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 10, 100, 1
        )
        self.brightness_scale.set_value(self.current_brightness)
        self.brightness_scale.set_draw_value(False)
        self.brightness_scale.set_hexpand(True)
        self.brightness_scale.connect("value-changed", self.on_brightness_changed)
        brightness_box.pack_start(self.brightness_scale, True, True, 0)
        
        main_box.pack_start(brightness_box, True, True, 0)
        

        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        button_box.set_halign(Gtk.Align.END)
        button_box.set_margin_top(20)
        

        cancel_button = Gtk.Button(label=self.translations['cancel'])
        cancel_button.get_style_context().add_class("action-button")
        cancel_button.get_style_context().add_class("secondary-button")
        cancel_button.connect("clicked", lambda w: self.destroy())
        button_box.pack_start(cancel_button, False, False, 0)
        

        apply_button = Gtk.Button(label=self.translations['apply'])
        apply_button.get_style_context().add_class("action-button")
        apply_button.get_style_context().add_class("primary-button")
        apply_button.connect("clicked", self.on_apply_clicked)
        button_box.pack_start(apply_button, False, False, 0)
        
        main_box.pack_start(button_box, False, False, 0)
        
        self.add(main_box)
    
    def show_about_dialog(self, button=None):
        """Show About dialog"""
        about = Gtk.AboutDialog()
        about.set_transient_for(self)
        about.set_modal(True)
        
        about.set_program_name("Lumessora")
        about.set_version("1.0")
        about.set_comments(self.translations['about_description'])
        about.set_copyright(self.translations['about_copyright'])
        about.set_license_type(Gtk.License.GPL_3_0)
        about.set_authors(["josejp2424"])
        about.set_website("https://essora.org")
        about.set_website_label(self.translations['about_website'])
        

        if os.path.exists(self.icon_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    self.icon_path, 128, 128, True
                )
                about.set_logo(pixbuf)
            except:
                pass
        
        about.run()
        about.destroy()
    
    def get_display_output(self):
        """Get primary monitor name"""
        try:
            output = subprocess.check_output(
                ["xrandr", "--query"], 
                stderr=subprocess.DEVNULL
            ).decode()
            
            for line in output.split('\n'):
                if ' connected' in line and 'disconnected' not in line:
                    return line.split()[0]
        except:
            pass
        return None
    
    def get_current_brightness(self):
        """Get current brightness"""
        try:
            output = subprocess.check_output(
                ["xrandr", "--verbose"],
                stderr=subprocess.DEVNULL
            ).decode()
            
            for line in output.split('\n'):
                if 'Brightness:' in line:
                    brightness = float(line.split(':')[1].strip())
                    return int(brightness * 100)
        except:
            pass
        return 50
    
    def on_brightness_changed(self, scale):
        """Callback when scale value changes"""
        value = int(scale.get_value())
        self.value_label.set_text(f"{value}%")
        

        brightness_value = value / 100.0
        if brightness_value < 0.1:
            brightness_value = 0.1
        
        try:
            subprocess.run(
                ["xrandr", "--output", self.display_output, "--brightness", str(brightness_value)],
                stderr=subprocess.DEVNULL,
                check=False
            )
        except:
            pass
    
    def on_apply_clicked(self, button):
        """Save configuration"""
        value = int(self.brightness_scale.get_value())
        brightness_value = value / 100.0
        

        script_path = "/usr/local/bin/brightness-control-start"
        script_content = f"""#!/bin/bash
# Lumessora - Brightness Control Startup Script
# Wait for X to be available
sleep 2

# Detect primary monitor
DISPLAY_OUTPUT=$(xrandr --query 2>/dev/null | grep " connected" | grep -v "disconnected" | head -n1 | awk '{{print $1}}')

if [ -n "$DISPLAY_OUTPUT" ]; then
    xrandr --output "$DISPLAY_OUTPUT" --brightness {brightness_value:.2f} 2>/dev/null
fi
"""
        
        try:

            with open("/tmp/brightness-control-start", "w") as f:
                f.write(script_content)
            
            subprocess.run(["pkexec", "sh", "-c", 
                f"cp /tmp/brightness-control-start {script_path} && chmod +x {script_path}"],
                check=True)
            
 
            desktop_src = "/usr/local/brightness-control/brightness-control.desktop"
            desktop_dst = "/etc/xdg/autostart/brightness-control.desktop"
            
            if os.path.exists(desktop_src):
                subprocess.run(["pkexec", "cp", desktop_src, desktop_dst], check=False)
            
            self.show_success_dialog()
        except:
            self.destroy()
    
    def show_success_dialog(self):
        """Show success dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=self.translations['success_title']
        )
        dialog.format_secondary_text(self.translations['success_message'])
        dialog.run()
        dialog.destroy()
        self.destroy()
    
    def show_error_dialog(self, message):
        """Show error dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()
        self.destroy()
    
    def on_close(self, widget, event):
        """Callback when closing window"""
        return False
    
    def on_key_press(self, widget, event):
        """Callback for key events"""
        if event.keyval == Gdk.KEY_Escape:
            self.destroy()
        return False

def main():
    app = BrightnessControl()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
