#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Essora Wbar Control 0.9
# Author: josejp2424 / Essora Linux
# License: GPL3

import os
import sys
import pwd
import shutil
import subprocess
import locale
from pathlib import Path

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk

APP_NAME = 'Essora Wbar Control'
APP_VERSION = '0.9'
ESSORA_GREEN = '#7D9B37'

ICON_PATH = Path('/usr/share/pixmaps/wbar/wbar.svg')
WBARDIR = Path('/usr/share/pixmaps/wbar')
AUTOSTART_TARGET = Path('/etc/xdg/autostart/wbar.desktop')
AUTOSTART_SOURCE = Path('/usr/local/wbar/wbar.desktop')
DEFAULT_CONFIG_SOURCE = Path('/usr/local/wbar/wbar.cfg')
WBAR_BIN = Path('/usr/bin/wbar')

IMAGE_EXTS = ('.png', '.jpg', '.jpeg', '.webp', '.xpm', '.svg')
FONT_EXTS = ('.ttf', '.otf', '.ttc', '.pcf', '.bdf')
FONT_DIRS = [Path('/usr/share/fonts'), Path('/usr/local/share/fonts')]


def get_lang():
    lang = os.environ.get('LANG') or locale.setlocale(locale.LC_CTYPE, None) or 'en'
    lang = lang.lower()

    if lang.startswith('es'):
        return 'es'
    if lang.startswith('ar'):
        return 'ar'
    if lang.startswith('ca'):
        return 'ca'
    if lang.startswith('fr'):
        return 'fr'
    if lang.startswith('it'):
        return 'it'
    if lang.startswith('pt'):
        return 'pt'
    if lang.startswith('hu'):
        return 'hu'
    if lang.startswith('ja') or lang.startswith('jp'):
        return 'ja'
    if lang.startswith('ru'):
        return 'ru'
    if lang.startswith('zh'):
        return 'zh'

    return 'en'


LANG_CODE = get_lang()

STRINGS = {
    'en': {
        'config': 'Configuration',
        'programs': 'Programs',
        'control': 'Startup / Run',
        'save': 'Save',
        'save_restart': 'Save and restart wbar',
        'close': 'Close',
        'appearance': 'Wbar appearance',
        'bar': 'Bar / background',
        'font': 'Font',
        'font_size': 'Font size',
        'position': 'Position',
        'offset': 'Offset',
        'icon_size': 'Icon size',
        'icon_distance': 'Icon distance',
        'zoom': 'Zoom',
        'animation': 'Animation',
        'programs_bar': 'Programs in the bar',
        'add': 'Add',
        'edit': 'Edit',
        'delete': 'Delete',
        'up': '↑ Move up',
        'down': '↓ Move down',
        'launch': 'Launch /usr/bin/wbar',
        'kill': 'Kill wbar',
        'add_startup': 'Add to startup',
        'remove_startup': 'Remove from startup',
        'restore_user': 'Restore user',
        'restore_all': 'Restore all /home',
        'configured_user': 'Configured user',
        'file': 'File',
        'running': 'running',
        'stopped': 'stopped',
        'yes': 'yes',
        'no': 'no',
        'startup': 'startup',
        'saved': 'Configuration saved',
        'save_error': 'Could not save',
        'launched': 'Wbar launched',
        'launched_as': 'Executed as user',
        'launch_error': 'Could not launch wbar',
        'wbar_missing': 'Missing /usr/bin/wbar',
        'startup_added': 'Added to startup',
        'startup_removed': 'Removed from startup',
        'startup_add_error': 'Could not add to startup',
        'startup_remove_error': 'Could not remove from startup',
        'launcher_missing': 'Launcher does not exist',
        'restored': 'Configuration restored',
        'restore_error': 'Could not restore',
        'restored_count': 'Restored',
        'root_required': 'Root required',
        'install_auth': 'Install gksu or pkexec to run this tool as root.',
        'entry_title': 'Wbar entry',
        'icon': 'i: Icon',
        'command': 'c: Command',
        'title': 't: Title',
        'browse': 'Browse',
        'select_icon': 'Select icon',
        'about': 'About',
        'about_text': 'Essora Wbar Control\nAuthor: josejp2424\nFor Essora Linux\nLicense: GPL3',
        'autostart_info': 'The GUI runs as root, but ~/.wbar keeps the real user owner.',
        'control_wbar': 'Wbar control',
    },
    'es': {
        'config': 'Configuración',
        'programs': 'Programas',
        'control': 'Inicio / Ejecutar',
        'save': 'Guardar',
        'save_restart': 'Guardar y reiniciar wbar',
        'close': 'Cerrar',
        'appearance': 'Apariencia de wbar',
        'bar': 'Barra / fondo',
        'font': 'Fuente',
        'font_size': 'Tamaño fuente',
        'position': 'Posición',
        'offset': 'Offset',
        'icon_size': 'Tamaño icono',
        'icon_distance': 'Distancia iconos',
        'zoom': 'Zoom',
        'animation': 'Animación',
        'programs_bar': 'Programas en la barra',
        'add': 'Agregar',
        'edit': 'Editar',
        'delete': 'Eliminar',
        'up': '↑ Subir',
        'down': '↓ Bajar',
        'launch': 'Lanzar /usr/bin/wbar',
        'kill': 'Matar wbar',
        'add_startup': 'Agregar al inicio',
        'remove_startup': 'Quitar del inicio',
        'restore_user': 'Restablecer usuario',
        'restore_all': 'Restablecer todos /home',
        'configured_user': 'Usuario configurado',
        'file': 'Archivo',
        'running': 'encendido',
        'stopped': 'apagado',
        'yes': 'sí',
        'no': 'no',
        'startup': 'inicio',
        'saved': 'Configuración guardada',
        'save_error': 'No se pudo guardar',
        'launched': 'Wbar lanzado',
        'launched_as': 'Ejecutado como usuario',
        'launch_error': 'No se pudo lanzar wbar',
        'wbar_missing': 'No existe /usr/bin/wbar',
        'startup_added': 'Agregado al inicio',
        'startup_removed': 'Quitado del inicio',
        'startup_add_error': 'No se pudo agregar al inicio',
        'startup_remove_error': 'No se pudo quitar del inicio',
        'launcher_missing': 'No existe el lanzador',
        'restored': 'Configuración restablecida',
        'restore_error': 'No se pudo restablecer',
        'restored_count': 'Restablecidos',
        'root_required': 'Se requiere root',
        'install_auth': 'Instalá gksu o pkexec para ejecutar esta herramienta como root.',
        'entry_title': 'Entrada de Wbar',
        'icon': 'i: Icono',
        'command': 'c: Comando',
        'title': 't: Título',
        'browse': 'Buscar',
        'select_icon': 'Seleccionar icono',
        'about': 'Acerca de',
        'about_text': 'Essora Wbar Control\nAutor: josejp2424\nPara Essora Linux\nLicencia: GPL3',
        'autostart_info': 'La GUI corre como root, pero ~/.wbar queda con dueño del usuario real.',
        'control_wbar': 'Control de wbar',
    },
}

for code in ['ar', 'ca', 'fr', 'it', 'pt', 'hu', 'ja', 'ru', 'zh']:
    STRINGS[code] = STRINGS['en'].copy()

STRINGS['fr'].update({
    'config': 'Configuration',
    'programs': 'Programmes',
    'control': 'Démarrage / Exécuter',
    'save': 'Enregistrer',
    'save_restart': 'Enregistrer et redémarrer wbar',
    'close': 'Fermer',
    'about': 'À propos',
    'about_text': 'Essora Wbar Control\nAuteur : josejp2424\nPour Essora Linux\nLicence : GPL3',
})

STRINGS['it'].update({
    'config': 'Configurazione',
    'programs': 'Programmi',
    'control': 'Avvio / Esegui',
    'save': 'Salva',
    'save_restart': 'Salva e riavvia wbar',
    'close': 'Chiudi',
    'about': 'Informazioni',
    'about_text': 'Essora Wbar Control\nAutore: josejp2424\nPer Essora Linux\nLicenza: GPL3',
})

STRINGS['pt'].update({
    'config': 'Configuração',
    'programs': 'Programas',
    'control': 'Início / Executar',
    'save': 'Salvar',
    'save_restart': 'Salvar e reiniciar wbar',
    'close': 'Fechar',
    'about': 'Sobre',
    'about_text': 'Essora Wbar Control\nAutor: josejp2424\nPara Essora Linux\nLicença: GPL3',
})

STRINGS['ru'].update({
    'config': 'Настройки',
    'programs': 'Программы',
    'control': 'Автозапуск / Запуск',
    'save': 'Сохранить',
    'save_restart': 'Сохранить и перезапустить wbar',
    'close': 'Закрыть',
    'about': 'О программе',
    'about_text': 'Essora Wbar Control\nАвтор: josejp2424\nДля Essora Linux\nЛицензия: GPL3',
})

STRINGS['zh'].update({
    'config': '配置',
    'programs': '程序',
    'control': '启动 / 运行',
    'save': '保存',
    'save_restart': '保存并重启 wbar',
    'close': '关闭',
    'about': '关于',
    'about_text': 'Essora Wbar Control\n作者: josejp2424\n用于 Essora Linux\n许可证: GPL3',
})


def tr(key):
    return STRINGS.get(LANG_CODE, STRINGS['en']).get(key, key)


CSS = f'''
window {{ background: #252b34; color: #f2f2f2; }}
.header {{ background: #2c333d; border-bottom: 1px solid #414956; padding: 10px; }}
.header-title {{ font-weight: bold; font-size: 15px; }}
.header-subtitle {{ color: #aeb6c3; font-size: 12px; }}
.card {{ background: #2b2b2b; border: 1px solid #454545; border-radius: 8px; padding: 12px; }}
button {{ background: #3a3a3a; color: #f5f5f5; border-radius: 6px; padding: 7px 10px; border: 1px solid #555; }}
button:hover {{ background: #484848; }}
button.suggested-action {{ background: {ESSORA_GREEN}; color: white; border-color: #8faf45; }}
button.destructive-action {{ background: #a43a3a; color: white; border-color: #c14b4b; }}
entry, spinbutton, combobox, treeview {{ background: #1f1f1f; color: #ffffff; border-color: #464646; }}
treeview.view:selected, treeview.view:selected:focus {{
    background-color: {ESSORA_GREEN};
    color: #ffffff;
}}
treeview.view row:selected, treeview.view row:selected:focus {{
    background-color: {ESSORA_GREEN};
    color: #ffffff;
}}
treeview.view row:hover {{
    background-color: #354322;
}}
notebook tab {{ background: #2b2b2b; padding: 8px 18px; }}
notebook tab:checked {{ background: #333333; border-bottom: 3px solid {ESSORA_GREEN}; }}
'''

DEFAULT_CONFIG = '''i: /usr/share/pixmaps/wbar/wbar.svg
c: /usr/bin/wbar --bpress --above-desk --pos bottom --offset 0 --isize 38 --idist 8 --zoomf 1.6 --nanim 3
t: /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf/10

i: /usr/share/pixmaps/wbar/wbar.svg
c: /usr/local/bin/essora-wbar-control
t: Essora Wbar Control
'''


def safe_run(cmd, **kw):
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw)


def find_real_user():
    sudo_user = os.environ.get('SUDO_USER')
    if sudo_user and sudo_user != 'root':
        return sudo_user

    pk_uid = os.environ.get('PKEXEC_UID')
    if pk_uid and pk_uid.isdigit():
        try:
            return pwd.getpwuid(int(pk_uid)).pw_name
        except Exception:
            pass

    try:
        logname = safe_run(['logname']).stdout.strip()
        if logname and logname != 'root':
            return logname
    except Exception:
        pass

    for p in pwd.getpwall():
        if p.pw_uid >= 1000 and p.pw_dir.startswith('/home/') and Path(p.pw_dir).is_dir():
            return p.pw_name

    return os.environ.get('USER', 'root')


def elevate_if_needed():
    if os.geteuid() == 0:
        return

    me = str(Path(__file__).resolve())
    env = os.environ.copy()
    display = env.get('DISPLAY', ':0')
    xauth = env.get('XAUTHORITY', str(Path.home() / '.Xauthority'))

    if shutil.which('gksu'):
        os.execlp('gksu', 'gksu', me, *sys.argv[1:])

    if shutil.which('pkexec'):
        os.execlp(
            'pkexec',
            'pkexec',
            'env',
            f'DISPLAY={display}',
            f'XAUTHORITY={xauth}',
            me,
            *sys.argv[1:]
        )

    dlg = Gtk.MessageDialog(
        message_type=Gtk.MessageType.ERROR,
        buttons=Gtk.ButtonsType.OK,
        text=tr('root_required')
    )
    dlg.format_secondary_text(tr('install_auth'))
    dlg.run()
    dlg.destroy()
    sys.exit(1)


def user_info(user):
    p = pwd.getpwnam(user)
    return Path(p.pw_dir), p.pw_uid, p.pw_gid


def split_blocks(text):
    blocks, cur = [], []
    for line in text.splitlines():
        if line.strip() == '':
            if cur:
                blocks.append(cur)
                cur = []
        else:
            cur.append(line.rstrip())
    if cur:
        blocks.append(cur)
    return blocks


def block_to_dict(block):
    d = {'i': '', 'c': '', 't': ''}
    for line in block:
        s = line.strip()
        if s.startswith('i:'):
            d['i'] = s[2:].strip()
        elif s.startswith('c:'):
            d['c'] = s[2:].strip()
        elif s.startswith('t:'):
            d['t'] = s[2:].strip()
    return d


def parse_config(path):
    if not path.exists():
        return block_to_dict(split_blocks(DEFAULT_CONFIG)[0]), [
            block_to_dict(b) for b in split_blocks(DEFAULT_CONFIG)[1:]
        ]

    text = path.read_text(errors='ignore')
    blocks = [block_to_dict(b) for b in split_blocks(text)]

    if not blocks:
        return block_to_dict(split_blocks(DEFAULT_CONFIG)[0]), []

    return blocks[0], blocks[1:]


def config_to_text(settings, entries):
    out = []
    for d in [settings] + entries:
        out.append(f"i: {d.get('i', '')}")
        out.append(f"c: {d.get('c', '')}")
        out.append(f"t: {d.get('t', '')}")
        out.append('')
    return '\n'.join(out)


def list_images():
    if not WBARDIR.exists():
        return []
    return [
        str(p) for p in sorted(WBARDIR.iterdir())
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS
    ]


def list_fonts():
    fonts = []
    for base in FONT_DIRS:
        if base.exists():
            try:
                for p in base.rglob('*'):
                    if p.is_file() and p.suffix.lower() in FONT_EXTS:
                        fonts.append(str(p))
            except Exception:
                pass
    return sorted(fonts)


def extract_arg(cmd, key, default=''):
    parts = cmd.split()
    try:
        i = parts.index(key)
        return parts[i + 1]
    except Exception:
        return default


def build_wbar_command(pos, offset, isize, idist, zoomf, nanim):
    return (
        f'/usr/bin/wbar --bpress --above-desk --pos {pos} '
        f'--offset {offset} --isize {isize} --idist {idist} '
        f'--zoomf {zoomf} --nanim {nanim}'
    )


class EntryDialog(Gtk.Dialog):
    def __init__(self, parent, data=None):
        super().__init__(title=tr('entry_title'), transient_for=parent, flags=0)
        self.set_default_size(620, 260)
        self.add_buttons(
            Gtk.STOCK_CANCEL,
            Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE,
            Gtk.ResponseType.OK
        )

        data = data or {
            'i': '/usr/share/pixmaps/wbar/wbar.svg',
            'c': '/usr/local/bin/essora-wbar-control',
            't': 'Essora Wbar Control'
        }

        area = self.get_content_area()
        area.set_border_width(12)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        area.add(grid)

        self.icon_entry = Gtk.Entry(text=data.get('i', ''))
        self.cmd_entry = Gtk.Entry(text=data.get('c', ''))
        self.title_entry = Gtk.Entry(text=data.get('t', ''))

        rows = [
            (tr('icon'), self.icon_entry, True),
            (tr('command'), self.cmd_entry, False),
            (tr('title'), self.title_entry, False)
        ]

        for row, (label, entry, browse) in enumerate(rows):
            grid.attach(Gtk.Label(label=label, xalign=0), 0, row, 1, 1)
            grid.attach(entry, 1, row, 1, 1)

            if browse:
                btn = Gtk.Button(label=tr('browse'))
                btn.connect('clicked', self.on_browse_icon)
                grid.attach(btn, 2, row, 1, 1)

        self.show_all()

    def on_browse_icon(self, *args):
        dlg = Gtk.FileChooserDialog(
            title=tr('select_icon'),
            transient_for=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dlg.add_buttons(
            Gtk.STOCK_CANCEL,
            Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN,
            Gtk.ResponseType.OK
        )

        if Path(self.icon_entry.get_text()).exists():
            dlg.set_filename(self.icon_entry.get_text())
        elif WBARDIR.exists():
            dlg.set_current_folder(str(WBARDIR))

        if dlg.run() == Gtk.ResponseType.OK:
            self.icon_entry.set_text(dlg.get_filename())

        dlg.destroy()

    def get_data(self):
        return {
            'i': self.icon_entry.get_text().strip(),
            'c': self.cmd_entry.get_text().strip(),
            't': self.title_entry.get_text().strip()
        }


class MainWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_NAME)

        self.real_user = find_real_user()
        self.home, self.uid, self.gid = user_info(self.real_user)
        self.user_config = self.home / '.wbar'

        self.settings, self.entries = parse_config(self.user_config)

        self.set_default_size(900, 600)
        self.set_position(Gtk.WindowPosition.CENTER)

        if ICON_PATH.exists():
            self.set_icon_from_file(str(ICON_PATH))

        self.connect('destroy', Gtk.main_quit)

        self.build_ui()
        self.refresh_status()

    def build_ui(self):
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS.encode())

        Gtk.StyleContext.add_provider_for_screen(
            self.get_screen(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(main)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class('header')
        main.pack_start(header, False, False, 0)

        img = Gtk.Image()
        if ICON_PATH.exists():
            img.set_from_file(str(ICON_PATH))
        img.set_pixel_size(72)
        header.pack_start(img, False, False, 0)

        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)

        title = Gtk.Label(label=f'{APP_NAME}  {APP_VERSION}', xalign=0)
        title.get_style_context().add_class('header-title')

        subtitle = Gtk.Label(
            label=f'{tr("configured_user")}: {self.real_user}    {tr("file")}: {self.user_config}',
            xalign=0
        )
        subtitle.get_style_context().add_class('header-subtitle')

        titles.pack_start(title, False, False, 0)
        titles.pack_start(subtitle, False, False, 0)
        header.pack_start(titles, True, True, 0)

        about_label = Gtk.Label()
        about_label.set_markup(
            f'<span foreground="{ESSORA_GREEN}" underline="single">{tr("about")}</span>'
        )
        about_label.set_xalign(1)

        about_event = Gtk.EventBox()
        about_event.add(about_label)
        about_event.set_tooltip_text(tr('about'))
        about_event.connect('button-press-event', self.on_about)

        header.pack_start(about_event, False, False, 0)

        self.status_label = Gtk.Label(label='', xalign=1)
        self.status_label.get_style_context().add_class('header-subtitle')
        header.pack_start(self.status_label, False, False, 0)

        self.nb = Gtk.Notebook()
        main.pack_start(self.nb, True, True, 0)

        self.build_config_tab()
        self.build_programs_tab()
        self.build_control_tab()

        bottom = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        bottom.set_border_width(12)
        main.pack_start(bottom, False, False, 0)

        save = Gtk.Button(label=tr('save'))
        save.get_style_context().add_class('suggested-action')
        save.connect('clicked', self.on_save)

        restart = Gtk.Button(label=tr('save_restart'))
        restart.connect('clicked', self.on_save_restart)

        close = Gtk.Button(label=tr('close'))
        close.get_style_context().add_class('destructive-action')
        close.connect('clicked', lambda *args: Gtk.main_quit())

        bottom.pack_start(save, True, True, 0)
        bottom.pack_start(restart, True, True, 0)
        bottom.pack_start(close, True, True, 0)

    def add_card(self, parent):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.set_border_width(12)
        card.get_style_context().add_class('card')
        parent.pack_start(card, False, False, 14)
        return card

    def build_config_tab(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.nb.append_page(box, Gtk.Label(label=tr('config')))

        card = self.add_card(box)
        st = self.settings
        cmd = st.get('c', '')

        card.pack_start(Gtk.Label(label=tr('appearance'), xalign=0), False, False, 0)

        grid = Gtk.Grid(column_spacing=10, row_spacing=8)
        card.pack_start(grid, False, False, 0)

        self.skin_combo = Gtk.ComboBoxText()
        images = list_images()
        for p in images:
            self.skin_combo.append_text(p)

        cur_img = st.get('i') or (images[0] if images else '')
        if cur_img in images:
            self.skin_combo.set_active(images.index(cur_img))
        elif images:
            self.skin_combo.set_active(0)

        self.font_combo = Gtk.ComboBoxText()
        fonts = list_fonts()
        cur_font = st.get('t', '')

        for f in fonts:
            self.font_combo.append_text(f)

        font_path = cur_font.rsplit('/', 1)[0] if '/' in cur_font else cur_font
        if font_path in fonts:
            self.font_combo.set_active(fonts.index(font_path))
        elif fonts:
            self.font_combo.set_active(0)

        self.font_size = Gtk.SpinButton.new_with_range(6, 32, 1)

        size = 10
        try:
            size = int(cur_font.rsplit('/', 1)[1])
        except Exception:
            pass

        self.font_size.set_value(size)

        positions = [
            'bottom',
            'top',
            'left',
            'right',
            'bottom-left',
            'bottom-right',
            'top-left',
            'top-right'
        ]

        self.pos_combo = Gtk.ComboBoxText()
        for pos in positions:
            self.pos_combo.append_text(pos)

        pos = extract_arg(cmd, '--pos', 'bottom')
        self.pos_combo.set_active(positions.index(pos) if pos in positions else 0)

        self.offset = Gtk.SpinButton.new_with_range(0, 500, 1)
        self.offset.set_value(int(float(extract_arg(cmd, '--offset', '0') or 0)))

        self.isize = Gtk.SpinButton.new_with_range(16, 128, 1)
        self.isize.set_value(int(float(extract_arg(cmd, '--isize', '38') or 38)))

        self.idist = Gtk.SpinButton.new_with_range(0, 64, 1)
        self.idist.set_value(int(float(extract_arg(cmd, '--idist', '8') or 8)))

        self.zoomf = Gtk.SpinButton.new_with_range(1.0, 4.0, 0.1)
        self.zoomf.set_digits(1)
        self.zoomf.set_value(
            float((extract_arg(cmd, '--zoomf', '1.6') or '1.6').replace(',', '.'))
        )

        self.nanim = Gtk.SpinButton.new_with_range(0, 10, 1)
        self.nanim.set_value(int(float(extract_arg(cmd, '--nanim', '3') or 3)))

        rows = [
            (tr('bar'), self.skin_combo),
            (tr('font'), self.font_combo),
            (tr('font_size'), self.font_size),
            (tr('position'), self.pos_combo),
            (tr('offset'), self.offset),
            (tr('icon_size'), self.isize),
            (tr('icon_distance'), self.idist),
            (tr('zoom'), self.zoomf),
            (tr('animation'), self.nanim),
        ]

        for i, (lab, wid) in enumerate(rows):
            grid.attach(Gtk.Label(label=lab, xalign=0), 0, i, 1, 1)
            grid.attach(wid, 1, i, 1, 1)

    def build_programs_tab(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.nb.append_page(box, Gtk.Label(label=tr('programs')))

        card = self.add_card(box)
        card.pack_start(Gtk.Label(label=tr('programs_bar'), xalign=0), False, False, 0)

        self.store = Gtk.ListStore(str, str, str)
        self.tree = Gtk.TreeView(model=self.store)
        self.tree.set_headers_visible(True)
        self.tree.get_selection().set_mode(Gtk.SelectionMode.SINGLE)

        for idx, name in enumerate([tr('icon'), tr('command'), tr('title')]):
            rend = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(name, rend, text=idx)
            col.set_resizable(True)
            self.tree.append_column(col)

        sc = Gtk.ScrolledWindow()
        sc.set_min_content_height(260)
        sc.add(self.tree)
        card.pack_start(sc, True, True, 0)

        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        card.pack_start(btns, False, False, 0)

        buttons = [
            (tr('add'), self.on_add),
            (tr('edit'), self.on_edit),
            (tr('delete'), self.on_delete),
            (tr('up'), self.on_up),
            (tr('down'), self.on_down),
        ]

        for label, cb in buttons:
            b = Gtk.Button(label=label)
            b.connect('clicked', cb)
            btns.pack_start(b, False, False, 0)

        self.reload_store()

    def build_control_tab(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.nb.append_page(box, Gtk.Label(label=tr('control')))

        card = self.add_card(box)
        card.pack_start(Gtk.Label(label=tr('control_wbar'), xalign=0), False, False, 0)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        card.pack_start(grid, False, False, 0)

        actions = [
            (tr('launch'), self.on_launch),
            (tr('kill'), self.on_kill),
            (tr('add_startup'), self.on_add_autostart),
            (tr('remove_startup'), self.on_remove_autostart),
            (tr('restore_user'), self.on_restore_user),
            (tr('restore_all'), self.on_restore_all),
        ]

        for n, (label, cb) in enumerate(actions):
            b = Gtk.Button(label=label)
            b.connect('clicked', cb)
            grid.attach(b, n % 2, n // 2, 1, 1)

        info = Gtk.Label(
            label=f'Autostart: {AUTOSTART_SOURCE}  →  {AUTOSTART_TARGET}\n{tr("autostart_info")}',
            xalign=0
        )
        card.pack_start(info, False, False, 10)

    def reload_store(self):
        self.store.clear()
        for e in self.entries:
            self.store.append([e.get('i', ''), e.get('c', ''), e.get('t', '')])

    def store_to_entries(self):
        self.entries = [
            {'i': row[0], 'c': row[1], 't': row[2]}
            for row in self.store
        ]

    def collect_settings(self):
        skin = self.skin_combo.get_active_text() or self.settings.get('i', '')
        font = self.font_combo.get_active_text() or '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
        font_t = f'{font}/{int(self.font_size.get_value())}'
        pos = self.pos_combo.get_active_text() or 'bottom'

        cmd = build_wbar_command(
            pos,
            int(self.offset.get_value()),
            int(self.isize.get_value()),
            int(self.idist.get_value()),
            round(float(self.zoomf.get_value()), 1),
            int(self.nanim.get_value())
        )

        return {'i': skin, 'c': cmd, 't': font_t}

    def write_user_config(self):
        self.store_to_entries()
        self.settings = self.collect_settings()
        text = config_to_text(self.settings, self.entries)

        self.user_config.parent.mkdir(parents=True, exist_ok=True)

        tmp = self.user_config.with_name('.wbar.tmp')
        tmp.write_text(text, encoding='utf-8')
        shutil.move(str(tmp), str(self.user_config))

        os.chown(self.user_config, self.uid, self.gid)
        os.chmod(self.user_config, 0o644)

    def selected_iter(self):
        sel = self.tree.get_selection()
        model, it = sel.get_selected()
        return it

    def on_add(self, *args):
        dlg = EntryDialog(self)

        if dlg.run() == Gtk.ResponseType.OK:
            d = dlg.get_data()
            self.store.append([d['i'], d['c'], d['t']])

        dlg.destroy()

    def on_edit(self, *args):
        it = self.selected_iter()
        if not it:
            return

        d = {
            'i': self.store[it][0],
            'c': self.store[it][1],
            't': self.store[it][2],
        }

        dlg = EntryDialog(self, d)

        if dlg.run() == Gtk.ResponseType.OK:
            nd = dlg.get_data()
            self.store[it] = [nd['i'], nd['c'], nd['t']]

        dlg.destroy()

    def on_delete(self, *args):
        it = self.selected_iter()
        if it:
            self.store.remove(it)

    def keep_selected_visible(self, it):
        if not it:
            return

        path = self.store.get_path(it)
        sel = self.tree.get_selection()
        sel.select_path(path)
        self.tree.set_cursor(path)
        self.tree.scroll_to_cell(path, None, True, 0.5, 0.0)

    def on_up(self, *args):
        it = self.selected_iter()
        if not it:
            return

        idx = self.store.get_path(it).get_indices()[0]

        if idx > 0:
            prev = self.store.get_iter(idx - 1)
            self.store.swap(it, prev)
            self.keep_selected_visible(it)

    def on_down(self, *args):
        it = self.selected_iter()
        if not it:
            return

        idx = self.store.get_path(it).get_indices()[0]

        if idx < len(self.store) - 1:
            nxt = self.store.get_iter(idx + 1)
            self.store.swap(it, nxt)
            self.keep_selected_visible(it)

    def message(self, text, detail=''):
        d = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=text
        )

        if detail:
            d.format_secondary_text(detail)

        d.run()
        d.destroy()
        self.refresh_status()

    def error(self, text, detail=''):
        d = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=text
        )

        if detail:
            d.format_secondary_text(detail)

        d.run()
        d.destroy()

    def on_about(self, widget=None, event=None):
        dlg = Gtk.AboutDialog(transient_for=self, modal=True)

        dlg.set_program_name(APP_NAME)
        dlg.set_version(APP_VERSION)
        dlg.set_comments(tr('about_text'))
        dlg.set_authors(['josejp2424'])
        dlg.set_license_type(Gtk.License.GPL_3_0)
        dlg.set_website('https://sourceforge.net/projects/essora/')

        if ICON_PATH.exists():
            try:
                pix = GdkPixbuf.Pixbuf.new_from_file_at_size(str(ICON_PATH), 96, 96)
                dlg.set_logo(pix)
            except Exception:
                pass

        dlg.run()
        dlg.destroy()

    def on_save(self, *args):
        try:
            self.write_user_config()
            self.message(tr('saved'))
        except Exception as e:
            self.error(tr('save_error'), str(e))

    def on_save_restart(self, *args):
        try:
            self.write_user_config()
            self.on_kill()
            GLib.timeout_add(600, lambda: (self.on_launch(), False)[1])
            self.message(tr('saved'))
        except Exception as e:
            self.error(tr('save_error'), str(e))

    def user_env_cmd(self, base):
        env = ['env']

        for k in ['DISPLAY', 'XAUTHORITY', 'DBUS_SESSION_BUS_ADDRESS', 'XDG_RUNTIME_DIR']:
            v = os.environ.get(k)
            if v:
                env.append(f'{k}={v}')

        if not os.environ.get('XAUTHORITY') and (self.home / '.Xauthority').exists():
            env.append(f'XAUTHORITY={self.home / ".Xauthority"}')

        return ['runuser', '-u', self.real_user, '--'] + env + base

    def on_launch(self, *args):
        try:
            if not WBAR_BIN.exists():
                self.error(tr('wbar_missing'))
                return

            subprocess.Popen(
                self.user_env_cmd([str(WBAR_BIN)]),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

            self.message(tr('launched'), f'{tr("launched_as")}: {self.real_user}')

        except Exception as e:
            self.error(tr('launch_error'), str(e))

    def on_kill(self, *args):
        safe_run(['pkill', '-u', self.real_user, '-x', 'wbar'])
        self.refresh_status()

    def on_add_autostart(self, *args):
        try:
            if not AUTOSTART_SOURCE.exists():
                self.error(tr('launcher_missing'), str(AUTOSTART_SOURCE))
                return

            AUTOSTART_TARGET.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(AUTOSTART_SOURCE, AUTOSTART_TARGET)

            os.chown(AUTOSTART_TARGET, 0, 0)
            os.chmod(AUTOSTART_TARGET, 0o644)

            self.message(tr('startup_added'))

        except Exception as e:
            self.error(tr('startup_add_error'), str(e))

    def on_remove_autostart(self, *args):
        try:
            if AUTOSTART_TARGET.exists() or AUTOSTART_TARGET.is_symlink():
                AUTOSTART_TARGET.unlink()

            self.message(tr('startup_removed'))

        except Exception as e:
            self.error(tr('startup_remove_error'), str(e))

    def restore_to_user(self, user):
        home, uid, gid = user_info(user)
        dst = home / '.wbar'
        src = DEFAULT_CONFIG_SOURCE

        if not src.exists():
            src.parent.mkdir(parents=True, exist_ok=True)
            src.write_text(DEFAULT_CONFIG, encoding='utf-8')
            os.chown(src, 0, 0)
            os.chmod(src, 0o644)

        shutil.copy2(src, dst)
        os.chown(dst, uid, gid)
        os.chmod(dst, 0o644)

    def on_restore_user(self, *args):
        try:
            self.restore_to_user(self.real_user)
            self.settings, self.entries = parse_config(self.user_config)
            self.reload_store()
            self.message(tr('restored'), str(self.user_config))

        except Exception as e:
            self.error(tr('restore_error'), str(e))

    def on_restore_all(self, *args):
        ok, fail = 0, []

        for p in pwd.getpwall():
            if p.pw_uid >= 1000 and p.pw_dir.startswith('/home/') and Path(p.pw_dir).is_dir():
                try:
                    self.restore_to_user(p.pw_name)
                    ok += 1
                except Exception as e:
                    fail.append(f'{p.pw_name}: {e}')

        self.message(f'{tr("restored_count")}: {ok}', '\n'.join(fail[:8]))

    def refresh_status(self):
        running = safe_run(['pgrep', '-u', self.real_user, '-x', 'wbar']).returncode == 0
        auto = AUTOSTART_TARGET.exists()

        self.status_label.set_text(
            f'wbar: {tr("running") if running else tr("stopped")}    '
            f'{tr("startup")}: {tr("yes") if auto else tr("no")}'
        )


def main():
    elevate_if_needed()

    win = MainWindow()
    win.show_all()

    Gtk.main()


if __name__ == '__main__':
    main()
