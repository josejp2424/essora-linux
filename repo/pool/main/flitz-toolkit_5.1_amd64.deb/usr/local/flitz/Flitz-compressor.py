#!/usr/bin/env python3
# ------------------------------------------------------------
# Author: josejp2424
# Version: 5.1
# Descripción: Flitz es una herramienta gráfica para comprimir carpetas
# en distintos formatos (tar.gz, tar.xz, zip, 7z, squashfs).
# Utiliza una interfaz gráfica con soporte de arrastrar y soltar.
# ------------------------------------------------------------
# Librerías utilizadas:
# - os
# - sys
# - subprocess
# - shutil
# - tkinter
# - tkinter.ttk
# - tkinter.filedialog
# - tkinter.messagebox
# - tkinter.scrolledtext
# - PIL (Image, ImageTk)
# - gettext
# - locale
# - tkinterdnd2 (TkinterDnD, DND_FILES)
#
# Requiere herramientas externas instaladas según el formato:
# - tar
# - zip
# - 7z
# - mksquashfs
# ------------------------------------------------------------
# License: MIT
#
# -----------------------------------------------------------------------------
# Copyright (c) 2025 josejp2424
#
# This file is part of Oply.
#
# Oply is free software: you can redistribute it and/or modify
# it under the terms of the MIT License as published by
# the Massachusetts Institute of Technology.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------
import os
import sys
import subprocess
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import gettext
import locale

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
except ImportError:
    print("Installing tkinterdnd2...")
    subprocess.run([sys.executable, "-m", "pip", "install", "tkinterdnd2"])
    from tkinterdnd2 import TkinterDnD, DND_FILES

APP_NAME = "flitz"
LOCALE_PATHS = [
    "/usr/share/locale",
    os.path.join(os.path.dirname(__file__), "locale"),
    "/usr/local/share/locale"
]

def setup_translations():
    """Configuración corregida de traducciones"""
    locale.setlocale(locale.LC_ALL, '')
    lang = None
    for loc_dir in LOCALE_PATHS:
        try:
            lang = gettext.translation(APP_NAME, loc_dir, fallback=True)
            print(f"Translations loaded from: {loc_dir}")
            break
        except Exception as e:
            print(f"Failed to load from {loc_dir}: {str(e)}")
    
    if lang is None:
        lang = gettext.NullTranslations()
    
    lang.install()
    return lang.gettext
_ = setup_translations()
# ==============================================

ICON_PATH = "/usr/local/flitz/Flitz.png"

FORMATS = ["tar.gz", "tar.xz", "zip", "7z", "squashfs"]
SQUASH_COMPRESSION = ["gzip", "xz", "lz4", "zstd"]
SQUASH_BLOCKS = ["4k", "16k", "32k", "64k", "128k", "256k", "512k", "1m", "1024k"]
XZ_FILTERS = ["None", "x86", "powerpc", "ia64", "arm", "armthumb"]

class ProgressParser:
    @staticmethod
    def parse_tar_progress(line):
        if "%" in line:
            return int(line.split("%")[0].split()[-1])
        return None

    @staticmethod
    def parse_7z_progress(line):
        if "%" in line:
            return int(line.split("%")[0].split()[-1])
        return None

    @staticmethod
    def parse_squashfs_progress(line):
        if "Progress:" in line:
            return int(line.split("Progress:")[1].split("%")[0].strip())
        return None

class FlitzApp:
    def __init__(self, root, initial_path=None):
        self.root = root
        self.root.title(_("Flitz Compressor"))
        
        # Center window
        window_width = 450
        window_height = 640
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.resizable(False, False)
        
        self.source_path = tk.StringVar(value=initial_path or "")
        self.format = tk.StringVar(value="tar.gz")
        self.compression = tk.StringVar(value="xz")
        self.block_size = tk.StringVar(value="128k")
        self.xz_filter = tk.StringVar(value="None")
        self.output_name = tk.StringVar()
        self.output_dir = tk.StringVar()
        
        # Progress tracking
        self.progress_var = tk.DoubleVar()
        self.progress_label = tk.StringVar(value=_("Ready"))
        
        self._build_ui()

        if initial_path:
            self._load_directory(initial_path)

    def _build_ui(self):
        main_frame = ttk.Frame(self.root, padding="3")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Configure drag and drop
        self.root.drop_target_register(DND_FILES)
        self.root.dnd_bind('<<Drop>>', self._on_drop)
        
        top_frame = ttk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=2)
        
        try:
            img = Image.open(ICON_PATH)
            img = img.resize((48, 48), Image.LANCZOS)
            self.tk_img = ImageTk.PhotoImage(img)
            icon_label = ttk.Label(top_frame, image=self.tk_img)
            icon_label.pack(side=tk.LEFT, padx=3)
        except:
            ttk.Label(top_frame, text="Flitz", font=("Helvetica", 9)).pack(side=tk.LEFT)
        
        title_frame = ttk.Frame(top_frame)
        title_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(title_frame, text=_("Flitz Compressor"), 
                font=("Helvetica", 10, "bold")).pack(anchor=tk.W)
        ttk.Label(title_frame, text="by josejp2424 (v5.1)", 
                font=("Helvetica", 7)).pack(anchor=tk.W)
        
        # Source selection
        file_frame = ttk.LabelFrame(main_frame, text=_("Source"), padding=3)
        file_frame.pack(fill=tk.X, pady=2)
        
        ttk.Button(file_frame, text=_("Select"), 
                  command=self._select_source, width=10).pack(side=tk.LEFT, padx=2)
        
        self.file_label = ttk.Label(file_frame, text=_("Drag folder here or click Select"), 
                                  font=("Helvetica", 8), wraplength=250)
        self.file_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.file_label.drop_target_register(DND_FILES)
        self.file_label.dnd_bind('<<Drop>>', self._on_drop)
        
        # Format selection
        format_frame = ttk.LabelFrame(main_frame, text=_("Format"), padding=3)
        format_frame.pack(fill=tk.X, pady=2)
        ttk.Combobox(format_frame, textvariable=self.format, 
                    values=FORMATS, state="readonly", width=15).pack(side=tk.LEFT, padx=2)
        self.format.trace("w", lambda *args: self._update_fields())
        
        # SquashFS options
        self.squash_frame = ttk.LabelFrame(main_frame, text=_("SquashFS Options"), padding=3)
        ttk.Label(self.squash_frame, text=_("Compression:")).pack(side=tk.LEFT, padx=2)
        ttk.Combobox(self.squash_frame, textvariable=self.compression, 
                     values=SQUASH_COMPRESSION, state="readonly", width=8).pack(side=tk.LEFT, padx=2)
        ttk.Label(self.squash_frame, text=_("Block size:")).pack(side=tk.LEFT, padx=2)
        ttk.Combobox(self.squash_frame, textvariable=self.block_size, 
                     values=SQUASH_BLOCKS, state="readonly", width=8).pack(side=tk.LEFT, padx=2)
        
        # XZ advanced options
        self.xz_frame = ttk.LabelFrame(main_frame, text=_("Advanced XZ Options"), padding=3)
        ttk.Label(self.xz_frame, text=_("BCJ Filter:")).pack(side=tk.LEFT, padx=2)
        ttk.Combobox(self.xz_frame, textvariable=self.xz_filter, 
                     values=XZ_FILTERS, state="readonly", width=10).pack(side=tk.LEFT, padx=2)
        
        # Output directory
        dir_frame = ttk.LabelFrame(main_frame, text=_("Output Directory"), padding=3)
        dir_frame.pack(fill=tk.X, pady=2)
        ttk.Button(dir_frame, text=_("Select"), 
                 command=self._select_output_dir, width=10).pack(side=tk.LEFT, padx=2)
        self.dir_label = ttk.Label(dir_frame, text=_("Default: source folder"), 
                                 font=("Helvetica", 8), wraplength=250)
        self.dir_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Output filename
        output_frame = ttk.LabelFrame(main_frame, text=_("Output Filename"), padding=3)
        output_frame.pack(fill=tk.X, pady=2)
        self.output_entry = ttk.Entry(output_frame, textvariable=self.output_name)
        self.output_entry.pack(fill=tk.X, padx=2)
        
        # Progress bar
        progress_frame = ttk.Frame(main_frame)
        progress_frame.pack(fill=tk.X, pady=2)
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, expand=True)
        ttk.Label(progress_frame, textvariable=self.progress_label).pack()
        
        # Console
        console_frame = ttk.LabelFrame(main_frame, text=_("Console"), padding=2)
        console_frame.pack(fill=tk.BOTH, expand=True, pady=2)
        self.console = scrolledtext.ScrolledText(console_frame, height=6, 
                                              wrap=tk.WORD, font=("Courier", 8))
        self.console.pack(fill=tk.BOTH, expand=True, padx=2, pady=(0,2))
        
        # Compress button
        ttk.Button(main_frame, text=_("Compress"), 
                 command=self._compress).pack(pady=3, ipadx=10, ipady=1)
        
        self._update_fields()

    def _on_drop(self, event):
        files = event.data.strip('{}').split()
        if files and os.path.isdir(files[0]):
            self._load_directory(files[0])
        else:
            messagebox.showwarning(_("Warning"), _("Please drag only folders"))

    def _load_directory(self, path):
        self.source_path.set(path)
        short_name = os.path.basename(path)
        if len(short_name) > 20:
            short_name = "..." + short_name[-17:]
        self.file_label.config(text=short_name)
        self.output_dir.set(os.path.dirname(path))
        self.dir_label.config(text=f"{_('Output')}: {os.path.dirname(path)}")
        self._suggest_name()

    def _select_source(self):
        if path := filedialog.askdirectory(title=_("Select folder to compress")):
            self._load_directory(path)

    def _select_output_dir(self):
        if path := filedialog.askdirectory(title=_("Select output directory")):
            self.output_dir.set(path)
            self.dir_label.config(text=f"{_('Output')}: {path}")

    def _suggest_name(self):
        base = os.path.basename(self.source_path.get().rstrip("/"))
        ext = self.format.get()
        self.output_name.set(f"{base}.{ext}" if ext != "squashfs" else f"{base}.sfs")

    def _update_fields(self):
        show_squash = self.format.get() == "squashfs"
        self.squash_frame.pack(fill=tk.X, pady=2) if show_squash else self.squash_frame.pack_forget()
        self.xz_frame.pack(fill=tk.X, pady=2) if show_squash and self.compression.get() == "xz" else self.xz_frame.pack_forget()
        self._suggest_name()

    def _write_console(self, text):
        self.console.insert(tk.END, text + "\n")
        self.console.see(tk.END)
        self.root.update()

    def _update_progress(self, percent, message):
        self.progress_var.set(percent)
        self.progress_label.set(message)
        self.root.update()

    def _compress(self):
        self.console.delete(1.0, tk.END)
        self._update_progress(0, _("Starting compression..."))
        
        source = self.source_path.get()
        output_name = self.output_name.get()
        output_dir = self.output_dir.get() or os.path.dirname(source)
        format = self.format.get()

        if not all([source, output_name]):
            messagebox.showerror(_("Error"), _("Missing data."))
            return

        output = os.path.join(output_dir, output_name)
        cmd = []
        parser = None

        if format == "tar.gz":
            cmd = ["tar", "-czf", output, "-C", os.path.dirname(source), os.path.basename(source)]
            parser = ProgressParser.parse_tar_progress
        elif format == "tar.xz":
            cmd = ["tar", "-cJf", output, "-C", os.path.dirname(source), os.path.basename(source)]
            parser = ProgressParser.parse_tar_progress
        elif format == "zip":
            cmd = ["zip", "-r", output, os.path.basename(source)]
            os.chdir(os.path.dirname(source))
        elif format == "7z":
            cmd = ["7z", "a", "-bsp1", output, source]
            parser = ProgressParser.parse_7z_progress
        elif format == "squashfs":
            if not (mksq := shutil.which("mksquashfs")):
                messagebox.showerror(_("Error"), _("mksquashfs is not installed."))
                return
            cmd = [mksq, source, output, "-noappend", "-comp", self.compression.get(), 
                  "-b", self.block_size.get(), "-progress"]
            if self.compression.get() == "xz" and self.xz_filter.get() != "None":
                cmd.extend(["-Xbcj", self.xz_filter.get()])
            parser = ProgressParser.parse_squashfs_progress

        if not cmd:
            messagebox.showerror(_("Error"), _("Format not supported"))
            return
            
        if not shutil.which(cmd[0]):
            messagebox.showerror(_("Error"), _("Tool '{}' is not installed.").format(cmd[0]))
            return

        self._write_console(_("Running: ") + " ".join(cmd))
        
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
                                     universal_newlines=True, bufsize=1)
            
            for line in process.stdout:
                self._write_console(line.strip())
                if parser and (percent := parser(line)):
                    self._update_progress(percent, f"{percent}% {_('completed')}")
            
            process.wait()
            if process.returncode == 0:
                self._update_progress(100, _("Completed successfully"))
                self._write_console("✅ " + _("Completed successfully."))
                messagebox.showinfo(_("Success"), _("File created:\n{}").format(output))
            else:
                self._update_progress(0, _("Compression failed"))
                self._write_console("❌ " + _("Error during compression."))
        except Exception as e:
            self._update_progress(0, _("Error occurred"))
            self._write_console(f"❌ {_('Error')}: {e}")

if __name__ == "__main__":
    try:
        from PIL import Image, ImageTk
    except ImportError:
        print(_("Installing dependencies..."))
        subprocess.run([sys.executable, "-m", "pip", "install", "pillow"])
    
    root = TkinterDnD.Tk() 
    style = ttk.Style()
    style.theme_use("clam")
    
    try:
        img = Image.open(ICON_PATH)
        photo = ImageTk.PhotoImage(img)
        root.iconphoto(True, photo)
    except:
        pass
    
    path = None
    if len(sys.argv) > 1:
        path = sys.argv[1]
        if os.path.exists(path):
            path = path if os.path.isdir(path) else os.path.dirname(path)
    
    app = FlitzApp(root, path)
    root.mainloop()
