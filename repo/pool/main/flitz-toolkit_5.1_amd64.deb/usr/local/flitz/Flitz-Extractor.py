#!/usr/bin/env python3
# ------------------------------------------------------------
# Flitz - Universal File Extractor (Versión Internacionalizada)
# Author: josejp2424
# Version: 5.1
# ------------------------------------------------------------
# Dependencies:
#   - Standard Library:
#     * os, sys, subprocess, threading, tempfile, shutil, locale
#     * tkinter (ttk, filedialog, messagebox, scrolledtext)
#     * argparse, tarfile, zipfile, gettext
#   - External:
#     * Pillow (PIL) - Python Imaging Library
#     * tkinterdnd2 - Drag and drop for Tkinter
#   - System Tools (optional):
#     * p7zip, unrar, unar, cabextract, rpm-tools, cpio
#     * dmg2img, innoextract, msitools, binutils
#     * squashfs-tools, zstd
# ------------------------------------------------------------
# Features:
#   - Supports multiple archive formats (ZIP, TAR, RAR, 7z, etc.)
#   - Handles compressed tar files (gz, bz2, xz)
#   - Extracts special formats (DEB, RPM, DMG, ISO, MSI, etc.)
#   - Multi-language support with gettext
#   - Drag and drop functionality
#   - Both GUI and command-line interfaces
# ------------------------------------------------------------
# License: MIT
#
# -----------------------------------------------------------------------------
# Copyright (c) 2025 josejp2424
#
# This file is part of Oply.
#
# Oply is free software: you can redistribute it and/or modify
# it under the terms of the MIT License as published by
# the Massachusetts Institute of Technology.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------
import os
import sys
import subprocess
import threading
import tarfile
import zipfile
import tempfile
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import gettext
import locale
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
except ImportError:
    print("tkinterdnd2 is not installed. Install with: pip install tkinterdnd2")
    sys.exit(1)

# Configuración de internacionalización estándar Unix
LOCALE_DIR = "/usr/share/locale"  
APP_NAME = "flitz"  
locale.setlocale(locale.LC_ALL, '')

def parse_args():
    """Parse command line arguments"""
    import argparse
    parser = argparse.ArgumentParser(description='Flitz Universal Extractor')
    parser.add_argument('file', nargs='?', help='File to extract')
    parser.add_argument('-o', '--output', help='Output directory')
    parser.add_argument('-r', '--recursive', action='store_true', help='Recursive extraction')
    parser.add_argument('-k', '--keep-structure', action='store_true', help='Keep directory structure')
    parser.add_argument('-y', '--overwrite', action='store_true', help='Overwrite existing files')
    parser.add_argument('-l', '--language', help='Set language (e.g. es, en)')
    return parser.parse_args()

class FlitzApp:
    def __init__(self, root, language=None):
        self.root = root
        
        # Configurar idioma
        self.set_language(language)
        
        self.root.title(_("Flitz Universal Extractor"))
        
        # 
        self.set_window_icon("/usr/local/flitz/Flitz.png")
            
        # 
        self.center_window()
        
        # 
        self.setup_ui()
        self.file_path = ""
        self.output_dir = ""
        self.supported_formats = self.get_supported_formats()
        self.check_required_tools()
        
        # 
        self.setup_drag_and_drop()
    
    def set_language(self, language=None):
        """Configure language settings using system locale path"""
        lang = language or locale.getlocale()[0] or 'en'
        try:
            # 
            self.trans = gettext.translation(
                APP_NAME,
                LOCALE_DIR,
                languages=[lang],
                fallback=True
            )
        except FileNotFoundError:
            try:
                # 
                local_locale = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'locales')
                self.trans = gettext.translation(
                    APP_NAME,
                    local_locale,
                    languages=[lang],
                    fallback=True
                )
            except FileNotFoundError:
                # 
                self.trans = gettext.NullTranslations()
        
        self.trans.install()
        global _
        _ = self.trans.gettext
        
    def set_window_icon(self, icon_path):
        """Set window icon from specific path"""
        try:
            if os.path.exists(icon_path):
                img = Image.open(icon_path)
                photo = ImageTk.PhotoImage(img)
                self.root.iconphoto(True, photo)
                self.root.tk_img = photo  # Keep reference
                print(_("Icon loaded from: {path}").format(path=icon_path))
            else:
                print(_("Icon not found at: {path}").format(path=icon_path))
        except Exception as e:
            print(_("Could not load icon: {error}").format(error=e))
        
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = 450
        height = 500
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
        
    def setup_drag_and_drop(self):
        """Configure drag and drop functionality"""
        # 
        self.file_label.drop_target_register(DND_FILES)
        self.file_label.dnd_bind('<<Drop>>', self.on_file_drop)
        
        # 
        self.root.drop_target_register(DND_FILES)
        self.root.dnd_bind('<<Drop>>', self.on_file_drop)
        
    def on_file_drop(self, event):
        """Handle file drop event"""
        # 
        file_path = event.data.strip()
        if file_path.startswith('{') and file_path.endswith('}'):  # Windows style
            file_path = file_path[1:-1]
        
        # 
        if ' ' in file_path:
            file_path = file_path.split(' ')[0]
        
        if os.path.exists(file_path):
            self.set_file(file_path)
        
    def check_required_tools(self):
        """Check for required command-line tools"""
        tools = {
            '7z': 'p7zip',
            'unrar': 'unrar',
            'unar': 'unar',
            'cabextract': 'cabextract',
            'rpm2cpio': 'rpm-tools',
            'cpio': 'cpio',
            'dmg2img': 'dmg2img',
            'innoextract': 'innoextract',
            'msiextract': 'msitools',
            'ar': 'binutils',
            'unsquashfs': 'squashfs-tools',
            'zstd': 'zstd'
        }
        
        missing = []
        for cmd, pkg in tools.items():
            if not shutil.which(cmd):
                missing.append(pkg)
        
        if missing:
            self.log(_("WARNING: Missing system tools. Install with: sudo pacman -S {tools}").format(tools=' '.join(missing)))
    
    def get_supported_formats(self):
        """Return a dictionary of supported formats and their handlers"""
        return {
            'zip': self.extract_with_zipfile,
            'tar': self.extract_with_tarfile,
            'gz': self.extract_compressed_tar,
            'tgz': self.extract_compressed_tar,
            'bz2': self.extract_compressed_tar,
            'xz': self.extract_compressed_tar,
            '7z': self.extract_with_7z,
            'rar': self.extract_with_unrar,
            'pet': self.extract_pet,
            'deb': self.extract_deb,
            'rpm': self.extract_rpm,
            'dmg': self.extract_dmg,
            'iso': self.extract_iso,
            'exe': self.extract_exe,
            'msi': self.extract_msi,
            'cab': self.extract_cab,
            'appimage': self.extract_appimage,
            'sfs': self.extract_squashfs,
            'zst': self.extract_zstd,
            '*': self.extract_with_7z
        }
    
    def setup_ui(self):
        # Window configuration
        self.root.geometry("450x500")
        self.root.resizable(False, False)
        
        # 
        main_frame = ttk.Frame(self.root, padding="3")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 
        top_frame = ttk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=2)
        
        # 
        try:
            icon_path = "/usr/local/flitz/Flitz.png"
            if os.path.exists(icon_path):
                img = Image.open(icon_path)
                img = img.resize((48, 48), Image.LANCZOS)
                self.ui_icon = ImageTk.PhotoImage(img) 
                icon_label = ttk.Label(top_frame, image=self.ui_icon)
                icon_label.pack(side=tk.LEFT, padx=3)
                print(_("UI icon loaded from: {path}").format(path=icon_path))
            else:
                print(_("UI icon not found at: {path}").format(path=icon_path))
                ttk.Label(top_frame, text="Flitz", font=("Helvetica", 9)).pack(side=tk.LEFT)
        except Exception as e:
            print(_("Could not load UI icon: {error}").format(error=e))
            ttk.Label(top_frame, text="Flitz", font=("Helvetica", 9)).pack(side=tk.LEFT)
        
        # 
        title_frame = ttk.Frame(top_frame)
        title_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(title_frame, text=_("Flitz Universal Extractor"), 
                font=("Helvetica", 10, "bold")).pack(anchor=tk.W)
        ttk.Label(title_frame, text=_("by josejp2424 (v5.1)"), 
                font=("Helvetica", 7)).pack(anchor=tk.W)
        
        # 
        file_frame = ttk.LabelFrame(main_frame, text=_("File"), padding=3)
        file_frame.pack(fill=tk.X, pady=2)
        
        self.file_button = ttk.Button(file_frame, text=_("Select"), 
                                    command=self.select_file, width=10)
        self.file_button.pack(side=tk.LEFT, padx=2)
        
        self.file_label = tk.Label(file_frame, text=_("Drag file here or click Select"), 
                                 font=("Helvetica", 8), wraplength=300,
                                 relief="sunken", padx=5, pady=2, bg="white")
        self.file_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 
        output_frame = ttk.LabelFrame(main_frame, text=_("Output"), padding=3)
        output_frame.pack(fill=tk.X, pady=2)
        
        self.output_button = ttk.Button(output_frame, text=_("Select"), 
                                      command=self.select_output_dir, width=10)
        self.output_button.pack(side=tk.LEFT, padx=2)
        
        self.output_label = ttk.Label(output_frame, text=_("Current"), 
                                    font=("Helvetica", 8), wraplength=300)
        self.output_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 
        options_frame = ttk.LabelFrame(main_frame, text=_("Options"), padding=3)
        options_frame.pack(fill=tk.X, pady=2)
        
        self.recursive_var = tk.IntVar()
        recursive_check = ttk.Checkbutton(options_frame, text=_("Recursive"),
                                        variable=self.recursive_var)
        recursive_check.pack(side=tk.LEFT, padx=5)
        
        self.keep_structure_var = tk.IntVar(value=1)
        structure_check = ttk.Checkbutton(options_frame, text=_("Keep structure"),
                                        variable=self.keep_structure_var)
        structure_check.pack(side=tk.LEFT, padx=5)
        
        self.overwrite_var = tk.IntVar()
        overwrite_check = ttk.Checkbutton(options_frame, text=_("Overwrite"),
                                        variable=self.overwrite_var)
        overwrite_check.pack(side=tk.LEFT, padx=5)
        
        # Console output
        console_frame = ttk.LabelFrame(main_frame, text=_("Output"), padding=2)
        console_frame.pack(fill=tk.BOTH, expand=True, pady=2)
        
        self.console = scrolledtext.ScrolledText(console_frame, height=8, 
                                              wrap=tk.WORD, font=("Courier", 8))
        self.console.pack(fill=tk.BOTH, expand=True)
        self.console.configure(state='disabled')
        
        # Extract button
        self.extract_button = ttk.Button(main_frame, text=_("Extract"), 
                                       command=self.start_extraction, 
                                       state=tk.DISABLED)
        self.extract_button.pack(pady=3, ipadx=10, ipady=1)
    
    def set_file(self, file_path):
        """Set the file path and update UI"""
        self.file_path = file_path
        short_name = os.path.basename(self.file_path)
        if len(short_name) > 25:
            short_name = "..." + short_name[-22:]
        self.file_label.config(text=short_name)
        self.extract_button.config(state=tk.NORMAL)
        self.log(_("File: {filename}").format(filename=os.path.basename(self.file_path)))
    
    def select_file(self):
        file_path = filedialog.askopenfilename(
            title=_("Select file"),
            filetypes=[
                (_("All supported archives"), 
                 "*.zip *.tar *.gz *.7z *.rar *.pet *.deb *.rpm *.dmg *.iso *.cab *.msi *.exe *.appimage *.sfs *.zst"),
                (_("All files"), "*.*")
            ]
        )
        if file_path:
            self.set_file(file_path)
    
    def select_output_dir(self):
        self.output_dir = filedialog.askdirectory(title=_("Select output directory"))
        if self.output_dir:
            short_dir = os.path.basename(self.output_dir)
            if len(self.output_dir) > 25:
                short_dir = "..." + self.output_dir[-22:]
            self.output_label.config(text=short_dir)
            self.log(_("Output: {directory}").format(directory=self.output_dir))
        else:
            self.output_dir = os.path.dirname(self.file_path) if self.file_path else os.getcwd()
            self.output_label.config(text=_("Current"))
    
    def log(self, message):
        self.console.configure(state='normal')
        self.console.insert(tk.END, message + "\n")
        self.console.see(tk.END)
        self.console.configure(state='disabled')
        self.root.update()
    
    def start_extraction(self):
        if not self.file_path:
            messagebox.showerror(_("Error"), _("Please select a file first"))
            return
            
        if not self.output_dir:
            self.select_output_dir()
            if not self.output_dir:
                self.output_dir = os.path.dirname(self.file_path)
        
        self.extract_button.config(state=tk.DISABLED)
        self.log("\n" + _("Starting extraction..."))
        
        # 
        if hasattr(self, 'root') and self.root.winfo_exists():
            threading.Thread(target=self.extract_file, daemon=True).start()
        else:
            self.extract_file()
    
    def get_file_extension(self, filename):
        """Get the file extension, handling multi-part extensions"""
        base = os.path.basename(filename).lower()
        if base.endswith('.tar.gz'):
            return 'tar.gz'
        elif base.endswith('.tar.bz2'):
            return 'tar.bz2'
        elif base.endswith('.tar.xz'):
            return 'tar.xz'
        elif base.endswith('.tar.7z'):
            return 'tar.7z'
        elif base.endswith('.tar.zip'):
            return 'tar.zip'
        elif base.endswith('.squashfs'):
            return 'sfs'
        elif '.' in base and base.split('.')[-1].isdigit():
            return base.split('.')[-2] + '.' + base.split('.')[-1]
        else:
            return base.split('.')[-1] if '.' in base else ''
    
    def extract_file(self):
        try:
            filename = os.path.basename(self.file_path)
            ext = self.get_file_extension(self.file_path)
            
            self.log(_("\nDetected format: {format}").format(format=ext))
            
            if ext in ['rar', '001', 'r00'] and self.is_multi_volume(self.file_path):
                self.handle_multi_volume()
                return
            
            extractor = self.supported_formats.get(ext, self.supported_formats['*'])
            extractor()
            
            self.log("\n" + _("Extraction completed successfully!"))
            if hasattr(self, 'root') and self.root.winfo_exists():
                messagebox.showinfo(_("Success"), _("Extraction completed"))
            
        except Exception as e:
            self.log(_("\nError: {error}").format(error=str(e)))
            if hasattr(self, 'root') and self.root.winfo_exists():
                messagebox.showerror(_("Error"), _("Extraction failed:\n{error}").format(error=str(e)))
            
        finally:
            if hasattr(self, 'extract_button'):
                self.extract_button.config(state=tk.NORMAL)
            if not (hasattr(self, 'root') and self.root.winfo_exists()):
                #
                self.root.quit()
    
    def is_multi_volume(self, filepath):
        base = os.path.basename(filepath).lower()
        if '.part' in base or '.r' in base.split('.')[-1] or '.001' in base:
            return True
        return False
    
    def handle_multi_volume(self):
        self.log(_("Detected multi-volume archive, using unrar..."))
        subprocess.run(['unrar', 'x', self.file_path, self.output_dir], check=True)
    
    def extract_with_zipfile(self):
        with zipfile.ZipFile(self.file_path, 'r') as zip_ref:
            zip_ref.extractall(self.output_dir)
    
    def extract_with_tarfile(self):
        with tarfile.open(self.file_path, 'r:*') as tar_ref:
            tar_ref.extractall(self.output_dir)
    
    def extract_compressed_tar(self):
        """Handle compressed tar files without creating double folders"""
        filename = os.path.basename(self.file_path)
        
        # Determine compression mode
        if filename.endswith('.gz') or filename.endswith('.tgz'):
            mode = 'r:gz'
        elif filename.endswith('.bz2'):
            mode = 'r:bz2'
        elif filename.endswith('.xz'):
            mode = 'r:xz'
        else:
            mode = 'r:*'
        
        # 
        temp_dir = tempfile.mkdtemp()
        try:
            with tarfile.open(self.file_path, mode) as tar_ref:
                tar_ref.extractall(temp_dir)
                
                # 
                extracted_items = os.listdir(temp_dir)
                
                if len(extracted_items) == 1:
                    # 
                    item_path = os.path.join(temp_dir, extracted_items[0])
                    if os.path.isdir(item_path):
                        # 
                        for content in os.listdir(item_path):
                            shutil.move(os.path.join(item_path, content), self.output_dir)
                    else:
                        # 
                        shutil.move(item_path, self.output_dir)
                else:
                    # 
                    for item in extracted_items:
                        shutil.move(os.path.join(temp_dir, item), self.output_dir)
        finally:
            shutil.rmtree(temp_dir)
    
    def extract_with_7z(self):
        """Handle 7z files and nested archives"""
        temp_dir = tempfile.mkdtemp()
        try:
            # 
            subprocess.run(['7z', 'x', self.file_path, f'-o{temp_dir}'], check=True)
            
            # 
            extracted_items = os.listdir(temp_dir)
            
            if len(extracted_items) == 1:
                item = extracted_items[0]
                item_path = os.path.join(temp_dir, item)
                
                # 
                if item.endswith('.tar'):
                    with tarfile.open(item_path, 'r:*') as tar_ref:
                        tar_ref.extractall(self.output_dir)
                elif item.endswith('.zip'):
                    with zipfile.ZipFile(item_path, 'r') as zip_ref:
                        zip_ref.extractall(self.output_dir)
                else:
                    # 
                    shutil.move(item_path, self.output_dir)
            else:
                # 
                for item in extracted_items:
                    shutil.move(os.path.join(temp_dir, item), self.output_dir)
        finally:
            shutil.rmtree(temp_dir)
    
    def extract_with_unrar(self):
        subprocess.run(['unrar', 'x', self.file_path, self.output_dir], check=True)
    
    def extract_pet(self):
        """Special handling for .pet files (Puppy Linux packages)"""
        with tarfile.open(self.file_path, 'r:gz') as tar_ref:
            tar_ref.extractall(self.output_dir)
    
    def extract_deb(self):
        """Extract Debian packages with proper directory structure"""
        pkg_name = os.path.basename(self.file_path).split('_')[0]
        output_path = os.path.join(self.output_dir, pkg_name)
        os.makedirs(output_path, exist_ok=True)
        
        temp_dir = tempfile.mkdtemp()
        try:
            subprocess.run(['ar', 'x', self.file_path], cwd=temp_dir, check=True)
            
            for f in os.listdir(temp_dir):
                if f.startswith('data.tar'):
                    data_path = os.path.join(temp_dir, f)
                    if f.endswith('.xz'):
                        subprocess.run(['tar', 'xJf', data_path, '-C', output_path], check=True)
                    elif f.endswith('.gz'):
                        subprocess.run(['tar', 'xzf', data_path, '-C', output_path], check=True)
                    elif f.endswith('.bz2'):
                        subprocess.run(['tar', 'xjf', data_path, '-C', output_path], check=True)
                    else:
                        subprocess.run(['tar', 'xf', data_path, '-C', output_path], check=True)
                    break
        finally:
            shutil.rmtree(temp_dir)
    
    def extract_rpm(self):
        """Extract RPM packages with proper directory structure"""
        pkg_name = os.path.basename(self.file_path).split('-')[0]
        output_path = os.path.join(self.output_dir, pkg_name)
        os.makedirs(output_path, exist_ok=True)
        
        cmd = f'rpm2cpio "{self.file_path}" | cpio -idmv -D "{output_path}"'
        subprocess.run(cmd, shell=True, check=True)
    
    def extract_dmg(self):
        """Extract Mac DMG files"""
        temp_img = os.path.join(self.output_dir, 'temp.img')
        subprocess.run(['dmg2img', self.file_path, temp_img], check=True)
        subprocess.run(['7z', 'x', temp_img], cwd=self.output_dir, check=True)
        os.remove(temp_img)
    
    def extract_iso(self):
        """Extract ISO files"""
        subprocess.run(['7z', 'x', self.file_path, f'-o{self.output_dir}'], check=True)
    
    def extract_exe(self):
        """Extract self-extracting executables"""
        try:
            subprocess.run(['innoextract', self.file_path, '-d', self.output_dir], check=True)
        except:
            subprocess.run(['7z', 'x', self.file_path, f'-o{self.output_dir}'], check=True)
    
    def extract_msi(self):
        """Extract MSI installers"""
        subprocess.run(['msiextract', '--directory', self.output_dir, self.file_path], check=True)
    
    def extract_cab(self):
        """Extract CAB files"""
        subprocess.run(['cabextract', '-d', self.output_dir, self.file_path], check=True)
    
    def extract_appimage(self):
        """Extract AppImage files"""
        subprocess.run(['chmod', '+x', self.file_path], check=True)
        subprocess.run([self.file_path, '--appimage-extract'], cwd=self.output_dir, check=True)
    
    def extract_squashfs(self):
        """Extract SquashFS (.sfs) files creating a folder with the archive name"""
        # 
        base_name = os.path.splitext(os.path.basename(self.file_path))[0]
        output_path = os.path.join(self.output_dir, base_name)
        os.makedirs(output_path, exist_ok=True)
        
        # 
        subprocess.run(['unsquashfs', '-f', '-d', output_path, self.file_path], check=True)
    
    def extract_zstd(self):
        """Extract .zst files creating a folder with the archive name"""
        # 
        base_name = os.path.splitext(os.path.basename(self.file_path))[0]
        if base_name.endswith('.tar'):
            base_name = base_name[:-4]  
        output_path = os.path.join(self.output_dir, base_name)
        os.makedirs(output_path, exist_ok=True)
        
        temp_file = os.path.join(tempfile.gettempdir(), 'flitz_temp_decompress')
        try:
            # 
            subprocess.run(['zstd', '-d', self.file_path, '-o', temp_file], check=True)
            
            # 
            try:
                with tarfile.open(temp_file, 'r:*') as tar_ref:
                    tar_ref.extractall(output_path)
            except tarfile.ReadError:
                # 
                shutil.move(temp_file, os.path.join(output_path, base_name))
        finally:
            if os.path.exists(temp_file):
                os.remove(temp_file)

def check_python_dependencies():
    required = {
        'PIL': 'python-pillow',
        'py7zr': 'python-py7zr',
        'rarfile': 'python-rarfile',
        'tkinterdnd2': 'tkinterdnd2'
    }
    
    missing = []
    for pkg, arch_pkg in required.items():
        try:
            __import__(pkg)
        except ImportError:
            missing.append(arch_pkg)
    
    if missing:
        print("\nERROR: Missing Python packages. Install with:")
        print(f"pip install {' '.join(missing)}")
        sys.exit(1)

def main():
    check_python_dependencies()
    
    args = parse_args()
    
    # Configurar idioma basado en argumentos o sistema
    language = args.language if args.language else None
    
    if args.file:
        # Modo consola
        root = TkinterDnD.Tk()
        root.withdraw() 
        
        app = FlitzApp(root, language)
        app.file_path = args.file
        app.output_dir = args.output if args.output else os.path.dirname(args.file)
        app.recursive_var.set(1 if args.recursive else 0)
        app.keep_structure_var.set(1 if args.keep_structure else 0)
        app.overwrite_var.set(1 if args.overwrite else 0)
        
       #
        app.start_extraction()
        
        # 
        root.mainloop()
    else:
        # 
        root = TkinterDnD.Tk()
        style = ttk.Style()
        style.theme_use("clam")
        
        app = FlitzApp(root, language)
        root.mainloop()

if __name__ == "__main__":
    main()
