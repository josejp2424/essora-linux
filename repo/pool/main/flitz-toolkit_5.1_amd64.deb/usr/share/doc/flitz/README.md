# Flitz Toolkit

**Versión:** 5.1  
**Autor:** josejp2424  
**Licencia:** MIT

## 📌 Descripción

**Flitz** es un conjunto de herramientas gráficas universales para comprimir y descomprimir archivos. Está pensado para usuarios de Linux que buscan una interfaz intuitiva y poderosa.  

Incluye:

- **Flitz-Extractor**: Descompresor universal multiformato.
- **Flitz-Compressor**: Compresor de carpetas con opciones avanzadas.

Ambos programas están internacionalizados, tienen soporte de arrastrar y soltar y pueden ejecutarse en modo gráfico o desde la línea de comandos.

---

## 🧰 Características

### Flitz-Extractor

- Soporte para: `.zip`, `.tar.*`, `.gz`, `.bz2`, `.xz`, `.7z`, `.rar`, `.pet`, `.deb`, `.rpm`, `.dmg`, `.iso`, `.cab`, `.msi`, `.exe`, `.appimage`, `.sfs`, `.zst`, etc.
- Extracción recursiva opcional.
- Detección y manejo de archivos multivolumen.
- Evita carpetas anidadas innecesarias.
- Soporte de línea de comandos con múltiples opciones.
- Soporte multilenguaje (`gettext`).
- Interfaz moderna con arrastrar y soltar.

### Flitz-Compressor

- Soporte de formatos: `tar.gz`, `tar.xz`, `zip`, `7z`, `squashfs`.
- Opciones avanzadas para squashfs: compresión (`xz`, `zstd`, `gzip`, `lz4`), tamaño de bloque, filtros BCJ (`x86`, `arm`, etc.).
- Barra de progreso en tiempo real.
- Sugerencia automática del nombre de salida.
- Interfaz moderna con soporte de arrastrar y soltar.

---

## 📦 Dependencias

### 🔹 Python (librerías)

#### Paquetes requeridos (en ambos sistemas):

- `python3-pillow` (PIL)
- `python3-tk` + `tkinterdnd2`
- `python3-py7zr`
- `python3-pyzstd`
- `python3-pybcj`
- `python3-beautifulsoup4`
- `python3-brotli`

#### Instalación en Debian / Ubuntu:
sudo pacman -S \
  python-pillow python-py7zr python-pyzstd python-pybcj \
  python-beautifulsoup4 python-brotli
#### Instalación en Debian / Ubuntu:

sudo apt-get install \
  python3-pillow python3-tk python3-py7zr python3-pyzstd \
  python3-pybcj python3-beautifulsoup4 python3-brotli


