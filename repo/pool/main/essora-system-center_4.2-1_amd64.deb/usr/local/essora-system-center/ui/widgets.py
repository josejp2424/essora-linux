#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class InfoFrame(Gtk.Box):
    """Contenedor estilo Hardinfo (cabecera + contenido)."""

    def __init__(self, title: str):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.get_style_context().add_class('info-frame')

        header = Gtk.Label(label=title)
        header.set_xalign(0)
        header.get_style_context().add_class('frame-header')
        self.pack_start(header, False, False, 0)

        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        self.pack_start(sep, False, False, 0)

        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)

        self.content_box = self.content
        self.content.set_margin_top(10)
        self.content.set_margin_bottom(10)
        self.content.set_margin_start(10)
        self.content.set_margin_end(10)
        self.pack_start(self.content, True, True, 0)

    def add(self, widget):
        self.content.pack_start(widget, False, False, 0)


class ProgressSection(Gtk.Box):
    """Sección simple con título + barra de progreso."""

    def __init__(self, title: str, show_text: bool = True):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.label = Gtk.Label(label=title)
        self.label.set_xalign(0)
        self.pack_start(self.label, False, False, 0)

        self.bar = Gtk.ProgressBar()
        self.bar.set_show_text(show_text)
        self.pack_start(self.bar, False, False, 0)

    def set_fraction(self, frac: float, text: str | None = None):
        self.bar.set_fraction(max(0.0, min(1.0, frac)))
        if text is not None:
            self.bar.set_text(text)


class GraphWidget(Gtk.DrawingArea):
    """Placeholder para gráficos. Por ahora dibuja una rejilla simple."""

    def __init__(self, height: int = 120):
        super().__init__()
        self.set_size_request(-1, height)
        self.connect('draw', self._on_draw)

    def _on_draw(self, widget, cr):
        alloc = self.get_allocation()
        w, h = alloc.width, alloc.height
        # fondo
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.0)
        cr.paint()
        # rejilla suave
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.08)
        step = max(10, int(w / 10))
        for x in range(0, w, step):
            cr.move_to(x, 0)
            cr.line_to(x, h)
        step_y = max(10, int(h / 6))
        for y in range(0, h, step_y):
            cr.move_to(0, y)
            cr.line_to(w, y)
        cr.set_line_width(1)
        cr.stroke()
        return False
