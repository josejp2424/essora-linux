#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, GdkPixbuf

from pathlib import Path
from utils.translations import translator


def _get_app_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def _load_icon_image(size: int = 24) -> Gtk.Image:
    app_dir = _get_app_dir()
    candidates = [
        Path('/usr/local/essora-system-center/icons/essora-center.png'),
        app_dir / 'icons' / 'essora-center.png',
        app_dir / 'icons' / 'essora-center.svg',
        Path('/usr/local/essora-kit/essora-center.svg'),
        Path('/usr/share/pixmaps/essora-system-center.png'),
    ]

    for p in candidates:
        try:
            if p.exists():
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(p), size, size, True)
                return Gtk.Image.new_from_pixbuf(pb)
        except Exception:
            continue


    return Gtk.Image.new_from_icon_name('computer-symbolic', Gtk.IconSize.BUTTON)


class EssoraHeaderBar(Gtk.HeaderBar):
    def __init__(self, parent_window):
        super().__init__()
        self.parent_window = parent_window

        self.set_show_close_button(False)
        self.get_style_context().add_class('essora-headerbar')


        left = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        left.set_margin_start(8)

        icon = _load_icon_image(size=22)
        icon.set_valign(Gtk.Align.CENTER)
        left.pack_start(icon, False, False, 0)

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        text_box.set_valign(Gtk.Align.CENTER)

        self.title_label = Gtk.Label(label=translator.get('Essora System Center'))
        self.title_label.set_xalign(0)
        self.title_label.get_style_context().add_class('header-title')

        self.subtitle_label = Gtk.Label(label=translator.get('System Information and Management Tool'))
        self.subtitle_label.set_xalign(0)
        self.subtitle_label.get_style_context().add_class('header-subtitle')

        text_box.pack_start(self.title_label, False, False, 0)
        text_box.pack_start(self.subtitle_label, False, False, 0)
        left.pack_start(text_box, False, False, 0)

        self.pack_start(left)


        right = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        right.set_margin_end(6)

        self.btn_min = self._make_btn('window-minimize-symbolic', translator.get('Minimize'))
        self.btn_min.connect('clicked', lambda *_: self.parent_window.iconify())

        self.btn_max = self._make_btn('window-maximize-symbolic', translator.get('Maximize'))
        self.btn_max.connect('clicked', self._toggle_maximize)

        self.btn_close = self._make_btn('window-close-symbolic', translator.get('Close'))
        self.btn_close.connect('clicked', lambda *_: self.parent_window.close())

        right.pack_start(self.btn_min, False, False, 0)
        right.pack_start(self.btn_max, False, False, 0)
        right.pack_start(self.btn_close, False, False, 0)

        self.pack_end(right)
        self.show_all()

    def _make_btn(self, icon_name: str, tooltip: str) -> Gtk.Button:
        b = Gtk.Button()
        b.set_relief(Gtk.ReliefStyle.NONE)
        b.set_focus_on_click(False)
        img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        b.add(img)
        b.set_tooltip_text(tooltip)
        return b

    def _toggle_maximize(self, *_):
        if self.parent_window.is_maximized():
            self.parent_window.unmaximize()
        else:
            self.parent_window.maximize()

    def set_subtitle(self, subtitle: str):
        if subtitle:
            self.subtitle_label.set_text(subtitle)
        else:
            self.subtitle_label.set_text('')
