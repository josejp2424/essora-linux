#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
"""System helpers for Essora System Center.

These utilities are intentionally dependency-light.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

Cmd = Union[str, Sequence[str]]


@dataclass
class CmdResult:
    ok: bool
    stdout: str
    stderr: str
    returncode: int


def run_cmd(cmd: Cmd, timeout: float = 3.0, env: Optional[Dict[str, str]] = None) -> CmdResult:
    """Run a command and return a structured result."""
    try:
        if isinstance(cmd, str):
            args = shlex.split(cmd)
        else:
            args = list(cmd)
        proc = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            env=env,
        )
        return CmdResult(proc.returncode == 0, proc.stdout.strip(), proc.stderr.strip(), proc.returncode)
    except FileNotFoundError as e:
        return CmdResult(False, "", str(e), 127)
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "").strip() if hasattr(e, 'stdout') else ""
        err = (e.stderr or "").strip() if hasattr(e, 'stderr') else "timeout"
        return CmdResult(False, out, err, 124)
    except Exception as e:
        return CmdResult(False, "", str(e), 1)


def read_text(path: str, default: str = "") -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return default


def parse_kv_lines(text: str) -> Dict[str, str]:
    """Parse KEY=VALUE lines (like /etc/os-release)."""
    data: Dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"').strip("'")
        data[k.strip()] = v
    return data


def get_os_release() -> Dict[str, str]:
    return parse_kv_lines(read_text("/etc/os-release"))


def get_kernel_version() -> str:
    return read_text("/proc/sys/kernel/osrelease").strip() or run_cmd(["uname", "-r"]).stdout or "Unknown"


def get_architecture() -> str:
    return run_cmd(["uname", "-m"]).stdout or "Unknown"


def get_hostname() -> str:
    return read_text("/etc/hostname").strip() or run_cmd(["hostname"]).stdout or "Unknown"


def get_uptime_seconds() -> Optional[float]:
    txt = read_text("/proc/uptime").strip()
    if not txt:
        return None
    try:
        return float(txt.split()[0])
    except Exception:
        return None


def format_uptime(seconds: float) -> str:
    seconds = max(0, int(seconds))
    days, rem = divmod(seconds, 86400)
    hrs, rem = divmod(rem, 3600)
    mins, _ = divmod(rem, 60)
    if days:
        return f"{days}d {hrs}h {mins}m"
    if hrs:
        return f"{hrs}h {mins}m"
    return f"{mins}m"


def get_boot_time_unix() -> Optional[int]:
    up = get_uptime_seconds()
    if up is None:
        return None
    return int(time.time() - up)



def get_os_age_days() -> Optional[int]:

    res = run_cmd(["stat", "-c", "%W", "/"], timeout=2.0)
    if res.ok and res.stdout.isdigit():
        bt = int(res.stdout)
        if bt > 0:
            now = int(time.time())
            return max(0, (now - bt) // 86400)

    dev = get_root_device()
    created = ""
    if dev and dev.startswith("/dev/"):
        r1 = run_cmd(["tune2fs", "-l", dev], timeout=4.0)
        out = r1.stdout if r1.ok else ""
        if not out:
            r2 = run_cmd(["sudo", "-n", "tune2fs", "-l", dev], timeout=4.0)
            out = r2.stdout if r2.ok else ""
        if out:
            for line in out.splitlines():
                if line.strip().startswith("Filesystem created") and ":" in line:
                    created = line.split(":", 1)[1].strip()
                    break
    if created:
        r3 = run_cmd(["date", "-d", created, "+%s"], timeout=2.0)
        if r3.ok and r3.stdout.isdigit():
            b = int(r3.stdout)
            now = int(time.time())
            return max(0, (now - b) // 86400)

    res2 = run_cmd(["stat", "-c", "%Y", "/"], timeout=2.0)
    if res2.ok and res2.stdout.isdigit():
        b = int(res2.stdout)
        now = int(time.time())
        return max(0, (now - b) // 86400)
    return None

def get_load_average() -> Tuple[Optional[float], Optional[float], Optional[float]]:
    txt = read_text("/proc/loadavg").strip()
    if not txt:
        return (None, None, None)
    parts = txt.split()
    try:
        return (float(parts[0]), float(parts[1]), float(parts[2]))
    except Exception:
        return (None, None, None)


def get_logged_in_users() -> List[str]:
    res = run_cmd(["who"], timeout=2.0)
    if not res.ok or not res.stdout:
        return []
    users: List[str] = []
    for line in res.stdout.splitlines():
        if line.strip():
            users.append(line.split()[0])
    # unique preserve order
    seen = set()
    out: List[str] = []
    for u in users:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def human_bytes(num: float) -> str:
    try:
        n = float(num)
    except Exception:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    if i == 0:
        return f"{int(n)} {units[i]}"
    return f"{n:.1f} {units[i]}"


def meminfo() -> Dict[str, int]:
    """Return /proc/meminfo as dict of kB values."""
    txt = read_text("/proc/meminfo")
    out: Dict[str, int] = {}
    for line in txt.splitlines():
        m = re.match(r"^(\w+):\s+(\d+)", line)
        if m:
            out[m.group(1)] = int(m.group(2))
    return out


def cpu_model() -> str:
    txt = read_text("/proc/cpuinfo")
    for line in txt.splitlines():
        if line.lower().startswith("model name") and ":" in line:
            return line.split(":", 1)[1].strip()
    return run_cmd(["uname", "-p"]).stdout or "Unknown"


def cpu_cores() -> int:
    try:
        return os.cpu_count() or 0
    except Exception:
        return 0


def lsblk_json() -> Optional[Dict[str, Any]]:
    res = run_cmd(["lsblk", "-J", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE,MODEL"], timeout=3.0)
    if not res.ok or not res.stdout:
        return None
    try:
        return json.loads(res.stdout)
    except Exception:
        return None


def ip_addr() -> List[Dict[str, str]]:
    """Return list of interfaces with addresses (best effort)."""
    res = run_cmd(["ip", "-o", "addr", "show"], timeout=3.0)
    if not res.ok:
        return []
    out: List[Dict[str, str]] = []
    for line in res.stdout.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        iface = parts[1]
        fam = parts[2]
        addr = parts[3]
        if fam in ("inet", "inet6"):
            out.append({"iface": iface, "family": fam, "addr": addr})
    return out


def default_route() -> str:
    res = run_cmd(["ip", "route", "show", "default"], timeout=2.0)
    return res.stdout if res.ok else ""


def dns_servers() -> List[str]:
    txt = read_text("/etc/resolv.conf")
    servers: List[str] = []
    for line in txt.splitlines():
        line = line.strip()
        if line.startswith("nameserver"):
            parts = line.split()
            if len(parts) >= 2:
                servers.append(parts[1])
    return servers


def dpkg_count() -> Optional[int]:
    res = run_cmd(["dpkg-query", "-f", "${binary:Package}\n", "-W"], timeout=6.0)
    if not res.ok:
        return None
    return len([l for l in res.stdout.splitlines() if l.strip()])


def flatpak_count() -> Optional[int]:
    res = run_cmd(["flatpak", "list"], timeout=6.0)
    if not res.ok:
        return None
    return len([l for l in res.stdout.splitlines() if l.strip()])


def appimage_count(search_dirs: Optional[List[str]] = None) -> Optional[int]:
    if not search_dirs:
        search_dirs = [os.path.expanduser("~/Applications"), "/opt"]
    total = 0
    found_any = False
    for d in search_dirs:
        if not os.path.isdir(d):
            continue
        found_any = True
        for root, _, files in os.walk(d):
            for fn in files:
                if fn.lower().endswith(".appimage"):
                    total += 1
    return total if found_any else None


def _base_block_device(dev: str) -> str:
    """Normalize a partition device path to its parent block device.

    Examples:
      - /dev/sda1 -> /dev/sda
      - /dev/nvme0n1p2 -> /dev/nvme0n1
      - /dev/mmcblk0p1 -> /dev/mmcblk0
    """
    dev = (dev or "").strip()
    if not dev.startswith("/dev/"):
        return dev

    # NVMe: nvme0n1p2 -> nvme0n1
    m = re.match(r"^(/dev/nvme\d+n\d+)p\d+$", dev)
    if m:
        return m.group(1)

    # MMC: mmcblk0p1 -> mmcblk0
    m = re.match(r"^(/dev/mmcblk\d+)p\d+$", dev)
    if m:
        return m.group(1)

    # sdX/hdX/vdX: sda1 -> sda, vda2 -> vda
    m = re.match(r"^(/dev/[a-zA-Z]+)\d+$", dev)
    if m:
        return m.group(1)

    return dev


def get_root_block_device() -> Optional[str]:
    """Return the block device backing '/'. Best effort."""


    res = run_cmd(["findmnt", "-no", "SOURCE", "/"], timeout=2.0)
    src = res.stdout.strip() if res.ok else ""
    if src.startswith("/dev/"):
        return _base_block_device(src)


    res = run_cmd(["df", "-P", "/"], timeout=2.5)
    if res.ok and res.stdout:
        lines = res.stdout.splitlines()
        if len(lines) >= 2:
            fs = lines[1].split()[0]
            if fs.startswith("/dev/"):
                return _base_block_device(fs)

    return None


def get_disk_status(dev: Optional[str] = None) -> Optional[str]:
    """Obtiene el estado/salud del disco usando hdsentinel (si está instalado).

    Basado en el comando que pasaste:
        hdsentinel -nodevs -dev /dev/sda 2>/dev/null | grep -E 'Health'

    Mejoras:
      - si no pasás 'dev', detecta el dispositivo que respalda '/'
      - fallback a /dev/sda
      - intenta primero sin sudo y luego con sudo -n (no interactivo)

    Devuelve la primera línea que contenga "Health" o None si no está disponible.
    """
    dev = (dev or "").strip() or (get_root_block_device() or "/dev/sda")
    if not dev:
        return None

    # Verificar si existe hdsentinel
    chk = run_cmd(["bash", "-lc", "command -v hdsentinel >/dev/null 2>&1"], timeout=2.0)
    if not chk.ok:
        return None

    qdev = shlex.quote(dev)
    cmd = f"hdsentinel -nodevs -dev {qdev} 2>/dev/null | grep -E 'Health'"


    res = run_cmd(["bash", "-lc", cmd], timeout=4.0)
    out = res.stdout.strip() if res.ok else ""
    if out:
        return out.splitlines()[0].strip()


    res = run_cmd(["bash", "-lc", f"sudo -n {cmd}"], timeout=4.0)
    out = res.stdout.strip() if res.ok else ""
    return out.splitlines()[0].strip() if out else None


def get_disk_health_status(dev: Optional[str] = None) -> Optional[str]:
    """Alias compat (por si algún módulo lo llama así)."""
    return get_disk_status(dev)
