#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
"""Traducciones para Essora System Center.

Requisitos del usuario:
- GUI base en INGLÉS (por defecto siempre 'en')
- Todas las traducciones externas en: /usr/local/essora-system-center/lang

Formato recomendado de archivos:
  /usr/local/essora-system-center/lang/es.json
  /usr/local/essora-system-center/lang/fr.json

Cada archivo debe ser un JSON plano "English string" -> "translated string".
"""

import json
import locale
import os
from pathlib import Path

SUPPORTED_LANGUAGES = {
    'en': 'English',
    'es': 'Español',
    'ca': 'Català',
    'fr': 'Français',
    'it': 'Italiano',
    'pt': 'Português',
    'hu': 'Magyar',
    'ru': 'Русский',
    'ja': '日本語',
    'zh': '中文',
    'ar': 'العربية',
}


def _get_app_dir() -> Path:
   
    return Path(__file__).resolve().parent.parent


def _get_lang_dir() -> Path:
    """Prioriza el path pedido por el usuario."""
    candidates = [
        Path('/usr/local/essora-system-center/lang'),
        _get_app_dir() / 'lang',
        Path('/usr/share/essora-system-center/lang'),
    ]
    for p in candidates:
        if p.exists() and p.is_dir():
            return p

    return candidates[0]


def _config_path() -> Path:
    xdg = os.environ.get('XDG_CONFIG_HOME')
    if xdg:
        base = Path(xdg)
    else:
        base = Path.home() / '.config'
    return base / 'essora-system-center' / 'config.json'


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')


def _normalize_lang(code: str) -> str:
    if not code:
        return 'en'
    code = code.strip().lower()

    if '_' in code:
        code = code.split('_', 1)[0]
    if '-' in code:
        code = code.split('-', 1)[0]
    if code in SUPPORTED_LANGUAGES:
        return code
    return 'en'


def _system_lang() -> str:
    try:
        lang, _enc = locale.getdefaultlocale()
        return _normalize_lang(lang or '')
    except Exception:
        return 'en'


class Translator:
    def __init__(self):
        self.lang_dir = _get_lang_dir()
        self.config_path = _config_path()

       
        self.default_lang = 'en'


        self.current_lang = self._load_preference()
        self.translations = self._load_file(self.current_lang)

    def _load_preference(self) -> str:
        cfg = _read_json(self.config_path)

        pref = cfg.get('language', self.default_lang)
        if isinstance(pref, str) and pref.lower() == 'auto':
            return _system_lang()
        return _normalize_lang(str(pref))

    def _load_file(self, lang: str) -> dict:

        if lang == 'en':
            return {}


        p = self.lang_dir / f'{lang}.json'
        if p.exists():
            data = _read_json(p)
            if isinstance(data, dict):
                return data

        return {}

    def get(self, key: str, **kwargs) -> str:
        if not isinstance(key, str):
            key = str(key)
        txt = self.translations.get(key, key)
        if kwargs:
            try:
                return txt.format(**kwargs)
            except Exception:
                return txt
        return txt

    def set_language(self, lang: str) -> None:
        lang = _normalize_lang(lang)
        self.current_lang = lang
        self.translations = self._load_file(lang)

    def save_language(self, lang: str) -> None:
        """Guarda preferencia y aplica al vuelo."""
       
        if isinstance(lang, str) and lang.lower() == 'auto':
            _write_json(self.config_path, {'language': 'auto'})
            self.set_language(_system_lang())
            return

        lang = _normalize_lang(lang)
        _write_json(self.config_path, {'language': lang})
        self.set_language(lang)


translator = Translator()
