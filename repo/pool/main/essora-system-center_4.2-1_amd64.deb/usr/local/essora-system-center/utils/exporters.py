#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
"""Report export helpers.

MainWindow collects per-module data via module.get_data() and passes a dict:
{ "Module Name": { ... } }

export_report writes TXT/JSON/HTML report and returns filepath.
"""

from __future__ import annotations

import html
import json
import os
from typing import Any, Dict

from utils.file_utils import ensure_dir, timestamp, safe_filename, user_documents_dir


def _to_text(data: Dict[str, Any]) -> str:
    lines = []
    for mod, payload in data.items():
        lines.append(f"== {mod} ==")
        if isinstance(payload, dict):
            for k, v in payload.items():
                lines.append(f"{k}: {v}")
        else:
            lines.append(str(payload))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _to_html(data: Dict[str, Any]) -> str:
    parts = [
        "<!doctype html>",
        "<html><head><meta charset='utf-8'>",
        "<title>Essora System Center Report</title>",
        "<style>body{font-family:sans-serif;padding:20px}h2{margin-top:30px}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px 8px}</style>",
        "</head><body>",
        f"<h1>Essora System Center Report</h1>",
    ]
    for mod, payload in data.items():
        parts.append(f"<h2>{html.escape(str(mod))}</h2>")
        if isinstance(payload, dict):
            parts.append("<table>")
            parts.append("<tr><th>Key</th><th>Value</th></tr>")
            for k, v in payload.items():
                parts.append(f"<tr><td>{html.escape(str(k))}</td><td>{html.escape(str(v))}</td></tr>")
            parts.append("</table>")
        else:
            parts.append(f"<pre>{html.escape(str(payload))}</pre>")
    parts.append("</body></html>")
    return "\n".join(parts)


def export_report(data: Dict[str, Any], format_type: str = "txt", out_dir: str | None = None) -> str:
    format_type = (format_type or "txt").lower().strip()
    if format_type not in {"txt", "json", "html"}:
        format_type = "txt"

    if out_dir is None:
        out_dir = os.path.join(user_documents_dir(), "Essora-System-Center")
    ensure_dir(out_dir)

    base = safe_filename(f"essora-system-center-report-{timestamp()}")
    if format_type == "txt":
        content = _to_text(data)
        path = os.path.join(out_dir, base + ".txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    if format_type == "json":
        path = os.path.join(out_dir, base + ".json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return path

    # html
    content = _to_html(data)
    path = os.path.join(out_dir, base + ".html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path
