#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Tools module.

Integra tus scripts externos dentro del System Center:
- about.py  (System Summary)
- agent.py  (Essora Top)

Se lanzan como procesos separados para evitar conflictos de GTK mainloops.
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from ui.widgets import InfoFrame
from utils.translations import translator


def _app_dir() -> Path:
    
    return Path(__file__).resolve().parent.parent


def _tool_path(name: str) -> Path:
    candidates = [
        Path('/usr/local/essora-system-center/tools') / name,
        _app_dir() / 'tools' / name,
    ]
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]


def _spawn_script(path: Path) -> tuple[bool, str]:
    try:
        env = os.environ.copy()
        env.setdefault('LC_ALL', 'C.UTF-8')
        env.setdefault('LANG', 'C.UTF-8')

        exe = sys.executable or 'python3'
        subprocess.Popen([exe, str(path)], env=env)
        return True, ''
    except Exception as e:
        return False, str(e)


class ToolsModule:
    """Tools tab."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget: Gtk.Widget | None = None
        self._status: Gtk.Label | None = None

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
        return self.content_widget

    def update(self):
        return

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        frame = InfoFrame(translator.get('Tools'))

        desc = Gtk.Label(label=translator.get('External tools integrated with Essora System Center.'))
        desc.set_xalign(0)
        desc.set_line_wrap(True)
        frame.add(desc)

        btns = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        btn_about = Gtk.Button(label=translator.get('Open System Summary'))
        btn_about.get_style_context().add_class('essora-button')
        btn_about.connect('clicked', self._on_launch, 'about.py')
        btns.pack_start(btn_about, False, False, 0)

        btn_agent = Gtk.Button(label=translator.get('Open Essora Top'))
        btn_agent.get_style_context().add_class('essora-button')
        btn_agent.connect('clicked', self._on_launch, 'agent.py')
        btns.pack_start(btn_agent, False, False, 0)

        frame.add(btns)

        self._status = Gtk.Label(label='')
        self._status.set_xalign(0)
        frame.add(self._status)

        root.pack_start(frame, True, True, 0)
        return root

    def _set_status(self, text: str):
        if self._status:
            self._status.set_text(text)

    def _on_launch(self, _btn, script_name: str):
        path = _tool_path(script_name)
        ok, err = _spawn_script(path)
        if ok:
            self._set_status(translator.get('Launched: {}').format(str(path)))
        else:
            self._set_status(translator.get('Error') + f': {err}')
