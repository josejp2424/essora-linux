#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Network information module."""

from __future__ import annotations

import threading

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from ui.widgets import InfoFrame
from utils.translations import translator
from utils.system_utils import dns_servers, default_route, ip_addr, run_cmd


class NetworkInfoModule:
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None

        self._iface_store = Gtk.ListStore(str, str, str) 
        self._lbl_route = None
        self._lbl_dns = None
        self._lbl_test = None
        self._btn_test = None

        self._data = {}

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)


        frame_if = InfoFrame(translator.get('Interfaces'))
        root.pack_start(frame_if, False, False, 0)

        tv = Gtk.TreeView(model=self._iface_store)
        for i, title in enumerate([translator.get('Interface'), translator.get('Family'), translator.get('Address')]):
            r = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(title, r, text=i)
            col.set_resizable(True)
            col.set_expand(True if i == 2 else False)
            tv.append_column(col)

        sw_tv = Gtk.ScrolledWindow()
        sw_tv.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw_tv.set_min_content_height(160)
        sw_tv.add(tv)
        frame_if.add(sw_tv)


        frame_route = InfoFrame(translator.get('Routing'))
        root.pack_start(frame_route, False, False, 0)
        self._lbl_route = Gtk.Label(xalign=0)
        self._lbl_route.set_selectable(True)
        self._lbl_route.set_line_wrap(True)
        frame_route.add(self._lbl_route)


        frame_dns = InfoFrame(translator.get('DNS'))
        root.pack_start(frame_dns, False, False, 0)
        self._lbl_dns = Gtk.Label(xalign=0)
        self._lbl_dns.set_selectable(True)
        self._lbl_dns.set_line_wrap(True)
        frame_dns.add(self._lbl_dns)


        frame_test = InfoFrame(translator.get('Connectivity test'))
        root.pack_start(frame_test, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._btn_test = Gtk.Button(label=translator.get('Run test'))
        self._btn_test.connect('clicked', self._on_test)
        self._lbl_test = Gtk.Label(xalign=0)
        self._lbl_test.set_selectable(True)
        row.pack_start(self._btn_test, False, False, 0)
        row.pack_start(self._lbl_test, True, True, 0)
        frame_test.add(row)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(root)
        return sw

    def reload(self):
        
        self._iface_store.clear()
        for item in ip_addr():
            self._iface_store.append([item.get('iface', ''), item.get('family', ''), item.get('addr', '')])


        route = default_route().strip() or translator.get('N/A')
        dns = dns_servers()
        dns_txt = ', '.join(dns) if dns else translator.get('N/A')

        if self._lbl_route is not None:
            self._lbl_route.set_text(route)
        if self._lbl_dns is not None:
            self._lbl_dns.set_text(dns_txt)

        self._data = {
            'interfaces': [
                {'iface': r[0], 'family': r[1], 'addr': r[2]}
                for r in self._iface_store
            ],
            'default_route': route,
            'dns_servers': dns,
        }

    def update(self):
        
        self.reload()

    def get_data(self):
        return dict(self._data)

    def _on_test(self, _btn):
        if self._btn_test is None or self._lbl_test is None:
            return
        self._btn_test.set_sensitive(False)
        self._lbl_test.set_text(translator.get('Testing...'))

        def worker():

            res_ip = run_cmd(['ping', '-c', '1', '-W', '2', '1.1.1.1'], timeout=4.0)
            res_host = run_cmd(['ping', '-c', '1', '-W', '2', 'google.com'], timeout=4.0)

            ok_ip = res_ip.ok
            ok_host = res_host.ok

            msg = f"1.1.1.1: {'OK' if ok_ip else 'FAIL'} | google.com: {'OK' if ok_host else 'FAIL'}"

            def done():
                if self._lbl_test is not None:
                    self._lbl_test.set_text(msg)
                if self._btn_test is not None:
                    self._btn_test.set_sensitive(True)
                return False

            GLib.idle_add(done)

        threading.Thread(target=worker, daemon=True).start()
