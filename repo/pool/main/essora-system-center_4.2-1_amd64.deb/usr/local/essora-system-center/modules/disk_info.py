#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Disk information module — PartView circles style.

Uses probepart + df to get partition data and renders each partition
as a circular progress ring card (GTK3 Cairo), same as PartView Modern.
"""

from __future__ import annotations

import math
import subprocess

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from ui.widgets import InfoFrame
from utils.translations import translator


def _fmt_kb(kb: int) -> str:
    if kb == 0:
        return "0 B"
    units = ['KB', 'MB', 'GB', 'TB']
    size = float(kb)
    ui = 0
    while size >= 1024 and ui < len(units) - 1:
        size /= 1024
        ui += 1
    if size >= 100:
        return f"{size:.0f} {units[ui]}"
    elif size >= 10:
        return f"{size:.1f} {units[ui]}"
    return f"{size:.2f} {units[ui]}"


def _get_df_map() -> dict[str, tuple[int, int]]:
    """Return {'/dev/sdaX': (size_kb, used_kb)} from df -k."""
    result: dict[str, tuple[int, int]] = {}
    try:
        out = subprocess.run(['df', '-k'], capture_output=True, text=True).stdout
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 3:
                try:
                    result[parts[0]] = (int(parts[1]), int(parts[2]))
                except ValueError:
                    pass
    except Exception:
        pass
    return result


class _PartitionCard(Gtk.Box):

    def __init__(self, device: str, fs_type: str, size_kb: int,
                 used_kb: int, mounted: bool):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self._size_kb = size_kb
        self._used_kb = used_kb
        self._pct = (used_kb / size_kb) if size_kb > 0 else 0.0

        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.IN)
        frame.set_margin_start(6)
        frame.set_margin_end(6)
        frame.set_margin_top(4)
        frame.set_margin_bottom(4)

        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        hbox.set_margin_start(14)
        hbox.set_margin_end(14)
        hbox.set_margin_top(12)
        hbox.set_margin_bottom(12)

        da = Gtk.DrawingArea()
        da.set_size_request(90, 90)
        da.connect('draw', self._draw_ring)
        hbox.pack_start(da, False, False, 0)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        vbox.set_valign(Gtk.Align.CENTER)

        lbl_dev = Gtk.Label()
        lbl_dev.set_markup(f'<b>{device}</b>')
        lbl_dev.set_halign(Gtk.Align.START)
        vbox.pack_start(lbl_dev, False, False, 0)

        if fs_type:
            lbl_fs = Gtk.Label(label=fs_type)
            lbl_fs.set_halign(Gtk.Align.START)
            lbl_fs.get_style_context().add_class('dim-label')
            vbox.pack_start(lbl_fs, False, False, 0)

        free_kb = max(0, size_kb - used_kb)

        lbl_size = Gtk.Label()
        lbl_size.set_markup(
            f'<small>{translator.get("Total")}: <b>{_fmt_kb(size_kb)}</b></small>'
        )
        lbl_size.set_halign(Gtk.Align.START)
        vbox.pack_start(lbl_size, False, False, 0)

        lbl_used = Gtk.Label()
        lbl_used.set_markup(
            f'<small>{translator.get("Used")}: <b>{_fmt_kb(used_kb)}</b>'
            f' \u2022 {translator.get("Free")}: <b>{_fmt_kb(free_kb)}</b></small>'
        )
        lbl_used.set_halign(Gtk.Align.START)
        vbox.pack_start(lbl_used, False, False, 0)

        if mounted:
            lbl_mnt = Gtk.Label()
            lbl_mnt.set_markup(f'<small>\u25cf {translator.get("Mounted")}</small>')
            lbl_mnt.set_halign(Gtk.Align.START)
            vbox.pack_start(lbl_mnt, False, False, 0)

        hbox.pack_start(vbox, True, True, 0)
        frame.add(hbox)
        self.pack_start(frame, True, True, 0)

    def _draw_ring(self, widget, cr):
        w = widget.get_allocated_width()
        h = widget.get_allocated_height()
        cx, cy = w / 2, h / 2
        radius = min(w, h) / 2 - 8
        lw = 10

        sc = widget.get_style_context()
        fg = sc.get_color(Gtk.StateFlags.NORMAL)

        cr.set_line_width(lw)
        cr.set_source_rgba(fg.red, fg.green, fg.blue, 0.18)
        cr.arc(cx, cy, radius, 0, 2 * math.pi)
        cr.stroke()

        pct = self._pct
        if pct > 0:
            if pct < 0.5:
                r, g, b = 0.0, 0.78, 0.59
            elif pct < 0.75:
                r, g, b = 1.0, 0.76, 0.0
            else:
                r, g, b = 1.0, 0.26, 0.26
            cr.set_source_rgba(r, g, b, 1.0)
            cr.set_line_width(lw)
            cr.set_line_cap(1)
            start = -math.pi / 2
            cr.arc(cx, cy, radius, start, start + 2 * math.pi * pct)
            cr.stroke()

        cr.set_source_rgba(fg.red, fg.green, fg.blue, 1.0)
        cr.select_font_face("Sans", 0, 1)
        cr.set_font_size(17)
        text = f"{int(pct * 100)}%"
        ext = cr.text_extents(text)
        cr.move_to(cx - ext.width / 2, cy + ext.height / 2)
        cr.show_text(text)
        return False


class DiskInfoModule:
    """Disks tab — PartView circles only, powered by probepart."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget: Gtk.Widget | None = None
        self._grid: Gtk.Grid | None = None
        self._status: Gtk.Label | None = None

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn = Gtk.Button(label=translator.get('Reload'))
        btn.get_style_context().add_class('essora-button')
        btn.connect('clicked', lambda *_: self.reload())
        actions.pack_start(btn, False, False, 0)

        self._status = Gtk.Label(label='')
        self._status.set_xalign(0)
        actions.pack_start(self._status, True, True, 0)
        root.pack_start(actions, False, False, 0)

        frame = InfoFrame(translator.get('Disks'))

        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self._grid = Gtk.Grid()
        self._grid.set_column_spacing(8)
        self._grid.set_row_spacing(4)
        self._grid.set_column_homogeneous(True)
        self._grid.set_margin_top(8)
        self._grid.set_margin_bottom(8)

        sc.add(self._grid)
        frame.content.pack_start(sc, True, True, 0)
        root.pack_start(frame, True, True, 0)

        return root

    def reload(self):
        if not self._grid:
            return
        if self._status:
            self._status.set_text(translator.get('Loading\u2026'))

        for ch in self._grid.get_children():
            self._grid.remove(ch)

        cards = self._build_cards()

        if cards:
            for i, card in enumerate(cards):
                self._grid.attach(card, i % 2, i // 2, 1, 1)
        else:
            lbl = Gtk.Label(label=translator.get('No partition data available'))
            self._grid.attach(lbl, 0, 0, 2, 1)

        self._grid.show_all()

        if self._status:
            self._status.set_text(translator.get('Ready'))

    def update(self):
        self.reload()

    def _build_cards(self) -> list[_PartitionCard]:
        df_map = _get_df_map()
        cards: list[_PartitionCard] = []

        try:
            result = subprocess.run(
                ['probepart', '-k', '-extra-info'],
                capture_output=True, text=True
            )
            lines = result.stdout.strip().splitlines() if result.stdout.strip() else []
        except FileNotFoundError:
            lines = []

        for line in lines:
            if not line.strip():
                continue
            parts = line.split('|')
            if len(parts) < 3:
                continue

            device  = parts[0].replace('/dev/', '')
            fs_type = parts[1]
            size_kb = int(parts[2]) if parts[2].isdigit() else 0
            mounted = len(parts) > 4 and parts[4] == 'mounted'

            used_kb = 0
            dev_path = f'/dev/{device}'
            if dev_path in df_map:
                used_kb = df_map[dev_path][1]
                mounted = True

            if fs_type in ('none', '') and size_kb == 0:
                continue

            cards.append(_PartitionCard(
                device=device,
                fs_type=fs_type,
                size_kb=size_kb,
                used_kb=used_kb,
                mounted=mounted,
            ))

        return cards
