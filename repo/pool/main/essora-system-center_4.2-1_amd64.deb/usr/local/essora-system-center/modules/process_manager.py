#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Pango

import os
import signal
import subprocess
import threading
from dataclasses import dataclass
from typing import List, Optional

from utils.translations import translator

@dataclass
class Process:
    """Representa un proceso del sistema"""
    pid: int
    user: str
    cpu: float
    mem: float
    vsz: int
    rss: int
    command: str
    state: str

class ProcessManagerModule:
    """Módulo de gestión de procesos"""
    
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None
        self.current_process = None
        self.process_store = None
        self.filter_model = None
        
    def get_content(self):
        """Obtener widget de contenido del módulo"""
        if self.content_widget is None:
            self.content_widget = self.create_content()
        return self.content_widget
    
    def create_content(self):
        """Crear contenido del módulo"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        
        
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        
        
        search_label = Gtk.Label(label=translator.get("Search") + ":")
        toolbar.pack_start(search_label, False, False, 0)
        
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("search-changed", self.on_search_changed)
        toolbar.pack_start(self.search_entry, True, True, 0)
        
       
        reload_btn = Gtk.Button(label=translator.get("Reload"))
        reload_btn.connect("clicked", self.on_reload_clicked)
        reload_btn.get_style_context().add_class("essora-button")
        toolbar.pack_start(reload_btn, False, False, 0)
        
        main_box.pack_start(toolbar, False, False, 0)
        
        
        process_area = self.create_process_area()
        main_box.pack_start(process_area, True, True, 0)
        

        self.status_label = Gtk.Label()
        self.status_label.set_halign(Gtk.Align.START)
        main_box.pack_start(self.status_label, False, False, 0)
        

        self.load_processes()
        
        return main_box
    
    def create_process_area(self):
        """Crear área de visualización de procesos"""
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_vexpand(True)
        

        self.process_store = Gtk.ListStore(int, str, float, float, int, int, str, str)
        self.filter_model = self.process_store.filter_new()
        self.filter_model.set_visible_func(self.process_filter_func)
        
        self.process_tree = Gtk.TreeView(model=self.filter_model)
        self.process_tree.set_search_column(7)
        

        columns = [
            ("PID", 0, 70),
            (translator.get("User"), 1, 90),
            ("CPU%", 2, 70),
            ("MEM%", 3, 70),
            ("VSZ", 4, 90),
            ("RSS", 5, 90),
            (translator.get("State"), 6, 70),
            (translator.get("Command"), 7, 300)
        ]
        
        for title, col_id, width in columns:
            if col_id in [2, 3]:  
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer)
                column.set_cell_data_func(renderer, self.format_percentage, col_id)
            elif col_id in [4, 5]: 
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer)
                column.set_cell_data_func(renderer, self.format_memory, col_id)
            else:
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            
            column.set_resizable(True)
            column.set_min_width(width)
            column.set_sort_column_id(col_id)
            self.process_tree.append_column(column)
        

        selection = self.process_tree.get_selection()
        selection.connect("changed", self.on_process_selected)
        

        self.process_tree.connect("row-activated", self.on_row_activated)
        
        scrolled.add(self.process_tree)
        vbox.pack_start(scrolled, True, True, 0)
        
       
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        self.terminate_btn = Gtk.Button(label=translator.get("Terminate (SIGTERM)"))
        self.terminate_btn.connect("clicked", self.on_terminate_clicked)
        self.terminate_btn.set_sensitive(False)
        self.terminate_btn.get_style_context().add_class("essora-button")
        button_box.pack_start(self.terminate_btn, False, False, 0)
        
        self.kill_btn = Gtk.Button(label=translator.get("Force Kill (SIGKILL)"))
        self.kill_btn.connect("clicked", self.on_kill_clicked)
        self.kill_btn.set_sensitive(False)
        self.kill_btn.get_style_context().add_class("essora-button")
        button_box.pack_start(self.kill_btn, False, False, 0)
        
        vbox.pack_start(button_box, False, False, 0)
        
        return vbox
    
    def format_percentage(self, column, cell, model, iter_, col_id):
        """Formatear porcentajes"""
        value = model.get_value(iter_, col_id)
        cell.set_property('text', f'{value:.1f}')
    
    def format_memory(self, column, cell, model, iter_, col_id):
        """Formatear memoria"""
        value = model.get_value(iter_, col_id)
        mb = value / 1024
        cell.set_property('text', f'{mb:.1f} MB')
    
    def process_filter_func(self, model, iter_, data):
        """Función de filtrado"""
        search_text = self.search_entry.get_text().lower()
        if not search_text:
            return True
        
        
        pid = str(model.get_value(iter_, 0))
        user = model.get_value(iter_, 1).lower()
        command = model.get_value(iter_, 7).lower()
        
        return (search_text in pid or 
                search_text in user or 
                search_text in command)
    
    def on_search_changed(self, entry):
        """Cambio en búsqueda"""
        self.filter_model.refilter()
    
    def on_reload_clicked(self, button):
        """Recargar procesos"""
        self.load_processes()
    
    def on_process_selected(self, selection):
        """Proceso seleccionado"""
        model, tree_iter = selection.get_selected()
        if tree_iter:
            self.current_process = model.get_value(tree_iter, 0)
            self.terminate_btn.set_sensitive(True)
            self.kill_btn.set_sensitive(True)
            
            
            user = model.get_value(tree_iter, 1)
            cpu = model.get_value(tree_iter, 2)
            mem = model.get_value(tree_iter, 3)
            command = model.get_value(tree_iter, 7)
            
            self.status_label.set_text(
                f"PID: {self.current_process} | {translator.get('User')}: {user} | "
                f"CPU: {cpu:.1f}% | MEM: {mem:.1f}% | {command}"
            )
        else:
            self.current_process = None
            self.terminate_btn.set_sensitive(False)
            self.kill_btn.set_sensitive(False)
            self.status_label.set_text("")
    
    def on_row_activated(self, treeview, path, column):
        """Doble clic en fila"""
        
        pass
    
    def on_terminate_clicked(self, button):
        """Terminar proceso (SIGTERM)"""
        if not self.current_process:
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=translator.get("Terminate process?")
        )
        dialog.format_secondary_text(
            translator.get("Are you sure you want to terminate process {} (SIGTERM)?").format(
                self.current_process
            )
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.kill_process(signal.SIGTERM)
    
    def on_kill_clicked(self, button):
        """Matar proceso (SIGKILL)"""
        if not self.current_process:
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=translator.get("Force kill process?")
        )
        dialog.format_secondary_text(
            translator.get("Are you sure you want to force kill process {} (SIGKILL)?").format(
                self.current_process
            )
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.kill_process(signal.SIGKILL)
    
    def load_processes(self):
        """Cargar procesos"""
        def load():
            try:
                processes = self.get_process_list()
                GLib.idle_add(self.update_process_list, processes)
            except Exception as e:
                GLib.idle_add(self.show_error, str(e))
        
        thread = threading.Thread(target=load, daemon=True)
        thread.start()
    
    def get_process_list(self) -> List[Process]:
        """Obtener lista de procesos"""
        try:
            result = subprocess.run(
                ['ps', 'aux', '--sort=-%cpu'],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            processes = []
            lines = result.stdout.strip().split('\n')[1:]  # Saltar encabezado
            
            for line in lines:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    try:
                        processes.append(Process(
                            pid=int(parts[1]),
                            user=parts[0],
                            cpu=float(parts[2]),
                            mem=float(parts[3]),
                            vsz=int(parts[4]),
                            rss=int(parts[5]),
                            state=parts[7],
                            command=parts[10]
                        ))
                    except (ValueError, IndexError):
                        continue
            
            return processes
            
        except subprocess.TimeoutExpired:
            return []
        except Exception:
            return []
    
    def update_process_list(self, processes: List[Process]):
        """Actualizar lista de procesos"""
        self.process_store.clear()
        
        for proc in processes:
            self.process_store.append([
                proc.pid,
                proc.user,
                proc.cpu,
                proc.mem,
                proc.vsz,
                proc.rss,
                proc.state,
                proc.command
            ])
        
        self.status_label.set_text(
            translator.get("Processes loaded: {}").format(len(processes))
        )
    
    def kill_process(self, sig: int):
        """Matar proceso"""
        if not self.current_process:
            return
        
        def kill():
            try:
                os.kill(self.current_process, sig)
                GLib.idle_add(self.show_success,
                            translator.get("Success"),
                            translator.get("Process {} terminated successfully").format(
                                self.current_process
                            ))
                
                import time
                time.sleep(0.5)
                GLib.idle_add(self.load_processes)
            except ProcessLookupError:
                GLib.idle_add(self.show_error,
                            translator.get("Process not found"))
            except PermissionError:
                GLib.idle_add(self.show_error,
                            translator.get("Permission denied"))
            except Exception as e:
                GLib.idle_add(self.show_error, str(e))
        
        thread = threading.Thread(target=kill, daemon=True)
        thread.start()
    
    def show_error(self, message):
        """Mostrar error"""
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=translator.get("Error")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_success(self, title, message):
        """Mostrar éxito"""
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def on_activate(self):
        """Cuando se activa el módulo"""
        self.load_processes()
    
    def update(self):
        """Actualizar datos"""
        self.load_processes()
    
    def reload(self):
        """Recargar completamente"""
        self.load_processes()
    
    def get_data(self):
        """Obtener datos para exportar"""
        processes = self.get_process_list()
        return {
            "count": len(processes),
            "processes": [
                {
                    "pid": p.pid,
                    "user": p.user,
                    "cpu": p.cpu,
                    "mem": p.mem,
                    "command": p.command,
                    "state": p.state
                }
                for p in processes[:100] 
            ]
        }
