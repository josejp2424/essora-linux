#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Pango, GdkPixbuf

import os
import platform
import subprocess
import socket
from datetime import datetime
from pathlib import Path

from utils.translations import translator

class SystemInfoModule:
    """Módulo de información del sistema"""
    
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None
    
    def get_content(self):
        """Obtener widget de contenido"""
        if self.content_widget is None:
            self.content_widget = self.create_content()
        return self.content_widget
    
    def create_content(self):
        """Crear contenido del módulo"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        

        header_box = self.create_header()
        main_box.pack_start(header_box, False, False, 0)
        
        # Separador
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        sep.set_margin_top(10)
        sep.set_margin_bottom(10)
        main_box.pack_start(sep, False, False, 0)
        
        # Información del sistema
        system_info = self.create_system_info()
        main_box.pack_start(system_info, True, True, 0)
        
        return main_box
    
    def create_header(self):
        """Crear encabezado con logo"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        
        
        logo_paths = [
            "/usr/local/essora-kit/essora-logo.svg",
            "/usr/share/pixmaps/essora-logo.png",
            Path(__file__).parent.parent / "assets" / "icons" / "essora-logo.svg"
        ]
        
        logo_loaded = False
        for logo_path in logo_paths:
            if Path(logo_path).exists():
                try:
                    pixbuf = Gtk.gdk.pixbuf_new_from_file_at_size(str(logo_path), 64, 64)
                    logo_img = Gtk.Image.new_from_pixbuf(pixbuf)
                    header_box.pack_start(logo_img, False, False, 0)
                    logo_loaded = True
                    break
                except:
                    continue
        
        if not logo_loaded:

            logo_img = Gtk.Image.new_from_icon_name("computer", Gtk.IconSize.DIALOG)
            header_box.pack_start(logo_img, False, False, 0)
        

        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        # Nombre del sistema
        system_name = self.get_system_name()
        name_label = Gtk.Label()
        name_label.set_markup(f'<span size="x-large" weight="bold" foreground="#4A9EFF">{system_name}</span>')
        name_label.set_halign(Gtk.Align.START)
        info_box.pack_start(name_label, False, False, 0)
        
        # Kernel
        kernel = self.get_kernel_version()
        kernel_label = Gtk.Label(label=f"Kernel: {kernel}")
        kernel_label.set_halign(Gtk.Align.START)
        kernel_label.get_style_context().add_class("info-value")
        info_box.pack_start(kernel_label, False, False, 0)
        
        # Tiempo de actividad
        uptime = self.get_uptime()
        uptime_label = Gtk.Label(label=f"{translator.get('Uptime')}: {uptime}")
        uptime_label.set_halign(Gtk.Align.START)
        uptime_label.get_style_context().add_class("info-value")
        info_box.pack_start(uptime_label, False, False, 0)
        
        header_box.pack_start(info_box, True, True, 0)
        
        return header_box
    
    def create_system_info(self):
        """Crear información del sistema"""
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        
        # Información básica
        basic_frame = InfoFrame(translator.get("Basic Information"))
        basic_grid = Gtk.Grid()
        basic_grid.set_row_spacing(8)
        basic_grid.set_column_spacing(20)
        
        basic_info = [
            (translator.get("Operating System"), self.get_os_info()),
            (translator.get("Kernel Version"), self.get_kernel_version()),
            (translator.get("Architecture"), self.get_architecture()),
            (translator.get("Hostname"), self.get_hostname()),
            (translator.get("Uptime"), self.get_uptime()),
            (translator.get("Boot Time"), self.get_boot_time()),
            (translator.get("Timezone"), self.get_timezone()),
            (translator.get("Desktop Environment"), self.get_desktop_env()),
            (translator.get("Display Server"), self.get_display_server()),
            (translator.get("Window Manager"), self.get_window_manager()),
        ]
        
        for i, (label, value) in enumerate(basic_info):
            lbl = Gtk.Label(label=f"{label}:")
            lbl.set_halign(Gtk.Align.END)
            lbl.get_style_context().add_class("info-label")
            
            val = Gtk.Label(label=value)
            val.set_halign(Gtk.Align.START)
            val.set_selectable(True)
            val.get_style_context().add_class("info-value")
            
            basic_grid.attach(lbl, 0, i, 1, 1)
            basic_grid.attach(val, 1, i, 1, 1)
        
        basic_frame.add(basic_grid)
        content_box.pack_start(basic_frame, False, False, 0)
        
        # Usuarios conectados
        users_frame = InfoFrame(translator.get("Logged In Users"))
        users_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        users = self.get_logged_users()
        if users:
            for user in users:
                user_label = Gtk.Label(label=user)
                user_label.set_halign(Gtk.Align.START)
                user_label.get_style_context().add_class("info-value")
                users_box.pack_start(user_label, False, False, 0)
        else:
            no_users = Gtk.Label(label=translator.get("No users logged in"))
            no_users.set_halign(Gtk.Align.START)
            no_users.get_style_context().add_class("info-value")
            users_box.pack_start(no_users, False, False, 0)
        
        users_frame.add(users_box)
        content_box.pack_start(users_frame, False, False, 0)
        
        # Carga del sistema
        load_frame = InfoFrame(translator.get("System Load"))
        load_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        load_avg = self.get_load_average()
        load_label = Gtk.Label(label=f"{translator.get('Load Average')}: {load_avg}")
        load_label.set_halign(Gtk.Align.START)
        load_label.get_style_context().add_class("info-value")
        load_box.pack_start(load_label, False, False, 0)
        
        # Barras de carga
        load_bars = self.create_load_bars()
        load_box.pack_start(load_bars, False, False, 0)
        
        load_frame.add(load_box)
        content_box.pack_start(load_frame, False, False, 0)
        
        scrolled.add(content_box)
        return scrolled
    
    def create_load_bars(self):
        """Crear barras de carga del sistema"""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        
        try:
            import psutil
            cpu_count = psutil.cpu_count()
            load_avg = psutil.getloadavg()
            
            for i, load in enumerate(load_avg):
                if i == 0:
                    period = "1 min"
                elif i == 1:
                    period = "5 min"
                else:
                    period = "15 min"
                
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                
                label = Gtk.Label(label=f"{period}:")
                label.set_size_request(60, -1)
                label.set_halign(Gtk.Align.START)
                row.pack_start(label, False, False, 0)
                
                progress = Gtk.ProgressBar()
                progress.set_fraction(load / cpu_count if cpu_count > 0 else 0)
                progress.set_show_text(True)
                progress.set_text(f"{load:.2f} ({load/cpu_count*100:.1f}%)" if cpu_count > 0 else f"{load:.2f}")
                row.pack_start(progress, True, True, 0)
                
                box.pack_start(row, False, False, 0)
                
        except ImportError:
            label = Gtk.Label(label=translator.get("psutil not available"))
            box.pack_start(label, False, False, 0)
        
        return box
    
    
    
    def get_system_name(self):
        """Obtener nombre del sistema"""
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    if line.startswith("PRETTY_NAME="):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
        
        return platform.system()
    
    def get_os_info(self):
        """Obtener información del SO"""
        try:
            with open("/etc/os-release") as f:
                os_info = {}
                for line in f:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        os_info[key] = value.strip('"')
                
                name = os_info.get("PRETTY_NAME", os_info.get("NAME", "Unknown"))
                version = os_info.get("VERSION", os_info.get("VERSION_ID", ""))
                
                if version:
                    return f"{name} {version}"
                return name
        except:
            return f"{platform.system()} {platform.release()}"
    
    def get_kernel_version(self):
        """Obtener versión del kernel"""
        return platform.release()
    
    def get_architecture(self):
        """Obtener arquitectura"""
        arch = platform.machine()
        # Traducciones comunes
        arch_map = {
            'x86_64': 'x64 (64-bit)',
            'amd64': 'x64 (64-bit)',
            'i386': 'x86 (32-bit)',
            'i686': 'x86 (32-bit)',
            'aarch64': 'ARM64',
            'armv7l': 'ARM (32-bit)',
            'armv6l': 'ARM (32-bit)',
        }
        return arch_map.get(arch, arch)
    
    def get_hostname(self):
        """Obtener nombre del host"""
        return socket.gethostname()
    
    def get_uptime(self):
        """Obtener tiempo de actividad"""
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
            
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            
            if days > 0:
                return f"{days}d {hours}h {minutes}m"
            elif hours > 0:
                return f"{hours}h {minutes}m"
            else:
                return f"{minutes}m"
        except:
            return translator.get("N/A")
    
    def get_boot_time(self):
        """Obtener hora de arranque"""
        try:
            import psutil
            boot_time = psutil.boot_time()
            return datetime.fromtimestamp(boot_time).strftime("%Y-%m-%d %H:%M:%S")
        except:
            return translator.get("N/A")
    
    def get_timezone(self):
        """Obtener zona horaria"""
        try:
            if Path('/etc/timezone').exists():
                with open('/etc/timezone', 'r') as f:
                    return f.read().strip()
            else:
                result = subprocess.run(['timedatectl'], capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if 'Time zone' in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            return parts[1].strip().split()[0]
        except:
            pass
        
        return translator.get("N/A")
    
    def get_desktop_env(self):
        """Obtener entorno de escritorio"""
        de = os.environ.get('XDG_CURRENT_DESKTOP', '')
        if de:
            return de
        
        de = os.environ.get('DESKTOP_SESSION', '')
        if de:
            return de
        
        return translator.get("Unknown")
    
    def get_display_server(self):
        """Obtener servidor de pantalla"""
        sess = os.environ.get("XDG_SESSION_TYPE", "").lower()
        if sess == "wayland":
            return "Wayland"
        elif sess == "x11":
            return "X11"
        
        return translator.get("Unknown")
    
    def get_window_manager(self):
        """Obtener gestor de ventanas"""
        try:
            result = subprocess.run(['wmctrl', '-m'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if line.startswith('Name:'):
                    return line.split(':')[1].strip()
        except:
            pass
        
        wm = os.environ.get('DESKTOP_SESSION', '')
        return wm if wm else translator.get("Unknown")
    
    def get_logged_users(self):
        """Obtener usuarios conectados"""
        try:
            result = subprocess.run(['who'], capture_output=True, text=True)
            users = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split()
                    if len(parts) >= 1:
                        users.append(parts[0])
            return list(set(users))  # Usuarios únicos
        except:
            return []
    
    def get_load_average(self):
        """Obtener carga promedio"""
        try:
            import psutil
            load = psutil.getloadavg()
            return f"{load[0]:.2f}, {load[1]:.2f}, {load[2]:.2f}"
        except:
            try:
                with open('/proc/loadavg', 'r') as f:
                    load = f.read().strip().split()[:3]
                    return ', '.join(load)
            except:
                return translator.get("N/A")
    
    def on_activate(self):
        """Cuando se activa el módulo"""
        pass
    
    def update(self):
        """Actualizar datos"""
        
        pass
    
    def reload(self):
        """Recargar completamente"""
        pass
    
    def get_data(self):
        """Obtener datos para exportar"""
        return {
            "os": self.get_os_info(),
            "kernel": self.get_kernel_version(),
            "architecture": self.get_architecture(),
            "hostname": self.get_hostname(),
            "uptime": self.get_uptime(),
            "boot_time": self.get_boot_time(),
            "timezone": self.get_timezone(),
            "desktop": self.get_desktop_env(),
            "display_server": self.get_display_server(),
            "window_manager": self.get_window_manager(),
            "users": self.get_logged_users(),
            "load_average": self.get_load_average()
        }

class InfoFrame(Gtk.Frame):
    """Frame de información personalizado"""
    
    def __init__(self, title):
        super().__init__()
        
        self.set_shadow_type(Gtk.ShadowType.NONE)
        self.get_style_context().add_class("info-frame")
        
        
        self.label = Gtk.Label(label=title)
        self.label.set_halign(Gtk.Align.START)
        self.label.get_style_context().add_class("frame-header")
        

        self.content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        self.content_box.set_margin_top(10)
        self.content_box.set_margin_bottom(10)
        self.content_box.set_margin_start(10)
        self.content_box.set_margin_end(10)
        

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.pack_start(self.label, False, False, 0)
        
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        vbox.pack_start(sep, False, False, 0)
        
        vbox.pack_start(self.content_box, True, True, 0)

       
        Gtk.Frame.add(self, vbox)
    
    def add(self, widget):
        """Añadir widget al frame"""
        self.content_box.pack_start(widget, False, False, 0)
