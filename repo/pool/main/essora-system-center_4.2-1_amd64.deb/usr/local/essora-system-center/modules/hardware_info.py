#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Hardware information module (Hardinfo-style)."""

from __future__ import annotations

import os
import re

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from ui.widgets import InfoFrame
from utils.translations import translator
from utils.system_utils import read_text, run_cmd, human_bytes


def _read_dmi(path: str) -> str:
    try:
        if os.path.exists(path):
            return read_text(path).strip()
    except Exception:
        pass
    return ""


def _cpu_model() -> str:
    txt = read_text('/proc/cpuinfo')
    m = re.search(r'^model name\s*:\s*(.+)$', txt, flags=re.M)
    if m:
        return m.group(1).strip()
    m = re.search(r'^Hardware\s*:\s*(.+)$', txt, flags=re.M)
    if m:
        return m.group(1).strip()
    return translator.get('Unknown')


def _cpu_cores_threads() -> str:

    res = run_cmd(['nproc', '--all'], timeout=2.0)
    threads = res.stdout.strip() if res.ok else ""
    
    cores = ""
    res2 = run_cmd(['lscpu'], timeout=2.0)
    if res2.ok and res2.stdout:
        m = re.search(r'^CPU\(s\):\s*(\d+)$', res2.stdout, flags=re.M)
        if m:
            threads = threads or m.group(1)
        m = re.search(r'^Core\(s\) per socket:\s*(\d+)$', res2.stdout, flags=re.M)
        if m:
            cores = m.group(1)
    if cores and threads:
        return f"{cores} / {threads}"
    return threads or cores or translator.get('Unknown')


def _mem_total() -> str:
    txt = read_text('/proc/meminfo')
    m = re.search(r'^MemTotal:\s+(\d+)\s+kB', txt, flags=re.M)
    if not m:
        return translator.get('Unknown')
    kb = int(m.group(1))
    return human_bytes(kb * 1024)


def _gpu_line() -> str:
    res = run_cmd("sh -lc \"lspci | egrep -i 'VGA|3D|Display' | head -n 1\"", timeout=3.0)
    if res.ok and res.stdout:
        return res.stdout
    return translator.get('N/A')


class HardwareInfoModule:
    """Hardware tab."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None

        self._values: dict[str, Gtk.Label] = {}
        self._last_data: dict[str, str] = {}

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        # Sections
        self.frame_cpu = InfoFrame(translator.get('CPU'))
        self.frame_mem = InfoFrame(translator.get('Memory'))
        self.frame_other = InfoFrame(translator.get('Devices'))

        root.pack_start(self.frame_cpu, False, False, 0)
        root.pack_start(self.frame_mem, False, False, 0)
        root.pack_start(self.frame_other, False, False, 0)

        # CPU grid
        cpu_grid = Gtk.Grid(column_spacing=16, row_spacing=8)
        self.frame_cpu.add(cpu_grid)
        self._add_row(cpu_grid, 0, translator.get('Model'), '')
        self._add_row(cpu_grid, 1, translator.get('Cores/Threads'), '')
        self._add_row(cpu_grid, 2, translator.get('Architecture'), '')

        # Memory grid
        mem_grid = Gtk.Grid(column_spacing=16, row_spacing=8)
        self.frame_mem.add(mem_grid)
        self._add_row(mem_grid, 0, translator.get('Total'), '')

        # Other devices grid
        dev_grid = Gtk.Grid(column_spacing=16, row_spacing=8)
        self.frame_other.add(dev_grid)
        self._add_row(dev_grid, 0, translator.get('GPU'), '')
        self._add_row(dev_grid, 1, translator.get('Motherboard'), '')
        self._add_row(dev_grid, 2, translator.get('BIOS'), '')

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(root)
        return sw

    def _add_row(self, grid: Gtk.Grid, row: int, key: str, value: str):
        k = Gtk.Label(label=key, xalign=0)
        k.get_style_context().add_class('dim-label')
        v = Gtk.Label(label=value, xalign=0)
        v.set_selectable(True)
        v.set_line_wrap(True)
        grid.attach(k, 0, row, 1, 1)
        grid.attach(v, 1, row, 1, 1)
        self._values[key] = v

    def _set(self, key: str, value: str):
        if key in self._values:
            self._values[key].set_text(value if value else translator.get('Unknown'))

    def reload(self):
        # CPU
        self._set(translator.get('Model'), _cpu_model())
        self._set(translator.get('Cores/Threads'), _cpu_cores_threads())
        arch = run_cmd(['uname', '-m'], timeout=2.0).stdout or translator.get('Unknown')
        self._set(translator.get('Architecture'), arch)

        # Memory
        self._set(translator.get('Total'), _mem_total())

        # Devices
        self._set(translator.get('GPU'), _gpu_line())

        board = " ".join([x for x in [
            _read_dmi('/sys/devices/virtual/dmi/id/board_vendor'),
            _read_dmi('/sys/devices/virtual/dmi/id/board_name'),
            _read_dmi('/sys/devices/virtual/dmi/id/board_version'),
        ] if x]).strip()
        self._set(translator.get('Motherboard'), board or translator.get('N/A'))

        bios = " ".join([x for x in [
            _read_dmi('/sys/devices/virtual/dmi/id/bios_vendor'),
            _read_dmi('/sys/devices/virtual/dmi/id/bios_version'),
            _read_dmi('/sys/devices/virtual/dmi/id/bios_date'),
        ] if x]).strip()
        self._set(translator.get('BIOS'), bios or translator.get('N/A'))

       
        self._last_data = {
            'cpu_model': _cpu_model(),
            'cores_threads': _cpu_cores_threads(),
            'architecture': arch,
            'memory_total': _mem_total(),
            'gpu': _gpu_line(),
            'motherboard': board or "",
            'bios': bios or "",
        }

    def update(self):
        
        return

    def get_data(self):
        if not self._last_data:
            self.reload()
        return dict(self._last_data)
