#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Software information module.

Shows package counts (dpkg/flatpak/appimage) and basic runtime versions.
"""

from __future__ import annotations

import os
import sys

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from ui.widgets import InfoFrame
from utils.translations import translator
from utils.system_utils import appimage_count, dpkg_count, flatpak_count, get_os_release, run_cmd


def _cmd_version(cmd: list[str]) -> str:
    res = run_cmd(cmd, timeout=3.0)
    if res.ok and res.stdout:
        return res.stdout.splitlines()[0].strip()
   
    if res.stderr:
        return res.stderr.splitlines()[0].strip()
    return translator.get('N/A')



def _gtk_runtime_version() -> str:
    """Return GTK runtime version without invoking gtk-query-immodules.

        self._set('gtk', _gtk_runtime_version())
    'Cannot load module ... --version.so'. We avoid that by asking Gtk itself.
    """
    try:
        return f"{Gtk.get_major_version()}.{Gtk.get_minor_version()}.{Gtk.get_micro_version()}"
    except Exception:
        
        v = _cmd_version(['pkg-config', '--modversion', 'gtk+-3.0'])
        return v or translator.get('N/A')

class SoftwareInfoModule:
    """Software tab."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None

        self._values: dict[str, Gtk.Label] = {}
        self._last_data: dict[str, object] = {}

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        frame_pkgs = InfoFrame(translator.get('Packages'))
        frame_runtimes = InfoFrame(translator.get('Runtimes'))
        frame_env = InfoFrame(translator.get('Environment'))

        root.pack_start(frame_pkgs, False, False, 0)
        root.pack_start(frame_runtimes, False, False, 0)
        root.pack_start(frame_env, False, False, 0)

        # Packages
        g1 = Gtk.Grid(column_spacing=16, row_spacing=8)
        frame_pkgs.add(g1)
        self._add_row(g1, 0, 'dpkg', translator.get('Deb packages (dpkg)'), '')
        self._add_row(g1, 1, 'flatpak', translator.get('Flatpak apps'), '')
        self._add_row(g1, 2, 'appimage', translator.get('AppImages'), '')

        # Runtimes
        g2 = Gtk.Grid(column_spacing=16, row_spacing=8)
        frame_runtimes.add(g2)
        self._add_row(g2, 0, 'python', translator.get('Python'), '')
        self._add_row(g2, 1, 'glibc', translator.get('glibc'), '')
        self._add_row(g2, 2, 'gtk', translator.get('GTK'), '')

        # Environment
        g3 = Gtk.Grid(column_spacing=16, row_spacing=8)
        frame_env.add(g3)
        self._add_row(g3, 0, 'distro', translator.get('Distribution'), '')
        self._add_row(g3, 1, 'session', translator.get('Session'), '')
        self._add_row(g3, 2, 'lang', translator.get('Language'), '')

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(root)
        return sw

    def _add_row(self, grid: Gtk.Grid, row: int, store_key: str, label: str, value: str):
        k = Gtk.Label(label=label, xalign=0)
        k.get_style_context().add_class('dim-label')
        v = Gtk.Label(label=value, xalign=0)
        v.set_selectable(True)
        v.set_line_wrap(True)
        grid.attach(k, 0, row, 1, 1)
        grid.attach(v, 1, row, 1, 1)
        self._values[store_key] = v

    def _set(self, store_key: str, value: str):
        if store_key in self._values:
            self._values[store_key].set_text(value if value else translator.get('N/A'))

    def reload(self):
        
        d = dpkg_count()
        f = flatpak_count()
        a = appimage_count([os.path.expanduser('~/Applications'), '/opt', '/usr/local/bin'])

        self._set('dpkg', str(d) if d is not None else translator.get('N/A'))
        self._set('flatpak', str(f) if f is not None else translator.get('N/A'))
        self._set('appimage', str(a) if a is not None else translator.get('N/A'))

        # Runtimes
        self._set('python', sys.version.split()[0])
        self._set('glibc', _cmd_version(['ldd', '--version']))
        self._set('gtk', _gtk_runtime_version())

        # Env
        osr = get_os_release()
        distro = osr.get('PRETTY_NAME') or osr.get('NAME') or translator.get('Unknown')
        session = os.environ.get('XDG_SESSION_TYPE') or translator.get('Unknown')
        lang = os.environ.get('LANG') or translator.get('Unknown')
        self._set('distro', distro)
        self._set('session', session)
        self._set('lang', lang)

        self._last_data = {
            'dpkg_count': d,
            'flatpak_count': f,
            'appimage_count': a,
            'python': sys.version.split()[0],
            'glibc': self._values['glibc'].get_text(),
            'gtk': self._values['gtk'].get_text(),
            'distro': distro,
            'session': session,
            'lang': lang,
        }

    def update(self):
        
        return

    def get_data(self):
        if not self._last_data:
            self.reload()
        return dict(self._last_data)
