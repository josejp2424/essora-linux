#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Resources monitor module.

Lightweight monitor based on psutil (CPU/RAM/SWAP + basic IO rates).
MainWindow calls update() periodically when the tab is active.
"""

from __future__ import annotations

import time

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

try:
    import psutil
except Exception:
    psutil = None 

from ui.widgets import InfoFrame, ProgressSection
from utils.translations import translator
from utils.system_utils import human_bytes


class ResourcesMonitorModule:
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget = None

        
        self._last_t = None
        self._last_net = None
        self._last_disk = None

        self._data: dict[str, object] = {}

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        if psutil is None:
            lab = Gtk.Label(label=translator.get('psutil is not installed'))
            lab.set_halign(Gtk.Align.START)
            root.pack_start(lab, False, False, 0)
            sw = Gtk.ScrolledWindow()
            sw.add(root)
            return sw

        frame_usage = InfoFrame(translator.get('Usage'))
        root.pack_start(frame_usage, False, False, 0)

        self.cpu = ProgressSection(translator.get('CPU'))
        self.mem = ProgressSection(translator.get('Memory'))
        self.swap = ProgressSection(translator.get('Swap'))

        frame_usage.add(self.cpu)
        frame_usage.add(self.mem)
        frame_usage.add(self.swap)

        frame_io = InfoFrame(translator.get('I/O'))
        root.pack_start(frame_io, False, False, 0)

        self.lbl_disk = Gtk.Label(xalign=0)
        self.lbl_disk.set_selectable(True)
        self.lbl_net = Gtk.Label(xalign=0)
        self.lbl_net.set_selectable(True)
        frame_io.add(self.lbl_disk)
        frame_io.add(self.lbl_net)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(root)
        return sw

    def reload(self):
        if psutil is None:
            return
        # init baseline for rates
        self._last_t = time.time()
        self._last_net = psutil.net_io_counters() if hasattr(psutil, 'net_io_counters') else None
        self._last_disk = psutil.disk_io_counters() if hasattr(psutil, 'disk_io_counters') else None
       
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass
        self.update()

    def update(self):
        if psutil is None:
            return

        # CPU
        try:
            cpu_pct = psutil.cpu_percent(interval=None) / 100.0
        except Exception:
            cpu_pct = 0.0
        self.cpu.set_fraction(cpu_pct, f"{cpu_pct*100:.0f}%")

        # Memory
        try:
            vm = psutil.virtual_memory()
            mem_pct = vm.percent / 100.0
            mem_txt = f"{vm.percent:.0f}%  ({human_bytes(vm.used)} / {human_bytes(vm.total)})"
        except Exception:
            mem_pct = 0.0
            mem_txt = translator.get('N/A')
        self.mem.set_fraction(mem_pct, mem_txt)

        # Swap
        try:
            sm = psutil.swap_memory()
            swap_pct = sm.percent / 100.0
            swap_txt = f"{sm.percent:.0f}%  ({human_bytes(sm.used)} / {human_bytes(sm.total)})"
        except Exception:
            swap_pct = 0.0
            swap_txt = translator.get('N/A')
        self.swap.set_fraction(swap_pct, swap_txt)

        # Rates
        now = time.time()
        dt = max(1e-3, (now - (self._last_t or now)))

        # Disk IO
        disk_rate = ""
        try:
            cur_disk = psutil.disk_io_counters()
            if self._last_disk is not None and cur_disk is not None:
                rd = (cur_disk.read_bytes - self._last_disk.read_bytes) / dt
                wr = (cur_disk.write_bytes - self._last_disk.write_bytes) / dt
                disk_rate = f"{translator.get('Disk')}: ↓ {human_bytes(rd)}/s  ↑ {human_bytes(wr)}/s"
            self._last_disk = cur_disk
        except Exception:
            disk_rate = f"{translator.get('Disk')}: {translator.get('N/A')}"

        # Net IO
        net_rate = ""
        try:
            cur_net = psutil.net_io_counters()
            if self._last_net is not None and cur_net is not None:
                rx = (cur_net.bytes_recv - self._last_net.bytes_recv) / dt
                tx = (cur_net.bytes_sent - self._last_net.bytes_sent) / dt
                net_rate = f"{translator.get('Network')}: ↓ {human_bytes(rx)}/s  ↑ {human_bytes(tx)}/s"
            self._last_net = cur_net
        except Exception:
            net_rate = f"{translator.get('Network')}: {translator.get('N/A')}"

        self.lbl_disk.set_text(disk_rate)
        self.lbl_net.set_text(net_rate)

        self._last_t = now

        self._data = {
            'cpu_percent': round(cpu_pct * 100, 1),
            'memory_percent': round(mem_pct * 100, 1) if psutil else None,
            'swap_percent': round(swap_pct * 100, 1) if psutil else None,
            'disk_rate': disk_rate,
            'net_rate': net_rate,
        }

    def get_data(self):
        return dict(self._data)
