#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Benchmarks module (quick, safe).

HardInfo incluye algunos benchmarks; acá agregamos una alternativa ligera:
- CPU (entero) mediante suma
- CPU (hash) mediante SHA-256
- Disco (I/O) opcional con archivo temporal pequeño

No requiere root, no toca nada del sistema fuera de /tmp.
"""

from __future__ import annotations

import os
import time
import hashlib
import tempfile
import threading

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from ui.widgets import InfoFrame
from utils.translations import translator


class BenchmarksModule:
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget: Gtk.Widget | None = None

        self._labels: dict[str, Gtk.Label] = {}
        self._run_btn: Gtk.Button | None = None
        self._status: Gtk.Label | None = None
        self._running = False

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
        return self.content_widget

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        frame = InfoFrame(translator.get('Benchmarks'))

        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(18)

        def add_row(r: int, key: str, label: str):
            l1 = Gtk.Label(label=f"{label}:")
            l1.set_xalign(1)
            l1.get_style_context().add_class('info-label')

            l2 = Gtk.Label(label=translator.get('Not run yet'))
            l2.set_xalign(0)
            l2.set_selectable(True)
            l2.get_style_context().add_class('info-value')

            grid.attach(l1, 0, r, 1, 1)
            grid.attach(l2, 1, r, 1, 1)
            self._labels[key] = l2

        add_row(0, 'cpu_int', translator.get('CPU Integer'))
        add_row(1, 'cpu_hash', translator.get('CPU Hash (SHA-256)'))
        add_row(2, 'disk_io', translator.get('Disk I/O (temp file)'))

        frame.add(grid)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)

        self._run_btn = Gtk.Button(label=translator.get('Run Quick Benchmarks'))
        self._run_btn.get_style_context().add_class('essora-button')
        self._run_btn.connect('clicked', self._on_run_clicked)
        actions.pack_start(self._run_btn, False, False, 0)

        self._status = Gtk.Label(label='')
        self._status.set_xalign(0)
        actions.pack_start(self._status, True, True, 0)

        root.pack_start(frame, False, False, 0)
        root.pack_start(actions, False, False, 0)

        note = Gtk.Label(
            label=translator.get('Note: benchmarks are approximate and depend on current load.')
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        root.pack_start(note, False, False, 0)

        return root

    def update(self):
        # No auto-run
        return

    def _set_status(self, text: str):
        if self._status:
            self._status.set_text(text)

    def _set_label(self, key: str, value: str):
        lab = self._labels.get(key)
        if lab:
            lab.set_text(value)

    def _on_run_clicked(self, *_):
        if self._running:
            return
        self._running = True
        if self._run_btn:
            self._run_btn.set_sensitive(False)
        self._set_status(translator.get('Running…'))

        t = threading.Thread(target=self._run_worker, daemon=True)
        t.start()

    def _run_worker(self):
        try:
            cpu_int = self._bench_cpu_int()
            GLib.idle_add(self._set_label, 'cpu_int', cpu_int)

            cpu_hash = self._bench_cpu_hash()
            GLib.idle_add(self._set_label, 'cpu_hash', cpu_hash)

            disk_io = self._bench_disk_io()
            GLib.idle_add(self._set_label, 'disk_io', disk_io)

            GLib.idle_add(self._set_status, translator.get('Done'))
        except Exception as e:
            GLib.idle_add(self._set_status, f"{translator.get('Error')}: {e}")
        finally:
            self._running = False
            if self._run_btn:
                GLib.idle_add(self._run_btn.set_sensitive, True)

    def _bench_cpu_int(self) -> str:
        
        n = 5_000_000
        t0 = time.perf_counter()
        s = 0
        for i in range(n):
            s += i
        dt = time.perf_counter() - t0
       
        if s < 0:
            return '0'
        return f"{n:,} iters in {dt:.3f}s".replace(',', '.')

    def _bench_cpu_hash(self) -> str:
       
        block = (b'Essora' * 1024)  # ~6KB
        reps = 5500  # ~33MB
        h = hashlib.sha256()
        t0 = time.perf_counter()
        for _ in range(reps):
            h.update(block)
        digest = h.hexdigest()[:12]
        dt = time.perf_counter() - t0
        mb = (len(block) * reps) / (1024 * 1024)
        speed = mb / dt if dt > 0 else 0
        return f"{mb:.0f}MB in {dt:.3f}s ({speed:.1f} MB/s) [{digest}]"

    def _bench_disk_io(self) -> str:
        
        size = 20 * 1024 * 1024
        data = os.urandom(1024 * 1024)  
        loops = size // len(data)

        # write
        t0 = time.perf_counter()
        with tempfile.NamedTemporaryFile(prefix='essora-bench-', delete=False) as f:
            path = f.name
            for _ in range(loops):
                f.write(data)
            f.flush()
            os.fsync(f.fileno())
        wt = time.perf_counter() - t0

        # read
        t1 = time.perf_counter()
        with open(path, 'rb', buffering=0) as f:
            while f.read(1024 * 1024):
                pass
        rt = time.perf_counter() - t1

        try:
            os.unlink(path)
        except Exception:
            pass

        mb = size / (1024 * 1024)
        ws = mb / wt if wt > 0 else 0
        rs = mb / rt if rt > 0 else 0
        return f"{mb:.0f}MB write {ws:.1f} MB/s, read {rs:.1f} MB/s"
