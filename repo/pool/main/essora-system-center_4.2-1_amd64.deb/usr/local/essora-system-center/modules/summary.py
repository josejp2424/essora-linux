#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Summary (About) module.

Inspirado en tu about.py, pero embebido como página dentro de Essora System Center.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from ui.widgets import InfoFrame
from utils.translations import translator
from utils.system_utils import (
    get_os_release,
    get_kernel_version,
    get_architecture,
    get_hostname,
    get_uptime_seconds,
    format_uptime,
    cpu_model,
    meminfo,
    human_bytes,
    run_cmd,
    get_disk_status,
    get_os_age_days,
)


def _first_line(s: str) -> str:
    return (s or '').splitlines()[0].strip() if (s or '').splitlines() else ''


def _glibc_version() -> str:
    res = run_cmd(['getconf', 'GNU_LIBC_VERSION'], timeout=2.0)
    if res.ok and res.stdout:
        return res.stdout
    res = run_cmd(['ldd', '--version'], timeout=2.0)
    if res.stdout:
        return _first_line(res.stdout)
    return translator.get('Unknown')


def _opengl_version() -> str:
    
    res = run_cmd(['glxinfo', '-B'], timeout=3.0)
    if res.ok and res.stdout:
        for line in res.stdout.splitlines():
            if 'OpenGL version string' in line:
                return line.split(':', 1)[-1].strip()
            if 'OpenGL core profile version string' in line:
                return line.split(':', 1)[-1].strip()
    
    res = run_cmd(['glxinfo'], timeout=3.0)
    if res.ok and res.stdout:
        for line in res.stdout.splitlines():
            if 'OpenGL version string' in line:
                return line.split(':', 1)[-1].strip()
    return translator.get('Unknown')


def _wm_name() -> str:
    
    res = run_cmd(['wmctrl', '-m'], timeout=2.0)
    if res.ok and res.stdout:
        for line in res.stdout.splitlines():
            if line.lower().startswith('name:'):
                return line.split(':', 1)[-1].strip()
    
    for k in ('XDG_CURRENT_DESKTOP', 'DESKTOP_SESSION', 'GDMSESSION'):
        v = os.environ.get(k, '').strip()
        if v:
            return v
    return translator.get('Unknown')


def _display_server() -> str:
    if os.environ.get('WAYLAND_DISPLAY'):
        return 'Wayland'
    if os.environ.get('DISPLAY'):
        return 'X11'
    return translator.get('Unknown')


def _df_root() -> tuple[str, str, str]:
    """(used, total, percent) for /"""
    res = run_cmd(['df', '-B1', '/'], timeout=2.5)
    if not res.ok or not res.stdout:
        return (translator.get('N/A'), translator.get('N/A'), translator.get('N/A'))
    lines = res.stdout.splitlines()
    if len(lines) < 2:
        return (translator.get('N/A'), translator.get('N/A'), translator.get('N/A'))
    parts = lines[1].split()
   
    if len(parts) >= 6:
        total = human_bytes(float(parts[1]))
        used = human_bytes(float(parts[2]))
        perc = parts[4]
        return (used, total, perc)
    return (translator.get('N/A'), translator.get('N/A'), translator.get('N/A'))


def _format_disk_health_line(line: str) -> str:
    """Extrae un texto corto a partir de la salida de hdsentinel.

    Ejemplos comunes:
      - "Health: 100%" -> "100%"
      - "Health: 100% (Excellent)" -> "100% (Excellent)"
    """
    s = (line or '').strip()
    if not s:
        return ''
   
    m = re.search(r"Health\s*:\s*(.*)$", s, flags=re.IGNORECASE)
    if m:
        s = m.group(1).strip()
   
    return _first_line(s)


def _gtk_themes() -> dict[str, str]:
    out = {'gtk-theme': '', 'icon-theme': '', 'cursor-theme': ''}

    # GTK3
    p = Path(os.path.expanduser('~/.config/gtk-3.0/settings.ini'))
    if p.exists():
        txt = p.read_text(encoding='utf-8', errors='ignore')
        for line in txt.splitlines():
            line = line.strip()
            if '=' not in line:
                continue
            k, v = [x.strip() for x in line.split('=', 1)]
            if k == 'gtk-theme-name':
                out['gtk-theme'] = v
            elif k == 'gtk-icon-theme-name':
                out['icon-theme'] = v
            elif k == 'gtk-cursor-theme-name':
                out['cursor-theme'] = v

    
    if not out['gtk-theme'] or not out['icon-theme'] or not out['cursor-theme']:
        p2 = Path(os.path.expanduser('~/.gtkrc-2.0'))
        if p2.exists():
            txt = p2.read_text(encoding='utf-8', errors='ignore')
            for line in txt.splitlines():
                line = line.strip()
                if line.startswith('gtk-theme-name') and '"' in line:
                    out['gtk-theme'] = out['gtk-theme'] or re.findall(r'"(.*?)"', line)[0]
                if line.startswith('gtk-icon-theme-name') and '"' in line:
                    out['icon-theme'] = out['icon-theme'] or re.findall(r'"(.*?)"', line)[0]
                if line.startswith('gtk-cursor-theme-name') and '"' in line:
                    out['cursor-theme'] = out['cursor-theme'] or re.findall(r'"(.*?)"', line)[0]

    return out


class SummaryModule:
    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget: Gtk.Widget | None = None

        self._lbl_title: Gtk.Label | None = None
        self._rows: dict[str, Gtk.Label] = {}

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            self.reload()
        return self.content_widget

    def on_activate(self):
        
        self.reload()

    def update(self):
        
        return

    def reload(self):
        osr = get_os_release()
        distro = osr.get('PRETTY_NAME') or osr.get('NAME') or 'GNU/Linux'
        kernel = get_kernel_version()
        glibc = _glibc_version()
        opengl = _opengl_version()
        wm = _wm_name()
        display = _display_server()

        cpu = cpu_model()
        mi = meminfo()
        mt = mi.get('MemTotal', 0) * 1024
        ma = mi.get('MemAvailable', mi.get('MemFree', 0)) * 1024
        used = max(0, mt - ma)

        used_s, total_s, perc_s = _df_root()
        health_line = get_disk_status()
        health = _format_disk_health_line(health_line) if health_line else ''
        up = get_uptime_seconds()
        uptime = format_uptime(up) if up is not None else translator.get('Unknown')
        age_days = get_os_age_days()
        os_age = translator.get('{days} days', days=age_days) if age_days is not None else translator.get('Unknown')

        themes = _gtk_themes()

        if self._lbl_title:
            self._lbl_title.set_text(distro)

        self._set('kernel', kernel)
        self._set('glibc', glibc)
        self._set('opengl', opengl)
        self._set('wm', wm)
        self._set('display', display)

        self._set('cpu', cpu)
        self._set('mem', f"{human_bytes(used)} / {human_bytes(mt)}")
        self._set('disk', f"{used_s} / {total_s} ({perc_s})")
        self._set('disk_health', health or translator.get('N/A'))

        self._set('host', get_hostname())
        self._set('arch', get_architecture())
        self._set('uptime', uptime)
        self._set('os_age', os_age)

        self._set('gtk', themes.get('gtk-theme') or translator.get('Unknown'))
        self._set('icons', themes.get('icon-theme') or translator.get('Unknown'))
        self._set('cursor', themes.get('cursor-theme') or translator.get('Unknown'))

    def _set(self, key: str, value: str):
        lab = self._rows.get(key)
        if lab:
            lab.set_text(value)

    def _kv_row(self, label: str, key: str) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.set_halign(Gtk.Align.FILL)

        l1 = Gtk.Label(label=label)
        l1.set_xalign(0)
        l1.get_style_context().add_class('info-label')
        l1.set_size_request(170, -1)

        l2 = Gtk.Label(label='')
        l2.set_xalign(0)
        l2.get_style_context().add_class('info-value')
        l2.set_selectable(True)
        l2.set_line_wrap(True)

        row.pack_start(l1, False, False, 0)
        row.pack_start(l2, True, True, 0)

        self._rows[key] = l2
        return row

    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        root.set_margin_top(14)
        root.set_margin_bottom(14)
        root.set_margin_start(14)
        root.set_margin_end(14)

        title = Gtk.Label(label='')
        title.set_xalign(0)
        title.get_style_context().add_class('summary-title')
        root.pack_start(title, False, False, 0)
        self._lbl_title = title

        # SOFTWARE
        sw = InfoFrame(translator.get('Software Information'))
        sw.add(self._kv_row(translator.get('Kernel') + ':', 'kernel'))
        sw.add(self._kv_row(translator.get('glibc') + ':', 'glibc'))
        sw.add(self._kv_row(translator.get('OpenGL') + ':', 'opengl'))
        sw.add(self._kv_row(translator.get('Window Manager') + ':', 'wm'))
        sw.add(self._kv_row(translator.get('Display Server') + ':', 'display'))
        root.pack_start(sw, False, False, 0)

        # HARDWARE
        hw = InfoFrame(translator.get('Hardware Information'))
        hw.add(self._kv_row(translator.get('CPU') + ':', 'cpu'))
        hw.add(self._kv_row(translator.get('Memory') + ':', 'mem'))
        hw.add(self._kv_row(translator.get('Disk') + ':', 'disk'))
        hw.add(self._kv_row(translator.get('Disk Health') + ':', 'disk_health'))
        root.pack_start(hw, False, False, 0)

        # ADDITIONAL
        add = InfoFrame(translator.get('Additional Information'))
        add.add(self._kv_row(translator.get('Computer') + ':', 'host'))
        add.add(self._kv_row(translator.get('Arch') + ':', 'arch'))
        add.add(self._kv_row(translator.get('Uptime') + ':', 'uptime'))
        add.add(self._kv_row(translator.get('OS Age') + ':', 'os_age'))
        root.pack_start(add, False, False, 0)

        # GTK
        gtk = InfoFrame(translator.get('GTK Themes'))
        gtk.add(self._kv_row(translator.get('GTK Theme') + ':', 'gtk'))
        gtk.add(self._kv_row(translator.get('Icon Theme') + ':', 'icons'))
        gtk.add(self._kv_row(translator.get('Cursor Theme') + ':', 'cursor'))
        root.pack_start(gtk, False, False, 0)

        # filler
        root.pack_start(Gtk.Box(), True, True, 0)

        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sc.set_shadow_type(Gtk.ShadowType.NONE)
        sc.add(root)
        return sc
