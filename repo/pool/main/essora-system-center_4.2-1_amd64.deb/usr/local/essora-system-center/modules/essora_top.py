#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Essora Top (process manager) embedded module.

Basado en tu agent.py (Essora Top), pero embebido como pestaña/página dentro

Essora System Center.

- No crea una ventana nueva.
- Reutiliza estilos (CSS) desde la app principal.
- Refresca de forma segura (thread + GLib.idle_add).
"""

from __future__ import annotations

import os
import signal
import subprocess
import threading
from dataclasses import dataclass
from typing import List, Tuple, Optional

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from utils.translations import translator


@dataclass
class Process:
    pid: int
    user: str
    cpu: float
    mem: float
    vsz: int
    rss: int
    state: str
    command: str


class SystemMonitor:
    """CPU y RAM con lectura directa de /proc (sin dependencias)."""

    def __init__(self):
        self.prev_cpu_times = None
        self.prev_per_core = None

    def _read_proc_stat(self) -> List[List[int]]:
        with open('/proc/stat', 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        cpu_lines = [ln for ln in lines if ln.startswith('cpu') and (ln[3:4].isdigit() or ln.startswith('cpu '))]
        out: List[List[int]] = []
        for ln in cpu_lines:
            parts = ln.split()
           
            try:
                times = [int(x) for x in parts[1:]]
            except Exception:
                times = []
            out.append(times)
        return out

    def cpu_percent_total(self) -> float:
        try:
            rows = self._read_proc_stat()
            if not rows:
                return 0.0
            times = rows[0]
            if self.prev_cpu_times is None:
                self.prev_cpu_times = times
                return 0.0
            deltas = [t - p for t, p in zip(times, self.prev_cpu_times)]
            total_delta = sum(deltas)
            idle_delta = deltas[3] if len(deltas) > 3 else 0
            self.prev_cpu_times = times
            if total_delta <= 0:
                return 0.0
            return 100.0 * (1.0 - idle_delta / total_delta)
        except Exception:
            return 0.0

    def cpu_percent_per_core(self) -> List[float]:
        try:
            rows = self._read_proc_stat()
           
            cores = rows[1:]
            if not cores:
                return []
            if self.prev_per_core is None or len(self.prev_per_core) != len(cores):
                self.prev_per_core = cores
                return [0.0] * len(cores)

            out: List[float] = []
            new_prev: List[List[int]] = []
            for curr, prev in zip(cores, self.prev_per_core):
                deltas = [c - p for c, p in zip(curr, prev)]
                total_delta = sum(deltas)
                idle_delta = deltas[3] if len(deltas) > 3 else 0
                if total_delta <= 0:
                    out.append(0.0)
                else:
                    out.append(100.0 * (1.0 - idle_delta / total_delta))
                new_prev.append(curr)
            self.prev_per_core = new_prev
            return out
        except Exception:
            return []

    def memory_stats(self) -> Tuple[float, float, float]:
        """(percent, used_gb, total_gb)"""
        try:
            total_kb = 0
            avail_kb = 0
            with open('/proc/meminfo', 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        total_kb = int(line.split()[1])
                    elif line.startswith('MemAvailable:'):
                        avail_kb = int(line.split()[1])
            used_kb = max(0, total_kb - avail_kb)
            total_gb = total_kb / (1024 * 1024)
            used_gb = used_kb / (1024 * 1024)
            percent = (used_kb / total_kb * 100.0) if total_kb else 0.0
            return percent, used_gb, total_gb
        except Exception:
            return 0.0, 0.0, 0.0

    def task_stats(self) -> Tuple[int, int, int]:
        """(total, running, sleeping)"""
        try:
            result = subprocess.run(['ps', 'ax'], capture_output=True, text=True, timeout=4)
            lines = result.stdout.strip().split('\n')[1:]
            total = len(lines)
            running = sum(1 for l in lines if ' R ' in l or ' R+' in l)
            sleeping = sum(1 for l in lines if ' S ' in l or ' S+' in l)
            return total, running, sleeping
        except Exception:
            return 0, 0, 0


class EssoraTopModule:
    """Página embebida tipo Essora Top."""

    def __init__(self, parent_window):
        self.parent = parent_window
        self.content_widget: Optional[Gtk.Widget] = None

        self.monitor = SystemMonitor()

        self._loading = False
        self._filter_text = ''

       
        self._pb_cpu = None
        self._pb_mem = None
        self._lbl_tasks = None
        self._core_bars: List[Gtk.ProgressBar] = []

        self._store = None
        self._filter = None
        self._tree = None
        self._status = None
        self._btn_kill = None
        self._btn_force = None

    def get_content(self):
        if self.content_widget is None:
            self.content_widget = self._create_ui()
            
            self.update()
        return self.content_widget

    def on_activate(self):
        self.update()

    def update(self):
        self._update_stats()
        self._refresh_processes_async()

    # ---------------- UI ----------------
    def _create_ui(self) -> Gtk.Widget:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)

        
        stats = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        stats.get_style_context().add_class('top-stats')

       
        row1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

        cpu_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        lab_cpu = Gtk.Label(label=translator.get('CPU') + ':')
        lab_cpu.get_style_context().add_class('stats-label')
        lab_cpu.set_xalign(0)
        cpu_box.pack_start(lab_cpu, False, False, 0)

        pb_cpu = Gtk.ProgressBar()
        pb_cpu.set_show_text(True)
        pb_cpu.get_style_context().add_class('cpu-bar')
        pb_cpu.set_size_request(140, -1)
        cpu_box.pack_start(pb_cpu, False, False, 0)
        self._pb_cpu = pb_cpu

        mem_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        lab_mem = Gtk.Label(label=translator.get('Memory') + ':')
        lab_mem.get_style_context().add_class('stats-label')
        lab_mem.set_xalign(0)
        mem_box.pack_start(lab_mem, False, False, 0)

        pb_mem = Gtk.ProgressBar()
        pb_mem.set_show_text(True)
        pb_mem.get_style_context().add_class('mem-bar')
        pb_mem.set_size_request(180, -1)
        mem_box.pack_start(pb_mem, False, False, 0)
        self._pb_mem = pb_mem

        lbl_tasks = Gtk.Label(label='')
        lbl_tasks.get_style_context().add_class('stats-label')
        lbl_tasks.set_xalign(0)
        self._lbl_tasks = lbl_tasks

        row1.pack_start(cpu_box, False, False, 0)
        row1.pack_start(mem_box, False, False, 0)
        row1.pack_start(lbl_tasks, False, False, 0)
        row1.pack_start(Gtk.Box(), True, True, 0)

       
        row2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self._core_bars = []
        for i in range(8):
            core = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            lab = Gtk.Label(label=f"C{i}:")
            lab.get_style_context().add_class('stats-label')
            pb = Gtk.ProgressBar()
            pb.set_show_text(False)
            pb.set_size_request(80, 6)
            pb.get_style_context().add_class('cpu-bar')
            core.pack_start(lab, False, False, 0)
            core.pack_start(pb, False, False, 0)
            row2.pack_start(core, False, False, 0)
            self._core_bars.append(pb)

        stats.pack_start(row1, False, False, 0)
        stats.pack_start(row2, False, False, 0)
        root.pack_start(stats, False, False, 0)


        search = Gtk.SearchEntry()
        search.set_placeholder_text(translator.get('Search') + '...')
        search.connect('search-changed', self._on_search)
        root.pack_start(search, False, False, 0)


        self._store = Gtk.ListStore(int, str, float, float, int, int, str, str)
        self._filter = self._store.filter_new()
        self._filter.set_visible_func(self._filter_func)

        tree = Gtk.TreeView(model=self._filter)
        tree.get_style_context().add_class('process-tree')
        self._tree = tree

        cols = [
            (translator.get('PID'), 0, 'text'),
            (translator.get('User'), 1, 'text'),
            ('CPU%', 2, 'float'),
            ('MEM%', 3, 'float'),
            ('VSZ', 4, 'int'),
            ('RSS', 5, 'int'),
            (translator.get('State'), 6, 'text'),
            (translator.get('Command'), 7, 'text'),
        ]

        for title, idx, kind in cols:
            r = Gtk.CellRendererText()
            if kind in ('float', 'int'):
                r.set_property('xalign', 1.0)
            col = Gtk.TreeViewColumn(title, r)
            if kind == 'float':
                col.set_cell_data_func(r, self._render_float, idx)
            else:
                col.add_attribute(r, 'text', idx)
            col.set_resizable(True)
            col.set_sizing(Gtk.TreeViewColumnSizing.AUTOSIZE)
            tree.append_column(col)

        sel = tree.get_selection()
        sel.connect('changed', self._on_selection)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(tree)
        root.pack_start(sw, True, True, 0)

        # Buttons
        btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)

        b_kill = Gtk.Button(label=translator.get('Terminate') + ' (SIGTERM)')
        b_kill.set_sensitive(False)
        b_kill.connect('clicked', self._on_kill, signal.SIGTERM)
        self._btn_kill = b_kill

        b_force = Gtk.Button(label=translator.get('Force Kill') + ' (SIGKILL)')
        b_force.set_sensitive(False)
        b_force.connect('clicked', self._on_kill, signal.SIGKILL)
        self._btn_force = b_force

        btn_row.pack_start(b_kill, False, False, 0)
        btn_row.pack_start(b_force, False, False, 0)
        btn_row.pack_start(Gtk.Box(), True, True, 0)

        root.pack_start(btn_row, False, False, 0)

        # Status
        status = Gtk.Label(label='')
        status.set_xalign(0)
        status.get_style_context().add_class('muted')
        self._status = status
        root.pack_start(status, False, False, 0)

        return root

    
    def _update_stats(self):
        cpu = self.monitor.cpu_percent_total()
        cores = self.monitor.cpu_percent_per_core()
        mem_p, mem_used, mem_total = self.monitor.memory_stats()
        t_total, t_run, t_sleep = self.monitor.task_stats()

        if self._pb_cpu:
            self._pb_cpu.set_fraction(max(0.0, min(1.0, cpu / 100.0)))
            self._pb_cpu.set_text(f"{cpu:.1f}%")

        if self._pb_mem:
            self._pb_mem.set_fraction(max(0.0, min(1.0, mem_p / 100.0)))
            self._pb_mem.set_text(f"{mem_used:.1f} / {mem_total:.1f} GB ({mem_p:.1f}%)")

        if self._lbl_tasks:
            self._lbl_tasks.set_text(
                translator.get('Tasks') + f": {t_total} ({t_run} " + translator.get('running') + f", {t_sleep} " + translator.get('sleeping') + ")"
            )


        for i, pb in enumerate(self._core_bars):
            if i < len(cores):
                pb.set_fraction(max(0.0, min(1.0, cores[i] / 100.0)))
            else:
                pb.set_fraction(0.0)

    def _refresh_processes_async(self):
        if self._loading:
            return
        self._loading = True
        threading.Thread(target=self._load_processes, daemon=True).start()

    def _load_processes(self):
        procs: List[Process] = []
        err = ''
        try:
            result = subprocess.run(
                ['ps', 'aux', '--sort=-%cpu'],
                capture_output=True,
                text=True,
                timeout=6,
            )
            lines = result.stdout.strip().split('\n')[1:]
            for line in lines:
                parts = line.split(None, 10)
                if len(parts) < 11:
                    continue
                try:
                    procs.append(
                        Process(
                            pid=int(parts[1]),
                            user=parts[0],
                            cpu=float(parts[2]),
                            mem=float(parts[3]),
                            vsz=int(parts[4]),
                            rss=int(parts[5]),
                            state=parts[7],
                            command=parts[10],
                        )
                    )
                except Exception:
                    continue
        except Exception as e:
            err = str(e)

        GLib.idle_add(self._apply_processes, procs, err)

    def _apply_processes(self, procs: List[Process], err: str):
        try:
            if err and self._status:
                self._status.set_text(translator.get('Error') + f": {err}")
            elif self._status:
                self._status.set_text(translator.get('Processes loaded') + f": {len(procs)}")

            if self._store is not None:
                self._store.clear()
                for p in procs[:800]:
                    self._store.append([p.pid, p.user, p.cpu, p.mem, p.vsz, p.rss, p.state, p.command])

            if self._filter is not None:
                self._filter.refilter()
        finally:
            self._loading = False
        return False


    def _on_search(self, entry: Gtk.SearchEntry):
        self._filter_text = (entry.get_text() or '').strip().lower()
        if self._filter is not None:
            self._filter.refilter()

    def _filter_func(self, model, itr, data=None):
        if not self._filter_text:
            return True
        try:
            pid = str(model.get_value(itr, 0))
            user = str(model.get_value(itr, 1)).lower()
            cmd = str(model.get_value(itr, 7)).lower()
            q = self._filter_text
            return q in pid or q in user or q in cmd
        except Exception:
            return True

    def _render_float(self, column, cell, model, itr, col_index: int):
        try:
            v = float(model.get_value(itr, col_index))
            cell.set_property('text', f"{v:.1f}")
        except Exception:
            cell.set_property('text', '')

   
    def _on_selection(self, selection):
        model, itr = selection.get_selected()
        ok = itr is not None
        if self._btn_kill:
            self._btn_kill.set_sensitive(ok)
        if self._btn_force:
            self._btn_force.set_sensitive(ok)

    def _selected_pid(self) -> Optional[int]:
        if not self._tree:
            return None
        sel = self._tree.get_selection()
        model, itr = sel.get_selected()
        if itr is None:
            return None
        try:
            return int(model.get_value(itr, 0))
        except Exception:
            return None

    def _on_kill(self, _btn, sig):
        pid = self._selected_pid()
        if not pid:
            return
        try:
            os.kill(pid, sig)
            if self._status:
                self._status.set_text(translator.get('Signal sent to PID') + f" {pid}: {sig}")
        except PermissionError:
            if self._status:
                self._status.set_text(translator.get('Permission denied'))
        except ProcessLookupError:
            if self._status:
                self._status.set_text(translator.get('Process not found'))
        except Exception as e:
            if self._status:
                self._status.set_text(translator.get('Error') + f": {e}")

        self._refresh_processes_async()
