#!/usr/bin/env python3
# ==================== ESSORA TOP - PROCESS MANAGER v3.0 ====================
# DESARROLLADO POR josejp2424
# Description: "About" dialog for Essora Store with multi-language support
# Version: 3.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gio', '2.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, GLib, Pango, GObject, Gio, GdkPixbuf, Gdk
import subprocess
import os
import threading
import logging
from enum import Enum
from typing import List, Optional, Callable, Tuple
from dataclasses import dataclass


import sys
POSSIBLE_PATHS = [
    '/usr/local/agent-essora',  
    '/usr/share/agent-essora',  
    os.path.dirname(os.path.abspath(__file__)) 
]
for path in POSSIBLE_PATHS:
    if os.path.exists(os.path.join(path, 'translations.py')):
        if path not in sys.path:
            sys.path.insert(0, path)
        break

from translations import translator
import signal  
import time  

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('EssoraTop')

@dataclass
class Process:
    """Representa un proceso del sistema"""
    pid: int
    user: str
    cpu: float
    mem: float
    vsz: int
    rss: int
    command: str
    state: str

@dataclass
class SystemStats:
    """Estadísticas del sistema para barras superiores"""
    cpu_percent: float  
    cpu_per_core: List[float]  
    mem_percent: float
    mem_used_gb: float
    mem_total_gb: float
    cpu_count: int
    tasks_total: int
    tasks_running: int
    tasks_sleeping: int

class ProcessManager:
    """Gestiona procesos del sistema usando ps"""
    
    @staticmethod
    def get_processes() -> List[Process]:
        """Obtiene lista de procesos del sistema"""
        try:
            result = subprocess.run(
                ['ps', 'aux', '--sort=-%cpu'],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            processes = []
            lines = result.stdout.strip().split('\n')[1:]  # Skip header
            
            for line in lines:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    try:
                        processes.append(Process(
                            pid=int(parts[1]),
                            user=parts[0],
                            cpu=float(parts[2]),
                            mem=float(parts[3]),
                            vsz=int(parts[4]),
                            rss=int(parts[5]),
                            state=parts[7],
                            command=parts[10]
                        ))
                    except (ValueError, IndexError) as e:
                        logger.debug(f"Skipping malformed ps line: {e}")
                        continue
            
            return processes
            
        except subprocess.TimeoutExpired:
            logger.error("ps command timed out")
            return []
        except Exception as e:
            logger.error(f"Error getting processes: {e}", exc_info=True)
            return []
    
    @staticmethod
    def kill_process(pid: int, signal_num: int = signal.SIGTERM) -> bool:
        """Termina un proceso con la señal especificada"""
        try:
            os.kill(pid, signal_num)
            return True
        except ProcessLookupError:
            logger.warning(f"Process {pid} not found")
            return False
        except PermissionError:
            logger.error(f"Permission denied to kill process {pid}")
            return False
        except Exception as e:
            logger.error(f"Error killing process {pid}: {e}")
            return False

class SystemMonitor:
    """Monitor de recursos del sistema"""
    
    def __init__(self):
        self.prev_cpu_times = None
        self.prev_per_core = None
    
    def get_system_stats(self) -> SystemStats:
        """Obtiene estadísticas completas del sistema"""
        cpu_percent = self._get_cpu_percent()
        cpu_per_core = self._get_cpu_per_core()
        mem_percent, mem_used_gb, mem_total_gb = self._get_memory_stats()
        cpu_count = self._get_cpu_count()
        tasks_total, tasks_running, tasks_sleeping = self._get_task_stats()
        
        return SystemStats(
            cpu_percent=cpu_percent,
            cpu_per_core=cpu_per_core,
            mem_percent=mem_percent,
            mem_used_gb=mem_used_gb,
            mem_total_gb=mem_total_gb,
            cpu_count=cpu_count,
            tasks_total=tasks_total,
            tasks_running=tasks_running,
            tasks_sleeping=tasks_sleeping
        )
    
    def _get_cpu_percent(self) -> float:
        """Obtiene porcentaje de CPU total"""
        try:
            with open('/proc/stat', 'r') as f:
                line = f.readline()
            
            fields = line.split()
            times = [int(x) for x in fields[1:]]
            
            if self.prev_cpu_times is None:
                self.prev_cpu_times = times
                return 0.0
            
            deltas = [t - p for t, p in zip(times, self.prev_cpu_times)]
            total_delta = sum(deltas)
            idle_delta = deltas[3] if len(deltas) > 3 else 0
            
            self.prev_cpu_times = times
            
            if total_delta == 0:
                return 0.0
            
            return 100.0 * (1.0 - idle_delta / total_delta)
            
        except Exception as e:
            logger.error(f"Error getting CPU percent: {e}")
            return 0.0
    
    def _get_cpu_per_core(self) -> List[float]:
        """Obtiene porcentaje de CPU por core"""
        try:
            with open('/proc/stat', 'r') as f:
                lines = f.readlines()
            
            cpu_lines = [line for line in lines if line.startswith('cpu') and line[3].isdigit()]
            
            current_times = []
            for line in cpu_lines:
                fields = line.split()
                times = [int(x) for x in fields[1:]]
                current_times.append(times)
            
            if self.prev_per_core is None or len(self.prev_per_core) != len(current_times):
                self.prev_per_core = current_times
                return [0.0] * len(current_times)
            
            percentages = []
            for curr, prev in zip(current_times, self.prev_per_core):
                deltas = [c - p for c, p in zip(curr, prev)]
                total_delta = sum(deltas)
                idle_delta = deltas[3] if len(deltas) > 3 else 0
                
                if total_delta == 0:
                    percentages.append(0.0)
                else:
                    percentages.append(100.0 * (1.0 - idle_delta / total_delta))
            
            self.prev_per_core = current_times
            return percentages
            
        except Exception as e:
            logger.error(f"Error getting per-core CPU: {e}")
            return []
    
    def _get_memory_stats(self) -> Tuple[float, float, float]:
        """Obtiene estadísticas de memoria"""
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = {}
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        meminfo[parts[0].rstrip(':')] = int(parts[1])
            
            total_kb = meminfo.get('MemTotal', 0)
            available_kb = meminfo.get('MemAvailable', 0)
            
            if total_kb == 0:
                return 0.0, 0.0, 0.0
            
            used_kb = total_kb - available_kb
            mem_percent = (used_kb / total_kb) * 100.0
            mem_used_gb = used_kb / (1024 * 1024)
            mem_total_gb = total_kb / (1024 * 1024)
            
            return mem_percent, mem_used_gb, mem_total_gb
            
        except Exception as e:
            logger.error(f"Error getting memory stats: {e}")
            return 0.0, 0.0, 0.0
    
    def _get_cpu_count(self) -> int:
        """Obtiene el número de CPUs"""
        try:
            return os.cpu_count() or 1
        except:
            return 1
    
    def _get_task_stats(self) -> Tuple[int, int, int]:
        """Obtiene estadísticas de tareas"""
        try:
            result = subprocess.run(['ps', 'ax'], capture_output=True, text=True, timeout=5)
            lines = result.stdout.strip().split('\n')[1:]  # Skip header
            
            total = len(lines)
            running = sum(1 for line in lines if ' R ' in line or ' R+ ' in line)
            sleeping = sum(1 for line in lines if ' S ' in line or ' S+ ' in line)
            
            return total, running, sleeping
            
        except Exception as e:
            logger.error(f"Error getting task stats: {e}")
            return 0, 0, 0

class EssoraTopWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=translator.get("Essora Top"))
        

        self.set_default_size(800, 600)
        self.set_border_width(0)
        

        icon_paths = [
            '/usr/local/essora-kit/essora-center.png',
            '/usr/share/pixmaps/essora-top.png',
            '/usr/local/agent-essora/essora.png',
        ]
        
        for icon_path in icon_paths:
            if os.path.exists(icon_path):
                try:
                    self.set_icon_from_file(icon_path)
                    logger.info(f"Icon loaded from {icon_path}")
                    break
                except Exception as e:
                    logger.warning(f"Could not load icon from {icon_path}: {e}")
        
        self.process_manager = ProcessManager()
        self.system_monitor = SystemMonitor()
        self.current_process = None
        self.update_interval = 2000  # ms
        
        # Aplicar CSS
        self.apply_css()
        
        # Crear interfaz
        self.setup_ui()
        

        self.load_processes()
        

        GLib.timeout_add(self.update_interval, self.auto_update)
    
    def apply_css(self):
        """Aplica estilos CSS globales"""
        css_provider = Gtk.CssProvider()
        css = """
        .stats-bar {
            background: linear-gradient(to bottom, #2c3e50, #34495e);
            color: white;
            padding: 8px;
            border-bottom: 2px solid #3498db;
        }
        
        .stats-label {
            font-weight: bold;
            color: white;
            font-size: 11px;
        }
        
        .cpu-bar {
            min-height: 6px;
        }
        
        .mem-bar {
            min-height: 6px;
        }
        
        .process-row {
            padding: 2px;
        }
        
        .process-row:selected {
            background-color: #3498db;
            color: white;
        }
        """
        
        css_provider.load_from_data(css.encode())
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def setup_ui(self):
        """Configura la interfaz de usuario"""

        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(main_vbox)
        

        self.create_headerbar()
        
        
        self.stats_box = self.create_stats_bar()
        main_vbox.pack_start(self.stats_box, False, False, 0)
        
        
        process_box = self.create_process_view()
        main_vbox.pack_start(process_box, True, True, 0)
        
        
        self.status_label = Gtk.Label()
        self.status_label.set_halign(Gtk.Align.START)
        self.status_label.set_margin_start(10)
        self.status_label.set_margin_end(10)
        self.status_label.set_margin_top(5)
        self.status_label.set_margin_bottom(5)
        main_vbox.pack_start(self.status_label, False, False, 0)
    
    def create_headerbar(self):
        """Crea la barra de título"""
        headerbar = Gtk.HeaderBar()
        headerbar.set_show_close_button(True)
        headerbar.set_title(translator.get("Essora Top"))
        headerbar.set_subtitle(translator.get("Process Manager"))
        self.set_titlebar(headerbar)
        
        # Agregar ícono al headerbar
        icon_paths = [
            '/usr/local/essora-kit/essora-center.png',
            '/usr/local/agent-essora/essora.png',
        ]
        
        for icon_path in icon_paths:
            if os.path.exists(icon_path):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 32, 32, True)
                    icon_image = Gtk.Image.new_from_pixbuf(pixbuf)
                    headerbar.pack_start(icon_image)
                    logger.info(f"HeaderBar icon loaded from {icon_path}")
                    break
                except Exception as e:
                    logger.warning(f"Could not load headerbar icon from {icon_path}: {e}")
        
        # Botón de recargar
        reload_btn = Gtk.Button()
        reload_icon = Gio.ThemedIcon(name="view-refresh-symbolic")
        reload_image = Gtk.Image.new_from_gicon(reload_icon, Gtk.IconSize.BUTTON)
        reload_btn.add(reload_image)
        reload_btn.set_tooltip_text(translator.get("Reload"))
        reload_btn.connect("clicked", lambda b: self.load_processes())
        headerbar.pack_start(reload_btn)
        
        # Botón de menú
        menu_btn = Gtk.MenuButton()
        menu_icon = Gio.ThemedIcon(name="open-menu-symbolic")
        menu_image = Gtk.Image.new_from_gicon(menu_icon, Gtk.IconSize.BUTTON)
        menu_btn.add(menu_image)
        headerbar.pack_end(menu_btn)
        
        # Crear menú
        menu = Gio.Menu()
        menu.append(translator.get("Reload"), "app.reload")
        menu.append(translator.get("About"), "app.about")
        menu.append(translator.get("Quit"), "app.quit")
        menu_btn.set_menu_model(menu)
    
    def create_stats_bar(self) -> Gtk.Box:
        """Crea la barra de estadísticas del sistema"""
        stats_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        stats_box.get_style_context().add_class("stats-bar")
        
        # Primera fila: CPU Total + Tasks
        row1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row1.set_margin_start(10)
        row1.set_margin_end(10)
        row1.set_margin_top(3)
        row1.set_margin_bottom(2)
        
        # CPU Total (texto y porcentaje)
        cpu_label_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        self.cpu_label = Gtk.Label()
        self.cpu_label.set_halign(Gtk.Align.START)
        self.cpu_label.get_style_context().add_class("stats-label")
        cpu_label_box.pack_start(self.cpu_label, False, False, 0)
        
        self.cpu_bar = Gtk.ProgressBar()
        self.cpu_bar.set_size_request(80, 6)
        self.cpu_bar.get_style_context().add_class("cpu-bar")
        cpu_label_box.pack_start(self.cpu_bar, False, False, 0)
        
        row1.pack_start(cpu_label_box, False, False, 0)
        
        # Tareas (a la derecha)
        self.tasks_label = Gtk.Label()
        self.tasks_label.get_style_context().add_class("stats-label")
        row1.pack_end(self.tasks_label, False, False, 0)
        
        stats_box.pack_start(row1, False, False, 0)
        
        # Grid para cores - se llenará dinámicamente en filas de 4
        self.cores_grid = Gtk.Grid()
        self.cores_grid.set_column_spacing(3)
        self.cores_grid.set_row_spacing(2)
        self.cores_grid.set_margin_start(10)
        self.cores_grid.set_margin_end(10)
        self.cores_grid.set_margin_bottom(2)
        stats_box.pack_start(self.cores_grid, False, False, 0)
        
        # Fila de Memoria
        row_mem = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row_mem.set_margin_start(10)
        row_mem.set_margin_end(10)
        row_mem.set_margin_bottom(3)
        
        mem_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        self.mem_label = Gtk.Label()
        self.mem_label.set_halign(Gtk.Align.START)
        self.mem_label.get_style_context().add_class("stats-label")
        mem_box.pack_start(self.mem_label, False, False, 0)
        
        self.mem_bar = Gtk.ProgressBar()
        self.mem_bar.set_hexpand(True)
        self.mem_bar.set_size_request(-1, 6)
        self.mem_bar.get_style_context().add_class("mem-bar")
        mem_box.pack_start(self.mem_bar, False, False, 0)
        
        row_mem.pack_start(mem_box, True, True, 0)
        stats_box.pack_start(row_mem, False, False, 0)
        
        return stats_box
    
    def create_process_view(self) -> Gtk.Box:
        """Crea la vista de procesos"""
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vbox.set_margin_start(10)
        vbox.set_margin_end(10)
        vbox.set_margin_top(10)
        
        # Barra de búsqueda
        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        search_label = Gtk.Label(label=translator.get("Search:"))
        search_box.pack_start(search_label, False, False, 0)
        
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("search-changed", self.on_search_changed)
        search_box.pack_start(self.search_entry, True, True, 0)
        
        vbox.pack_start(search_box, False, False, 0)
        
        # TreeView de procesos
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_vexpand(True)
        
        # Modelo: PID, User, CPU%, MEM%, VSZ, RSS, State, Command
        self.process_store = Gtk.ListStore(int, str, float, float, int, int, str, str)
        self.filter_model = self.process_store.filter_new()
        self.filter_model.set_visible_func(self.process_filter_func)
        
        self.process_tree = Gtk.TreeView(model=self.filter_model)
        self.process_tree.set_search_column(7)  # Command
        
        # Columnas
        columns = [
            ("PID", 0, 60),
            (translator.get("User"), 1, 80),
            ("CPU%", 2, 60),
            ("MEM%", 3, 60),
            ("VSZ", 4, 80),
            ("RSS", 5, 80),
            (translator.get("State"), 6, 50),
            (translator.get("Command"), 7, 250)
        ]
        
        for title, col_id, width in columns:
            if col_id in [2, 3]:  # CPU% y MEM%
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer)
                column.set_cell_data_func(renderer, self.format_percentage, col_id)
            elif col_id in [4, 5]:  # VSZ y RSS
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer)
                column.set_cell_data_func(renderer, self.format_memory, col_id)
            else:
                renderer = Gtk.CellRendererText()
                column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            
            column.set_resizable(True)
            column.set_min_width(width)
            column.set_sort_column_id(col_id)
            self.process_tree.append_column(column)
        
        # Selección
        selection = self.process_tree.get_selection()
        selection.connect("changed", self.on_process_selected)
        
        scrolled.add(self.process_tree)
        vbox.pack_start(scrolled, True, True, 0)
        
        # Botones de acción
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        
        self.kill_btn = Gtk.Button(label=translator.get("Terminate (SIGTERM)"))
        self.kill_btn.connect("clicked", self.on_kill_clicked)
        self.kill_btn.set_sensitive(False)
        button_box.pack_start(self.kill_btn, True, True, 0)
        
        self.force_kill_btn = Gtk.Button(label=translator.get("Force Kill (SIGKILL)"))
        self.force_kill_btn.connect("clicked", self.on_force_kill_clicked)
        self.force_kill_btn.set_sensitive(False)
        button_box.pack_start(self.force_kill_btn, True, True, 0)
        
        vbox.pack_start(button_box, False, False, 0)
        
        return vbox
    
    def format_percentage(self, column, cell, model, iter_, col_id):
        """Formatea porcentajes con 1 decimal"""
        value = model.get_value(iter_, col_id)
        cell.set_property('text', f'{value:.1f}')
    
    def format_memory(self, column, cell, model, iter_, col_id):
        """Formatea valores de memoria en MB"""
        value = model.get_value(iter_, col_id)
        mb = value / 1024
        cell.set_property('text', f'{mb:.1f} MB')
    
    def process_filter_func(self, model, iter_, data):
        """Filtra procesos por búsqueda"""
        search_text = self.search_entry.get_text().lower()
        if not search_text:
            return True
        
        # Buscar en PID, User y Command
        pid = str(model.get_value(iter_, 0))
        user = model.get_value(iter_, 1).lower()
        command = model.get_value(iter_, 7).lower()
        
        return (search_text in pid or 
                search_text in user or 
                search_text in command)
    
    def on_search_changed(self, entry):
        """Maneja cambios en la búsqueda"""
        self.filter_model.refilter()
    
    def on_process_selected(self, selection):
        """Maneja la selección de un proceso"""
        model, tree_iter = selection.get_selected()
        if tree_iter:
            self.current_process = model.get_value(tree_iter, 0)  # PID
            self.kill_btn.set_sensitive(True)
            self.force_kill_btn.set_sensitive(True)
            
            # Actualizar información
            user = model.get_value(tree_iter, 1)
            cpu = model.get_value(tree_iter, 2)
            mem = model.get_value(tree_iter, 3)
            command = model.get_value(tree_iter, 7)
            
            self.update_status(
                f"PID: {self.current_process} | {translator.get('User')}: {user} | "
                f"CPU: {cpu:.1f}% | MEM: {mem:.1f}% | {command}"
            )
        else:
            self.current_process = None
            self.kill_btn.set_sensitive(False)
            self.force_kill_btn.set_sensitive(False)
            self.update_status("")
    
    def load_processes(self):
        """Carga la lista de procesos"""
        def load():
            try:
                processes = self.process_manager.get_processes()
                GLib.idle_add(self.update_process_list, processes)
            except Exception as e:
                logger.error(f"Error loading processes: {e}")
                GLib.idle_add(self.show_error, str(e))
        
        thread = threading.Thread(target=load, daemon=True)
        thread.start()
    
    def update_process_list(self, processes: List[Process]) -> bool:
        """Actualiza la lista de procesos en el TreeView"""
        self.process_store.clear()
        
        for proc in processes:
            self.process_store.append([
                proc.pid,
                proc.user,
                proc.cpu,
                proc.mem,
                proc.vsz,
                proc.rss,
                proc.state,
                proc.command
            ])
        
        self.update_status(translator.get("Processes loaded: {}").format(len(processes)))
        return False
    
    def update_system_stats(self) -> bool:
        """Actualiza las estadísticas del sistema"""
        try:
            stats = self.system_monitor.get_system_stats()
            
            # CPU Total
            self.cpu_label.set_text(f"CPU: {stats.cpu_percent:.1f}%")
            self.cpu_bar.set_fraction(stats.cpu_percent / 100.0)
            
            # Memoria
            self.mem_label.set_text(
                f"{translator.get('Memory')}: {stats.mem_used_gb:.1f} / {stats.mem_total_gb:.1f} GB "
                f"({stats.mem_percent:.1f}%)"
            )
            self.mem_bar.set_fraction(stats.mem_percent / 100.0)
            
            # Tareas
            self.tasks_label.set_text(
                f"{translator.get('Tasks')}: {stats.tasks_total} "
                f"({stats.tasks_running} {translator.get('running')}, "
                f"{stats.tasks_sleeping} {translator.get('sleeping')})"
            )
            
            # CPU por core
            self.update_cpu_cores(stats.cpu_per_core)
            
        except Exception as e:
            logger.error(f"Error updating system stats: {e}")
        
        return False
    
    def update_cpu_cores(self, core_percentages: List[float]):
        """Actualiza las barras de CPU por core en grid de 4 columnas"""
        
        for child in self.cores_grid.get_children():
            self.cores_grid.remove(child)
        
        
        cores_per_row = 4
        
        for i, percent in enumerate(core_percentages):
            row = i // cores_per_row
            col = i % cores_per_row
            
            core_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            
            
            label = Gtk.Label(label=f"C{i}:")
            label.get_style_context().add_class("stats-label")
            label.set_size_request(25, -1)
            core_box.pack_start(label, False, False, 0)
            
           
            bar = Gtk.ProgressBar()
            bar.set_fraction(percent / 100.0)
            bar.set_size_request(120, 6)
            bar.get_style_context().add_class("cpu-bar")
            bar.set_show_text(True)
            bar.set_text(f"{percent:.1f}%")
            core_box.pack_start(bar, False, False, 0)
            
            self.cores_grid.attach(core_box, col, row, 1, 1)
        
        self.cores_grid.show_all()
    
    def auto_update(self) -> bool:
        """Actualización automática periódica"""
        self.load_processes()
        self.update_system_stats()
        return True 
    
    def on_kill_clicked(self, button):
        """Termina el proceso seleccionado (SIGTERM)"""
        if not self.current_process:
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=translator.get("Terminate process?")
        )
        dialog.format_secondary_text(
            translator.get("Are you sure you want to terminate process {} (SIGTERM)?").format(
                self.current_process
            )
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.kill_process(signal.SIGTERM)
    
    def on_force_kill_clicked(self, button):
        """Fuerza la terminación del proceso (SIGKILL)"""
        if not self.current_process:
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=translator.get("Force kill process?")
        )
        dialog.format_secondary_text(
            translator.get("Are you sure you want to force kill process {} (SIGKILL)? "
                         "This cannot be caught by the process.").format(
                self.current_process
            )
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            self.kill_process(signal.SIGKILL)
    
    def kill_process(self, sig: int):
        """Mata un proceso con la señal especificada"""
        if not self.current_process:
            return
        
        def kill():
            try:
                success = self.process_manager.kill_process(self.current_process, sig)
                if success:
                    GLib.idle_add(
                        self.show_info,
                        translator.get("Success"),
                        translator.get("Process {} terminated successfully").format(
                            self.current_process
                        )
                    )
                    time.sleep(0.5) 
                    GLib.idle_add(self.load_processes)
                else:
                    GLib.idle_add(
                        self.show_error,
                        translator.get("Failed to terminate process {}").format(
                            self.current_process
                        )
                    )
            except Exception as e:
                GLib.idle_add(self.show_error, str(e))
        
        thread = threading.Thread(target=kill, daemon=True)
        thread.start()
    
    def update_status(self, message: str):
        """Actualiza el mensaje de estado"""
        self.status_label.set_markup(f'<small>{message}</small>')
    
    def show_error(self, message: str):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=translator.get("Error")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_info(self, title: str, message: str):
        """Muestra un diálogo de información"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

class EssoraTopApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id='org.essora.essora-top')
        self.window = None
    
    def do_activate(self):
        if not self.window:
            self.window = EssoraTopWindow(self)
            self.window.show_all()
            self.window.present()
    
    def do_startup(self):
        Gtk.Application.do_startup(self)
        
        reload_action = Gio.SimpleAction.new("reload", None)
        reload_action.connect("activate", self.on_reload)
        self.add_action(reload_action)
        
        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self.on_about)
        self.add_action(about_action)
        
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", self.on_quit)
        self.add_action(quit_action)
        
        self.set_accels_for_action("app.quit", ["<Primary>q"])
        self.set_accels_for_action("app.reload", ["<Primary>r", "F5"])
    
    def on_reload(self, action, param):
        if self.window:
            self.window.load_processes()
    
    def on_about(self, action, param):
        about = Gtk.AboutDialog(transient_for=self.window, modal=True)
        about.set_program_name(translator.get("Essora Top"))
        about.set_version("3.0")
        about.set_comments(translator.get("About dialog for Essora Store with multi-language support"))
        about.set_authors(["josejp2424"])
        about.set_website("https://sourceforge.net/projects/essora/")
        about.set_license_type(Gtk.License.GPL_3_0)
        

        icon_paths = [
            '/usr/local/essora-kit/essora-center.png',
            '/usr/share/pixmaps/agent-essora.png',
            '/usr/local/agent-essora/essora.png',
            os.path.join(os.path.dirname(os.path.abspath(__file__)), 'essora.png')
        ]
        
        logo_loaded = False
        for icon_path in icon_paths:
            if os.path.exists(icon_path):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 128, 128, True)
                    about.set_logo(pixbuf)
                    logo_loaded = True
                    logger.info(f"About dialog logo loaded from {icon_path}")
                    break
                except Exception as e:
                    logger.warning(f"Could not load logo from {icon_path}: {e}")
        
        if not logo_loaded:
            about.set_logo_icon_name('preferences-system')
        
        about.run()
        about.destroy()
    
    def on_quit(self, action, param):
        self.quit()

def main():
    try:
        if os.geteuid() == 0:
            logger.warning("Running as root is not recommended")
        app = EssoraTopApplication()
        return app.run(None)
    except KeyboardInterrupt:
        logger.info("Application interrupted by user")
        return 0
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        return 1

if __name__ == '__main__':
    exit(main())
