#!/bin/sh
[ -x /sbin/sysctl ] && /sbin/sysctl -q --system || true
[ -x /usr/sbin/sysctl ] && /usr/sbin/sysctl -q --system || true
exit 0
