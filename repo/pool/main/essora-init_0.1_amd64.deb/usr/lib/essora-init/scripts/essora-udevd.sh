#!/bin/sh
set -u

mkdir -p /run/udev /run/sendsigs.omit.d

if command -v udevd >/dev/null 2>&1; then
    exec udevd --daemon
fi

if [ -x /sbin/udevd ]; then
    exec /sbin/udevd --daemon
fi

if [ -x /lib/udev/udevd ]; then
    exec /lib/udev/udevd --daemon
fi

if [ -x /lib/systemd/systemd-udevd ]; then
    exec /lib/systemd/systemd-udevd --daemon
fi

echo "[essora-init] udevd not found"
exit 0
