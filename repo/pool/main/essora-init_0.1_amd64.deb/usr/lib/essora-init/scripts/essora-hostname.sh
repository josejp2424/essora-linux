#!/bin/sh
[ -r /etc/hostname ] && hostname "$(cat /etc/hostname | head -n1)" 2>/dev/null || hostname essora 2>/dev/null || true
exit 0
