#!/bin/sh
mkdir -p /run/dbus /var/run/dbus /var/lib/dbus
chown messagebus:messagebus /run/dbus /var/run/dbus 2>/dev/null || true
[ -x /usr/bin/dbus-uuidgen ] && /usr/bin/dbus-uuidgen --ensure 2>/dev/null || true
exec /usr/bin/dbus-daemon --system --nofork --nopidfile
