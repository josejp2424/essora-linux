#!/bin/sh
[ -x /usr/sbin/bluetoothd ] || exit 0
exec /usr/sbin/bluetoothd --nodetach
