#!/bin/sh
if [ -x /usr/libexec/elogind ]; then
    exec /usr/libexec/elogind
fi
if [ -x /lib/elogind/elogind ]; then
    exec /lib/elogind/elogind
fi
if [ -x /usr/lib/elogind/elogind ]; then
    exec /usr/lib/elogind/elogind
fi
exit 0
