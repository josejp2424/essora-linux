#!/bin/sh
DAEMON="/usr/sbin/NetworkManager"
[ -x "$DAEMON" ] || exit 0
mkdir -p /run/NetworkManager
exec "$DAEMON" --no-daemon
