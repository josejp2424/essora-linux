#!/bin/sh
mkdir -p /run/network
: > /run/network/ifstate 2>/dev/null || true

if command -v ifup >/dev/null 2>&1; then
    ifup -a --allow=auto 2>/dev/null || ifup -a 2>/dev/null || true
fi

exit 0
