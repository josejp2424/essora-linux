#!/bin/sh
[ -x /usr/sbin/alsactl ] && /usr/sbin/alsactl restore 2>/dev/null || true
[ -x /sbin/alsactl ] && /sbin/alsactl restore 2>/dev/null || true
exit 0
