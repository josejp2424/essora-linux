#!/bin/sh
[ -x /etc/rc.local ] && exec /etc/rc.local
exit 0
