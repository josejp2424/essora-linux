#!/bin/sh
[ -x /bin/plymouth ] && /bin/plymouth quit 2>/dev/null || true
[ -x /usr/bin/slim ] || exit 0
exec /usr/bin/slim -nodaemon
