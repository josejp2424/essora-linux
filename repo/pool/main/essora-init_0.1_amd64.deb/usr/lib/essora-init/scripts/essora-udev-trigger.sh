#!/bin/sh
UDEVADM=""
for c in /bin/udevadm /sbin/udevadm /usr/bin/udevadm /usr/sbin/udevadm; do
    [ -x "$c" ] && UDEVADM="$c" && break
done

[ -n "$UDEVADM" ] || exit 0
"$UDEVADM" trigger --action=add 2>/dev/null || true
"$UDEVADM" settle --timeout=15 2>/dev/null || true
exit 0
