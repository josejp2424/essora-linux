#!/bin/sh
set -u

msg() { echo "[essora-init] $*"; }

mkdir -p /proc /sys /dev /dev/pts /dev/shm /run /run/lock /tmp

mountpoint -q /proc || mount -t proc proc /proc -o nodev,noexec,nosuid || true
mountpoint -q /sys || mount -t sysfs sysfs /sys -o nodev,noexec,nosuid || true
mountpoint -q /run || mount -t tmpfs tmpfs /run -o nosuid,nodev,mode=0755 || true
mkdir -p /run/lock /run/user /run/network /run/dbus /run/udev /run/sendsigs.omit.d
chmod 755 /run /run/lock /run/network /run/dbus /run/udev 2>/dev/null || true

if ! grep -q " /dev devtmpfs " /proc/mounts 2>/dev/null; then
    mount -t devtmpfs devtmpfs /dev -o nosuid,mode=0755 || true
fi

mountpoint -q /dev/pts || mount -t devpts devpts /dev/pts -o noexec,nosuid,gid=5,mode=0620 || true
mountpoint -q /dev/shm || mount -t tmpfs tmpfs /dev/shm -o nosuid,nodev || true

[ -e /dev/fd ] || ln -s /proc/self/fd /dev/fd 2>/dev/null || true
[ -e /dev/stdin ] || ln -s fd/0 /dev/stdin 2>/dev/null || true
[ -e /dev/stdout ] || ln -s fd/1 /dev/stdout 2>/dev/null || true
[ -e /dev/stderr ] || ln -s fd/2 /dev/stderr 2>/dev/null || true

[ -d /sys/kernel/security ] && { mountpoint -q /sys/kernel/security || mount -t securityfs securityfs /sys/kernel/security 2>/dev/null || true; }
[ -d /sys/fs/cgroup ] && { mountpoint -q /sys/fs/cgroup || mount -t cgroup2 cgroup2 /sys/fs/cgroup 2>/dev/null || true; }
[ -d /sys/firmware/efi/efivars ] && { mountpoint -q /sys/firmware/efi/efivars || mount -t efivarfs efivarfs /sys/firmware/efi/efivars 2>/dev/null || true; }

chmod 1777 /tmp 2>/dev/null || true
msg "kernel filesystems ready"
exit 0
