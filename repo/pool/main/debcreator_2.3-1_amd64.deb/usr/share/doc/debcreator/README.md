#josejp2424
# DebCreator

## 🇪🇸 ¿Qué es DebCreator?

**DebCreator** es una herramienta gráfica y de consola para generar paquetes `.deb` de forma sencilla a partir de una estructura de directorios ya preparada. Pensada para desarrolladores o usuarios que desean crear paquetes Debian sin complicaciones.

### Este paquete incluye:

- Script principal: `/usr/local/bin/make-deb`
- Entrada de escritorio: `/usr/share/applications/make-deb.desktop`
- Icono de aplicación: `/usr/share/pixmaps/debcreator.jpg`
- Documentación: `/usr/share/doc/debcreator/README.md`
- Licencia: `/usr/share/doc/debcreator/LICENSE`

### Características

- Interfaz simple y directa.
- Compatible con cualquier entorno de escritorio.
- No requiere dependencias externas pesadas.
- Ideal para sistemas Live o distribución de scripts personalizados.

### Cómo usar

1. Crea un directorio con esta estructura:
   ```
   mi-paquete/
   ├── DEBIAN/
   │   └── control
   └── usr/
       └── bin/
           └── aplicacion
   ```

2. Ejecuta **DebCreator** desde el menú o por terminal:
   ```bash
   sudo make-deb mi-paquete
   ```

3. Se generará un archivo `.deb` listo para instalar en el mismo directorio.

### Requisitos del sistema

- Sistema basado en Debian o derivados.

### Dependencias requeridas

- `dpkg-dev` – Para construir paquetes `.deb`.
- `fakeroot` – Para emular entorno root sin privilegios.
- `yad` – Para la interfaz gráfica.
- `coreutils` – Comandos básicos (du, mkdir, etc).
- `sed` – Procesamiento de texto.
- `gawk` – Procesamiento avanzado de texto.

### Licencia

MIT License – Libre para usar, modificar y distribuir.

---

## 🇬🇧 What is DebCreator?

**DebCreator** is a simple graphical and terminal tool to generate `.deb` packages from a prepared directory structure. It is designed for developers or users who want to build Debian packages quickly and easily.

### This package includes:

- Main script: `/usr/local/bin/make-deb`
- Desktop entry: `/usr/share/applications/make-deb.desktop`
- Application icon: `/usr/local/debcreator/debcreator.svg`
- Documentation: `/usr/share/doc/debcreator/README.md`
- License: `/usr/share/doc/debcreator/LICENSE`

### Features

- Simple and clean interface.
- Compatible with any desktop environment.
- Lightweight, no heavy dependencies.
- Perfect for live systems or distributing personal scripts.

### How to use

1. Prepare a folder like this:
   ```
   my-package/
   ├── DEBIAN/
   │   └── control
   └── usr/
       └── bin/
           └── application
   ```

2. Run **DebCreator** from the menu or terminal:
   ```bash
   make-deb my-package
   ```

3. A `.deb` file will be created in the same folder, ready to install.

### System Requirements

- Debian-based system.

### Required dependencies

- `dpkg-dev` – For building `.deb` packages.
- `fakeroot` – To emulate root environment.
- `yad` – For the graphical interface.
- `coreutils` – Basic tools (du, mkdir, etc).
- `sed` – Text processing.
- `gawk` – Advanced text processing.

### License

MIT License – Free to use, modify and distribute.
