#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ESSORA DISTRO WELCOME SCRIPT (GTK3)

Official welcome application for Essora Linux Distribution
Version: 2.0.0
Author: Essora Development Team josejp2424 nilsonmorales
License: GPL-3.0
Source: https://sourceforge.net/projects/essora/
"""

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk

import os
import subprocess
from pathlib import Path


ICON_MAIN = "/usr/share/icons/essora.png"
ICON_SF = "/usr/share/pixmaps/essora/sourceforge1.png"
ICON_LOCALE = "/usr/share/pixmaps/essora/essora-locale.png"

# Community
ICON_COMMUNITY_HDR = "/usr/local/essora-wlcome/comunidad.png"
ICON_TELEGRAM = "/usr/local/essora-wlcome/telegram.png"
ICON_REDDIT = "/usr/local/essora-wlcome/reddit.png"
ICON_X = "/usr/local/essora-wlcome/x.png"
ICON_YOUTUBE = "/usr/local/essora-wlcome/youtube.png"

COMMUNITY_TG_URL = "https://t.me/essoralinux"
COMMUNITY_REDDIT_URL = "https://www.reddit.com/"
COMMUNITY_X_URL = "https://x.com"
COMMUNITY_YT_URL = "https://www.youtube.com/"


# Donate / support assets
DONATE_URL = "https://www.paypal.com/donate/?hosted_button_id=BHVGASBK9UJGQ"
ICON_DONATE_HDR = "/usr/local/essora-wlcome/donate-essora.png"
ICON_PAYPAL = "/usr/local/essora-wlcome/paypal.png"
ICON_BITCOIN = "/usr/local/essora-wlcome/bitcoin.png"
ICON_ETHEREUM = "/usr/local/essora-wlcome/ethereum.png"
ICON_USDT = "/usr/local/essora-wlcome/usdt.png"
IMG_QR_PAYPAL = "/usr/local/essora-wlcome/Código QR.png"

# Dirección (solo esto se copia)
DONATE_ADDR = "0xc1629e776967025E4AA40411f4c0e1B0D2c09FdD"

# Redes (texto fijo, no copiable)
BTC_NET = "RED BEP20"
ETH_NET = "RED ERC20"
USDT_NET = "RED BEP20"


# Archivo de configuración
CONFIG_DIR = Path.home() / ".config" / "essora-welcome"
CONFIG_FILE = CONFIG_DIR / "autostart"


def load_pixbuf(path: str, size=None):
    """Carga una imagen como GdkPixbuf, opcionalmente escalada."""
    try:
        if not path or not os.path.exists(path):
            return None
        pb = GdkPixbuf.Pixbuf.new_from_file(path)
        if size is not None:
            w, h = size
            pb = pb.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
        return pb
    except Exception as e:
        print(f"Error loading image {path}: {e}")
        return None


def load_autostart_config():
    """Lee si debe mostrarse al inicio"""
    try:
        if CONFIG_FILE.exists():
            content = CONFIG_FILE.read_text().strip()
            return content.lower() in ('true', '1', 'yes')
        return True  # Por defecto mostrar
    except Exception as e:
        print(f"Error reading config: {e}")
        return True


def save_autostart_config(show: bool):
    """Guarda la configuración de autostart"""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text('true' if show else 'false')
    except Exception as e:
        print(f"Error saving config: {e}")


class EssoraWelcomeApp(Gtk.Window):
    def __init__(self):
        super().__init__()
        self.set_resizable(False)
        self.set_default_size(880, 680)
        self.set_position(Gtk.WindowPosition.CENTER)

        # Icono de ventana
        pb = load_pixbuf(ICON_MAIN)
        if pb:
            self.set_icon(pb)

        self.load_assets()
        self.setup_language()
        self.build_ui()
        self.update_content()

    def tr(self, key: str) -> str:
        """Traducción con fallback a inglés."""
        lang = self.languages.get(self.current_lang, self.languages.get("en", {}))
        if key in lang:
            return lang[key]
        return self.languages.get("en", {}).get(key, key)

    def load_assets(self):
        self.logo_pb = load_pixbuf(ICON_MAIN, (48, 48))
        self.sf_pb = load_pixbuf(ICON_SF, (20, 20))
        self.locale_pb = load_pixbuf(ICON_LOCALE, (20, 20))

        # Community icons
        self.community_hdr_pb = load_pixbuf(ICON_COMMUNITY_HDR, (22, 22))
        self.tg_pb = load_pixbuf(ICON_TELEGRAM, (18, 18))
        self.reddit_pb = load_pixbuf(ICON_REDDIT, (18, 18))
        self.x_pb = load_pixbuf(ICON_X, (18, 18))
        self.yt_pb = load_pixbuf(ICON_YOUTUBE, (18, 18))

        # Donate icons (opcionales)
        self.donate_hdr_pb = load_pixbuf(ICON_DONATE_HDR, (28, 28))
        self.paypal_pb = load_pixbuf(ICON_PAYPAL, (18, 18))
        self.btc_pb = load_pixbuf(ICON_BITCOIN, (18, 18))
        self.eth_pb = load_pixbuf(ICON_ETHEREUM, (18, 18))
        self.usdt_pb = load_pixbuf(ICON_USDT, (18, 18))
        self.qr_pb_small = load_pixbuf(IMG_QR_PAYPAL, (18, 18))

    def setup_language(self):
        self.languages = {
            'en': {
                'title': "Welcome to Essora Eos",
                'main_text': "Thank you for choosing Essora.\n\nThis system was designed to be lightweight, fast, and easy to use.\n\n🔐 Username: essora\n🔐 Password: essora\n\n⚙️ To enable/disable autologin:\nControl Center → Login Window",
                'about_text': "A minimalist Devuan-based distribution:\n• Fast and lightweight\n• Simple and customizable\n• Fully under your control\n\nNo bloatware. No complications.",
                'name_meaning': "🌱 Essora\nBase distro name. Invented name with clean, soft connotations.\nCould be interpreted as a fusion between:\n- 'Essence' (core)\n- 'Ora' (Latin: 'hour', 'now')\n\n🌄 Eos\nGreek goddess of dawn. Represents:\n- New beginnings\n- Clarity and light\n- The awakening\n\nEssora Eos = 'The new dawn of essentials'",
                'show_startup': "Show at startup",

                # Community
                'community': "Community",
                'community_tip': "Community links",

                # Donate
                'donate': "Donate",
                'donate_tip': "Support Essora",
                'donate_paypal': "PayPal (open in browser)",
                'donate_qr': "PayPal QR",
                'donate_bitcoin': "Bitcoin",
                'donate_ethereum': "Ethereum",
                'donate_usdt': "USDT",
                'copy': "Copy",
                'copied': "Copied to clipboard",
                'close': "Close",
                'open_in_viewer': "Open image",
            },
            'es': {
                'title': "Bienvenido a Essora Eos",
                'main_text': "Gracias por elegir Essora.\n\nEste sistema fue diseñado para ser ligero, rápido y fácil de usar.\n\n🔐 Usuario: essora\n🔐 Contraseña: essora\n\n⚙️ Para activar/desactivar autologin:\nCentro de Control → Ventana de Login",
                'about_text': "Distribución minimalista basada en Devuan:\n• Rápida y liviana\n• Simple y personalizable\n• Bajo tu control completo\n\nSin bloatware. Sin complicaciones.",
                'name_meaning': "🌱 Essora\nNombre base de la distro. Nombre inventado con connotaciones limpias.\nPodría interpretarse como fusión entre:\n- 'Essence' (esencia)\n- 'Ora' (del latín: 'hora', 'ahora')\n\n🌄 Eos\nDiosa griega del amanecer. Representa:\n- Nuevos comienzos\n- Claridad y luz\n- El despertar\n\nEssora Eos = 'El nuevo amanecer de lo esencial'",
                'show_startup': "Mostrar al inicio",

                # Community
                'community': "Comunidad",
                'community_tip': "Enlaces de la comunidad",

                # Donate
                'donate': "Donar",
                'donate_tip': "Apoyar Essora",
                'donate_paypal': "PayPal (abrir en navegador)",
                'donate_qr': "QR de PayPal",
                'donate_bitcoin': "Bitcoin",
                'donate_ethereum': "Ethereum",
                'donate_usdt': "USDT",
                'copy': "Copiar",
                'copied': "Copiado al portapapeles",
                'close': "Cerrar",
                'open_in_viewer': "Abrir imagen",
            },
            'fr': {
                'title': "Bienvenue sur Essora Eos",
                'main_text': "Merci d'avoir choisi Essora.\n\nCe système est conçu pour être léger, rapide et facile à utiliser.\n\n🔐 Utilisateur: essora\n🔐 Mot de passe: essora\n\n⚙️ Pour activer/désactiver l'auto-login:\nCentre de contrôle → Fenêtre de connexion",
                'about_text': "Distribution minimaliste basée sur Devuan:\n• Rapide et légère\n• Simple et personnalisable\n• Sous votre contrôle complet\n\nSans bloatware. Sans complications.",
                'name_meaning': "🌱 Essora\nNom de base de la distro. Nom inventé aux connotations pures.\nInterprétation possible comme fusion entre:\n- 'Essence' (noyau)\n- 'Ora' (latin: 'heure', 'maintenant')\n\n🌄 Eos\nDéesse grecque de l'aurore. Représente:\n- Un nouveau départ\n- Clarté et lumière\n- L'éveil\n\nEssora Eos = 'La nouvelle aube de l'essentiel'",
                'show_startup': "Afficher au démarrage"
            },
            'ja': {
                'title': "Essora Eosへようこそ",
                'main_text': "Essoraをお選びいただきありがとうございます。\n\n軽量、高速、シンプルなシステムです。\n\n🔐 ユーザー名: essora\n🔐 パスワード: essora\n\n⚙️ 自動ログイン設定:\nコントロールセンター → ログインウィンドウ",
                'about_text': "Devuanベースのミニマルディストリビューション:\n• 高速・軽量\n• シンプルでカスタマイズ可能\n• 完全なコントロール\n\n余計なものなし。複雑さなし。",
                'name_meaning': "🌱 Essora\nディストロの基本名。清潔で現代的な響き。\n解釈としては:\n- 'Essence' (本質)\n- 'Ora' (ラテン語で「今」)\nの融合\n\n🌄 Eos\nギリシャ神話の暁の女神。意味:\n- 新しい始まり\n- 明瞭さと光\n- 目覚め\n\nEssora Eos = 「本質の新しい夜明け」",
                'show_startup': "起動時に表示"
            },
            'ru': {
                'title': "Добро пожаловать в Essora Eos",
                'main_text': "Спасибо за выбор Essora.\n\nЭта система создана быть лёгкой, быстрой и удобной.\n\n🔐 Пользователь: essora\n🔐 Пароль: essora\n\n⚙️ Автовход:\nЦентр управления → Окно входа",
                'about_text': "Минималистичный дистрибутив на Devuan:\n• Быстрый и лёгкий\n• Простой и настраиваемый\n• Полный контроль\n\nБез bloatware. Без сложностей.",
                'name_meaning': "🌱 Essora\nНазвание дистрибутива. Вымышленное, но с чистым звучанием.\nМожно интерпретировать как:\n- 'Essence' (суть)\n- 'Ora' (лат. 'время', 'сейчас')\n\n🌄 Eos\nГреческая богиня утра. Символизирует:\n- Новые начала\n- Ясность и свет\n- Пробуждение\n\nEssora Eos = 'Новый рассвет необходимого'",
                'show_startup': "Показать при запуске"
            },
            'zh': {
                'title': "欢迎使用 Essora Eos",
                'main_text': "感谢您选择 Essora。\n\n本系统设计为轻量、快速且易用。\n\n🔐 用户名: essora\n🔐 密码: essora\n\n⚙️ 启用/禁用自动登录:\n控制中心 → 登录窗口",
                'about_text': "基于Devuan的极简发行版:\n• 快速轻便\n• 简洁可定制\n• 完全由您掌控\n\n无臃肿软件。无复杂设置。",
                'name_meaning': "🌱 Essora\n发行版基础名称。创新的名称，干净现代。\n可解读为:\n- 'Essence' (核心)\n- 'Ora' (拉丁语'时刻', '现在')\n\n🌄 Eos\n希腊黎明女神。象征:\n- 新的开始\n- 光明清晰\n- 觉醒时刻\n\nEssora Eos = '必要之物新的黎明'",
                'show_startup': "启动时显示"
            },
            'ar': {
                'title': "مرحبًا بكم في Essora Eos",
                'main_text': "شكرًا لاختياركم Essora.\n\nتم تصميم هذا النظام ليكون خفيفًا وسريعًا وسهل الاستخدام.\n\n🔐 اسم المستخدم: essora\n🔐 كلمة المرور: essora\n\n⚙️ لتمكين/تعطيل الدخول التلقائي:\nمركز التحكم → نافذة الدخول",
                'about_text': "توزيعة مبنية على دبيان بطريقة بسيطة:\n• سريعة وخفيفة\n• بسيطة وقابلة للتخصيص\n• تحت سيطرتك الكاملة\n\nبدون برامج زائدة. بدون تعقيدات.",
                'name_meaning': "🌱 Essora\nاسم التوزيعة الأساسي. اسم مبتكر بدلالات نظيفة.\nيمكن تفسيره على أنه مزيج بين:\n- 'Essence' (الجوهر)\n- 'Ora' (اللاتينية: 'الآن')\n\n🌄 Eos\nإلهة الفجر اليونانية. تمثل:\n- البدايات الجديدة\n- الوضوح والضوء\n- الصحوة\n\nEssora Eos = 'فجر الأساسيات الجديد'",
                'show_startup': "عرض عند البدء"
            },
            'ca': {
                'title': "Benvingut a Essora Eos",
                'main_text': "Gràcies per triar Essora.\n\nAquest sistema està dissenyat per ser lleuger, ràpid i fàcil d'usar.\n\n🔐 Usuari: essora\n🔐 Contrasenya: essora\n\n⚙️ Per activar/desactivar l'autologin:\nCentre de Control → Finestra d'Inici",
                'about_text': "Distribució minimalista basada en Devuan:\n• Ràpida i lleugera\n• Simple i personalitzable\n• Sota el teu control complet\n\nSense programari superflu. Sense complicacions.",
                'name_meaning': "🌱 Essora\nNom base de la distribució. Nom inventat amb connotacions netes.\nEs podria interpretar com a fusió entre:\n- 'Essence' (essència)\n- 'Ora' (llatí: 'hora', 'ara')\n\n🌄 Eos\nDeessa grega de l'alba. Representa:\n- Nous començaments\n- Claror i llum\n- El despertar\n\nEssora Eos = 'La nova alba de l'essencial'",
                'show_startup': "Mostrar a l'inici"
            },
            'hu': {
                'title': "Üdvözöljük az Essora Eos-ban",
                'main_text': "Köszönjük, hogy az Essora-t választotta.\n\nEz a rendszer könnyű, gyors és könnyen használható.\n\n🔐 Felhasználónév: essora\n🔐 Jelszó: essora\n\n⚙️ Automatikus bejelentkezés be/ki:\nVezérlőpult → Bejelentkezési ablak",
                'about_text': "Minimalista Devuan-alapú disztribúció:\n• Gyors és könnyű\n• Egyszerű és testreszabható\n• Teljesen az Ön irányítása alatt\n\nNincs felesleges szoftver. Nincs bonyolultság.",
                'name_meaning': "🌱 Essora\nAz alap disztribúció neve. Kitalált név tiszta felhangokkal.\nÉrtelmezhető mint:\n- 'Essence' (lényeg)\n- 'Ora' (latin: 'óra', 'most')\n\n🌄 Eos\nA hajnal görög istennője. Jelképez:\n- Új kezdeteket\n- Világosságot és fényt\n- Az ébredést\n\nEssora Eos = 'Az alapvető dolgok új hajnala'",
                'show_startup': "Megjelenítés indításkor"
            },
            'it': {
                'title': "Benvenuto in Essora Eos",
                'main_text': "Grazie per aver scelto Essora.\n\nQuesto sistema è progettato per essere leggero, veloce e facile da usare.\n\n🔐 Nome utente: essora\n🔐 Password: essora\n\n⚙️ Per abilitare/disabilitare l'autologin:\nCentro di Controllo → Finestra di Login",
                'about_text': "Distribuzione minimalista basata su Devuan:\n• Veloce e leggera\n• Semplice e personalizzabile\n• Completamente sotto il tuo controllo\n\nSenza bloatware. Senza complicazioni.",
                'name_meaning': "🌱 Essora\nNome base della distro. Nome inventato con connotazioni pulite.\nPuò essere interpretato come fusione tra:\n- 'Essence' (essenza)\n- 'Ora' (latino: 'ora', 'adesso')\n\n🌄 Eos\nDea greca dell'aurora. Rappresenta:\n- Nuovi inizi\n- Chiarezza e luce\n- Il risveglio\n\nEssora Eos = 'La nuova aurora dell'essenziale'",
                'show_startup': "Mostra all'avvio"
            },
            'pl': {
                'title': "Witamy w Essora Eos",
                'main_text': "Dziękujemy za wybranie Essora.\n\nTen system został zaprojektowany tak, aby był lekki, szybki i łatwy w użyciu.\n\n🔐 Nazwa użytkownika: essora\n🔐 Hasło: essora\n\n⚙️ Aby włączyć/wyłączyć autologowanie:\nCentrum Sterowania → Okno Logowania",
                'about_text': "Minimalistyczna dystrybucja oparta na Devuanie:\n• Szybka i lekka\n• Prosta i konfigurowalna\n• W pełni pod Twoją kontrolą\n\nBez zbędnego oprogramowania. Bez komplikacji.",
                'name_meaning': "🌱 Essora\nPodstawowa nazwa dystrybucji. Wymyślona nazwa o czystym brzmieniu.\nMożna interpretować jako połączenie:\n- 'Essence' (esencja)\n- 'Ora' (łac. 'godzina', 'teraz')\n\n🌄 Eos\nGrecka bogini świtu. Reprezentuje:\n- Nowe początki\n- Jasność i światło\n- Przebudzenie\n\nEssora Eos = 'Nowy świt esencji'",
                'show_startup': "Pokaż przy uruchomieniu"
            },
            'pt': {
                'title': "Bem-vindo ao Essora Eos",
                'main_text': "Obrigado por escolher o Essora.\n\nEste sistema foi projetado para ser leve, rápido e fácil de usar.\n\n🔐 Nome de usuário: essora\n🔐 Senha: essora\n\n⚙️ Para ativar/desativar login automático:\nCentro de Controle → Janela de Login",
                'about_text': "Distribuição minimalista baseada em Devuan:\n• Rápida e leve\n• Simples e personalizável\n• Totalmente sob seu controle\n\nSem bloatware. Sem complicações.",
                'name_meaning': "🌱 Essora\nNome base da distribuição. Nome inventado com conotações limpas.\nPode ser interpretado como uma fusão entre:\n- 'Essence' (essência)\n- 'Ora' (latim: 'hora', 'agora')\n\n🌄 Eos\nDeusa grega do amanhecer. Representa:\n- Novos começos\n- Clareza e luz\n- O despertar\n\nEssora Eos = 'O novo amanhecer do essencial'",
                'show_startup': "Mostrar na inicialização"
            }
        }

        self.current_lang = "en"

    def build_ui(self):
        # HeaderBar estilo GNOME
        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.props.title = "Essora Welcome"
        self.set_titlebar(header)

        # Logo en el header
        if self.logo_pb:
            logo_img = Gtk.Image.new_from_pixbuf(self.logo_pb)
            header.pack_start(logo_img)

        # Botón SourceForge
        sf_button = Gtk.Button()
        if self.sf_pb:
            sf_button.set_image(Gtk.Image.new_from_pixbuf(self.sf_pb))
        sf_button.set_tooltip_text("Visit SourceForge")
        sf_button.connect("clicked", self.on_open_sourceforge)
        header.pack_start(sf_button)

        # Comunidad (al lado de SourceForge)
        community_btn = Gtk.MenuButton()
        community_btn.set_relief(Gtk.ReliefStyle.NONE)
        if self.community_hdr_pb:
            community_btn.set_image(Gtk.Image.new_from_pixbuf(self.community_hdr_pb))
            community_btn.set_always_show_image(True)
        community_btn.set_tooltip_text(self.tr("community_tip"))

        community_menu = Gtk.Menu()

        def add_social_item(label: str, icon_pb, activate_cb):
            item = Gtk.MenuItem()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            if icon_pb:
                box.pack_start(Gtk.Image.new_from_pixbuf(icon_pb), False, False, 0)
            lab = Gtk.Label(label=label, xalign=0.0)
            box.pack_start(lab, True, True, 0)
            item.add(box)
            item.connect("activate", activate_cb)
            community_menu.append(item)
            return item

        add_social_item("Telegram", self.tg_pb, self.on_open_telegram)
        add_social_item("Reddit", self.reddit_pb, self.on_open_reddit)
        add_social_item("X", self.x_pb, self.on_open_x)
        add_social_item("YouTube", self.yt_pb, self.on_open_youtube)

        community_menu.show_all()
        community_btn.set_popup(community_menu)
        header.pack_start(community_btn)

        # Selector de idioma
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)

        if self.locale_pb:
            lang_box.pack_start(Gtk.Image.new_from_pixbuf(self.locale_pb), False, False, 0)

        self.lang_combo = Gtk.ComboBoxText()
        for code in sorted(self.languages.keys()):
            self.lang_combo.append_text(code)
        self.lang_combo.set_active(sorted(self.languages.keys()).index(self.current_lang))
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, False, False, 0)

        header.pack_start(lang_box)

        # Botón Donate (menú desplegable)
        self.donate_btn = Gtk.MenuButton()
        self.donate_btn.set_relief(Gtk.ReliefStyle.NONE)
        # Para que SIEMPRE se vea: texto + icono (si existe)
        self.donate_btn.set_label(self.tr("donate"))
        if self.donate_hdr_pb:
            self.donate_btn.set_image(Gtk.Image.new_from_pixbuf(self.donate_hdr_pb))
            self.donate_btn.set_always_show_image(True)
        self.donate_btn.set_tooltip_text(self.tr("donate_tip"))

        donate_menu = Gtk.Menu()

        def add_menu_item(label: str, icon_pb, activate_cb):
            item = Gtk.MenuItem()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            if icon_pb:
                box.pack_start(Gtk.Image.new_from_pixbuf(icon_pb), False, False, 0)
            lab = Gtk.Label(label=label, xalign=0.0)
            box.pack_start(lab, True, True, 0)
            item.add(box)
            item.connect("activate", activate_cb)
            donate_menu.append(item)
            return item

        add_menu_item(self.tr("donate_paypal"), self.paypal_pb, self.on_open_paypal)
        add_menu_item(self.tr("donate_qr"), self.qr_pb_small, self.on_open_qr)

        donate_menu.append(Gtk.SeparatorMenuItem())

        add_menu_item(self.tr("donate_bitcoin"), self.btc_pb, self.on_donate_bitcoin)
        add_menu_item(self.tr("donate_ethereum"), self.eth_pb, self.on_donate_ethereum)
        add_menu_item(self.tr("donate_usdt"), self.usdt_pb, self.on_donate_usdt)

        donate_menu.show_all()
        self.donate_btn.set_popup(donate_menu)
        header.pack_end(self.donate_btn)

        # CheckButton para mostrar al inicio (a la derecha)
        self.show_startup_check = Gtk.CheckButton()
        self.show_startup_check.set_active(load_autostart_config())
        self.show_startup_check.connect("toggled", self.on_startup_toggled)
        header.pack_end(self.show_startup_check)

        # Container principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        main_box.set_border_width(20)
        self.add(main_box)

        # Título principal
        self.title_label = Gtk.Label()
        self.title_label.set_xalign(0.0)
        main_box.pack_start(self.title_label, False, False, 0)

        # ScrolledWindow para el contenido
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroller.set_vexpand(True)
        main_box.pack_start(scroller, True, True, 0)

        self.textview = Gtk.TextView()
        self.textview.set_wrap_mode(Gtk.WrapMode.WORD)
        self.textview.set_editable(False)
        self.textview.set_cursor_visible(False)
        self.textview.set_left_margin(10)
        self.textview.set_right_margin(10)
        scroller.add(self.textview)

    def open_url(self, url: str):
        try:
            subprocess.Popen(["xdg-open", url])
        except Exception as e:
            print(f"Error opening URL: {e}")

    def open_file(self, filepath: str):
        try:
            if filepath and os.path.exists(filepath):
                subprocess.Popen(["xdg-open", filepath])
        except Exception as e:
            print(f"Error opening file: {e}")

    def copy_to_clipboard(self, text: str):
        try:
            cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            cb.set_text(text, -1)
            cb.store()
        except Exception as e:
            print(f"Error copying to clipboard: {e}")

    def show_qr_dialog(self):
        dlg = Gtk.Dialog(title=self.tr("donate_qr"), transient_for=self, modal=True)
        dlg.set_resizable(False)

        content = dlg.get_content_area()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_border_width(12)

        pb_big = load_pixbuf(IMG_QR_PAYPAL, (420, 420))
        if pb_big:
            box.pack_start(Gtk.Image.new_from_pixbuf(pb_big), True, True, 0)
        else:
            box.pack_start(Gtk.Label(label=IMG_QR_PAYPAL, xalign=0.0), False, False, 0)

        content.add(box)

        dlg.add_button(self.tr("open_in_viewer"), 1)
        dlg.add_button(self.tr("close"), Gtk.ResponseType.CLOSE)
        dlg.show_all()

        resp = dlg.run()
        dlg.destroy()

        if resp == 1:
            self.open_file(IMG_QR_PAYPAL)

    def show_address_dialog(self, title: str, address: str, network: str, icon_pb=None):
        # Ventana más ancha para que se vea completa la dirección
        dlg = Gtk.Dialog(title=title, transient_for=self, modal=True)
        dlg.set_resizable(False)
        dlg.set_default_size(620, -1)

        content = dlg.get_content_area()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_border_width(12)

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        if icon_pb:
            head.pack_start(Gtk.Image.new_from_pixbuf(icon_pb), False, False, 0)
        head_label = Gtk.Label(label=title)
        head_label.set_xalign(0.0)
        head.pack_start(head_label, True, True, 0)
        box.pack_start(head, False, False, 0)

        # Solo la dirección (esto es lo que se copia)
        entry = Gtk.Entry()
        entry.set_text(address)
        entry.set_editable(False)
        entry.set_can_focus(True)
        entry.set_width_chars(56)
        entry.set_hexpand(True)
        entry.select_region(0, -1)
        box.pack_start(entry, False, False, 0)

        # Red fija (NO copiable)
        net_label = Gtk.Label(label=f"- {network} -")
        net_label.set_xalign(0.0)
        net_label.set_selectable(False)
        box.pack_start(net_label, False, False, 0)

        status = Gtk.Label(label="")
        status.set_xalign(0.0)

        btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        copy_btn = Gtk.Button(label=self.tr("copy"))

        def _do_copy(*_):
            self.copy_to_clipboard(address)
            status.set_text(self.tr("copied"))
            entry.select_region(0, -1)

        copy_btn.connect("clicked", _do_copy)
        btn_row.pack_start(copy_btn, False, False, 0)
        box.pack_start(btn_row, False, False, 0)
        box.pack_start(status, False, False, 0)

        content.add(box)

        dlg.add_button(self.tr("close"), Gtk.ResponseType.CLOSE)
        dlg.show_all()
        dlg.run()
        dlg.destroy()

    def on_open_sourceforge(self, *_):
        self.open_url("https://sourceforge.net/projects/essora/")

    def on_open_telegram(self, *_):
        self.open_url(COMMUNITY_TG_URL)

    def on_open_reddit(self, *_):
        self.open_url(COMMUNITY_REDDIT_URL)

    def on_open_x(self, *_):
        self.open_url(COMMUNITY_X_URL)

    def on_open_youtube(self, *_):
        self.open_url(COMMUNITY_YT_URL)

    def on_open_paypal(self, *_):
        self.open_url(DONATE_URL)

    def on_open_qr(self, *_):
        self.show_qr_dialog()

    def on_donate_bitcoin(self, *_):
        self.show_address_dialog(self.tr("donate_bitcoin"), DONATE_ADDR, BTC_NET, self.btc_pb)

    def on_donate_ethereum(self, *_):
        self.show_address_dialog(self.tr("donate_ethereum"), DONATE_ADDR, ETH_NET, self.eth_pb)

    def on_donate_usdt(self, *_):
        self.show_address_dialog(self.tr("donate_usdt"), DONATE_ADDR, USDT_NET, self.usdt_pb)

    def on_language_changed(self, combo):
        text = combo.get_active_text()
        self.current_lang = text if text in self.languages else "en"
        self.update_content()

    def on_startup_toggled(self, check):
        save_autostart_config(check.get_active())

    def update_content(self):
        lang = self.languages.get(self.current_lang, self.languages["en"])

        # Actualizar título del header
        header = self.get_titlebar()
        if header:
            header.props.title = lang["title"]

        # Actualizar título principal
        safe_title = GLib.markup_escape_text(lang["title"])
        self.title_label.set_markup(f"<span size='16000' weight='bold'>{safe_title}</span>")

        # Actualizar tooltip del checkbox
        self.show_startup_check.set_tooltip_text(lang["show_startup"])

        # Contenido completo
        full_text = (
            f"{lang['main_text']}\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{lang['about_text']}\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{lang['name_meaning']}"
        )

        buf = self.textview.get_buffer()
        buf.set_text(full_text)


def main():
    # Si está configurado para no mostrarse, salir inmediatamente
    if not load_autostart_config():
        return

    win = EssoraWelcomeApp()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
