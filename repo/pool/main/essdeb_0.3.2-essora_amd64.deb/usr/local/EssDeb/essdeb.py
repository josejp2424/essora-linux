#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# version 0.4.0
# EssDeb - Instalador de paquetes .deb para Essora
# Copyright (C) 2026 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
EssDeb - DEB Package Installer for Essora Linux
A modern GTK3 package installer with drag-and-drop support

Author: josejp2424
License: GPL-3.0
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
import subprocess
import os
import sys
import apt
import apt.debfile
import apt_pkg
import locale
import threading

class EssDeb(Gtk.Window):
    def __init__(self):
        super().__init__(title="EssDeb")
        self.set_default_size(700, 550)
        self.set_border_width(0)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Variables
        self.package_file = None
        self.package_info = {}
        self.is_installed = False
        self.icon_path = "/usr/local/EssDeb/EssDeb.svg"
        
        # Set window icon
        if os.path.exists(self.icon_path):
            self.set_icon_from_file(self.icon_path)
        
        # Translations
        self.translations = {
            'en': {
                'title': 'EssDeb - Package Installer',
                'select_package': 'Select DEB',
                'install': 'Install',
                'reinstall': 'Reinstall',
                'remove': 'Remove',
                'cancel': 'Cancel',
                'about': 'About',
                'version': 'Version',
                'status': 'Status',
                'description': 'Description',
                'size': 'Size',
                'depends': 'Dependencies',
                'installed': 'Installed',
                'not_installed': 'Not installed',
                'installing': 'Installing...',
                'removing': 'Removing...',
                'success': 'Installation successful',
                'success_remove': 'Removal successful',
                'error': 'Error',
                'select_deb': 'Please select a .deb package',
                'no_package': 'No package selected',
                'drag_drop': 'Drag & drop a .deb package here',
                'architecture': 'Architecture',
                'maintainer': 'Maintainer',
                'homepage': 'Homepage',
                'section': 'Section',
                'priority': 'Priority',
                'confirm_remove': 'Are you sure you want to remove this package?',
                'confirm': 'Confirm',
                'package_removed': 'Package removed successfully',
                'fixing_deps': 'Fixing dependencies...',
                'about_title': 'About EssDeb',
                'license': 'License',
                'author': 'Author',
                'notes_title': 'Notes for Essora Linux',
                'note_openrc': '• Compatible with OpenRC',
                'note_pkexec': '• Uses pkexec instead of gksu',
                'note_design': '• Coherent design with other Essora applications',
                'note_xlibre': '• Xlibre support',
                'refreshing_menu': 'Refreshing menu...',
                'progress_unpacking': 'Unpacking...',
                'progress_setting_up': 'Setting up...',
                'progress_removing': 'Removing package...',
                'progress_fixing': 'Fixing dependencies...',
                'progress_complete': 'Complete',
                'update': 'Update',
                'status_update_available': 'Update available (installed: {installed_ver})',
                'status_installed_newer': 'Installed (newer version: {installed_ver})',
            },
            'es': {
                'title': 'EssDeb - Instalador de Paquetes',
                'select_package': 'Seleccionar DEB',
                'install': 'Instalar',
                'reinstall': 'Reinstalar',
                'remove': 'Desinstalar',
                'cancel': 'Cancelar',
                'about': 'Acerca de',
                'version': 'Versión',
                'status': 'Estado',
                'description': 'Descripción',
                'size': 'Tamaño',
                'depends': 'Dependencias',
                'installed': 'Instalado',
                'not_installed': 'No instalado',
                'installing': 'Instalando...',
                'removing': 'Desinstalando...',
                'success': 'Instalación exitosa',
                'success_remove': 'Desinstalación exitosa',
                'error': 'Error',
                'select_deb': 'Por favor, seleccione un paquete .deb',
                'no_package': 'Ningún paquete seleccionado',
                'drag_drop': 'Arrastra y suelta un paquete .deb aquí',
                'architecture': 'Arquitectura',
                'maintainer': 'Mantenedor',
                'homepage': 'Sitio web',
                'section': 'Sección',
                'priority': 'Prioridad',
                'confirm_remove': '¿Está seguro de que desea desinstalar este paquete?',
                'confirm': 'Confirmar',
                'package_removed': 'Paquete desinstalado correctamente',
                'fixing_deps': 'Corrigiendo dependencias...',
                'about_title': 'Acerca de EssDeb',
                'license': 'Licencia',
                'author': 'Autor',
                'notes_title': 'Notas para Essora Linux',
                'note_openrc': '• Compatible con OpenRC',
                'note_pkexec': '• Usa pkexec en lugar de gksu',
                'note_design': '• Diseño coherente con otras aplicaciones Essora',
                'note_xlibre': '• Soporte para Xlibre',
                'refreshing_menu': 'Refrescando menú...',
                'progress_unpacking': 'Descomprimiendo...',
                'progress_setting_up': 'Configurando...',
                'progress_removing': 'Eliminando paquete...',
                'progress_fixing': 'Corrigiendo dependencias...',
                'progress_complete': 'Completado',
                'update': 'Actualizar',
                'status_update_available': 'Actualización disponible (instalado: {installed_ver})',
                'status_installed_newer': 'Instalado (versión más reciente: {installed_ver})',
            },
            'ar': {
                'title': 'EssDeb - مثبت الحزم',
                'select_package': 'اختر DEB',
                'install': 'تثبيت',
                'reinstall': 'إعادة التثبيت',
                'remove': 'إزالة',
                'cancel': 'إلغاء',
                'about': 'حول',
                'version': 'الإصدار',
                'status': 'الحالة',
                'description': 'الوصف',
                'size': 'الحجم',
                'depends': 'التبعيات',
                'installed': 'مثبت',
                'not_installed': 'غير مثبت',
                'installing': 'جاري التثبيت...',
                'removing': 'جاري الإزالة...',
                'success': 'تم التثبيت بنجاح',
                'success_remove': 'تم الإزالة بنجاح',
                'error': 'خطأ',
                'select_deb': 'يرجى اختيار حزمة .deb',
                'no_package': 'لم يتم اختيار حزمة',
                'drag_drop': 'اسحب وأفلت حزمة .deb هنا',
                'architecture': 'البنية',
                'maintainer': 'المطور',
                'homepage': 'الموقع',
                'section': 'القسم',
                'priority': 'الأولوية',
                'confirm_remove': 'هل أنت متأكد من إزالة هذه الحزمة؟',
                'confirm': 'تأكيد',
                'package_removed': 'تم إزالة الحزمة بنجاح',
                'fixing_deps': 'إصلاح التبعيات...',
                'about_title': 'حول EssDeb',
                'license': 'الترخيص',
                'author': 'المؤلف',
                'notes_title': 'ملاحظات لـ Essora Linux',
                'note_openrc': '• متوافق مع OpenRC',
                'note_pkexec': '• يستخدم pkexec بدلاً من gksu',
                'note_design': '• تصميم متسق مع تطبيقات Essora الأخرى',
                'note_xlibre': '• دعم Xlibre',
                'refreshing_menu': 'تحديث القائمة...',
                'progress_unpacking': 'جاري التفريغ...',
                'progress_setting_up': 'جاري الإعداد...',
                'progress_removing': 'جاري إزالة الحزمة...',
                'progress_fixing': 'إصلاح التبعيات...',
                'progress_complete': 'مكتمل',
                'update': 'تحديث',
                'status_update_available': 'تحديث متاح (مثبت: {installed_ver})',
                'status_installed_newer': 'مثبت (إصدار أحدث: {installed_ver})',
            },
            'ca': {
                'title': 'EssDeb - Instal·lador de Paquets',
                'select_package': 'Selecciona DEB',
                'install': 'Instal·lar',
                'reinstall': 'Reinstal·lar',
                'remove': 'Eliminar',
                'cancel': 'Cancel·lar',
                'about': 'Quant a',
                'version': 'Versió',
                'status': 'Estat',
                'description': 'Descripció',
                'size': 'Mida',
                'depends': 'Dependències',
                'installed': 'Instal·lat',
                'not_installed': 'No instal·lat',
                'installing': 'Instal·lant...',
                'removing': 'Eliminant...',
                'success': 'Instal·lació correcta',
                'success_remove': 'Eliminació correcta',
                'error': 'Error',
                'select_deb': 'Si us plau, seleccioni un paquet .deb',
                'no_package': 'Cap paquet seleccionat',
                'drag_drop': 'Arrossega i deixa anar un paquet .deb aquí',
                'architecture': 'Arquitectura',
                'maintainer': 'Mantenidor',
                'homepage': 'Lloc web',
                'section': 'Secció',
                'priority': 'Prioritat',
                'confirm_remove': 'Esteu segur que voleu eliminar aquest paquet?',
                'confirm': 'Confirmar',
                'package_removed': 'Paquet eliminat correctament',
                'fixing_deps': 'Corregint dependències...',
                'about_title': 'Quant a EssDeb',
                'license': 'Llicència',
                'author': 'Autor',
                'notes_title': 'Notes per a Essora Linux',
                'note_openrc': '• Compatible amb OpenRC',
                'note_pkexec': '• Utilitza pkexec en lloc de gksu',
                'note_design': '• Disseny coherent amb altres aplicacions Essora',
                'note_xlibre': '• Suport per a Xlibre',
                'refreshing_menu': 'Refrescant menú...',
                'progress_unpacking': 'Descomprimint...',
                'progress_setting_up': 'Configurant...',
                'progress_removing': 'Eliminant paquet...',
                'progress_fixing': 'Corregint dependències...',
                'progress_complete': 'Completat',
                'update': 'Actualitza',
                'status_update_available': 'Actualització disponible (instal·lat: {installed_ver})',
                'status_installed_newer': 'Instal·lat (versió més recent: {installed_ver})',
            },
            'fr': {
                'title': 'EssDeb - Installateur de Paquets',
                'select_package': 'Sélectionner DEB',
                'install': 'Installer',
                'reinstall': 'Réinstaller',
                'remove': 'Désinstaller',
                'cancel': 'Annuler',
                'about': 'À propos',
                'version': 'Version',
                'status': 'État',
                'description': 'Description',
                'size': 'Taille',
                'depends': 'Dépendances',
                'installed': 'Installé',
                'not_installed': 'Non installé',
                'installing': 'Installation...',
                'removing': 'Suppression...',
                'success': 'Installation réussie',
                'success_remove': 'Suppression réussie',
                'error': 'Erreur',
                'select_deb': 'Veuillez sélectionner un paquet .deb',
                'no_package': 'Aucun paquet sélectionné',
                'drag_drop': 'Glissez-déposez un paquet .deb ici',
                'architecture': 'Architecture',
                'maintainer': 'Mainteneur',
                'homepage': 'Site web',
                'section': 'Section',
                'priority': 'Priorité',
                'confirm_remove': 'Êtes-vous sûr de vouloir supprimer ce paquet?',
                'confirm': 'Confirmer',
                'package_removed': 'Paquet supprimé avec succès',
                'fixing_deps': 'Correction des dépendances...',
                'about_title': 'À propos de EssDeb',
                'license': 'Licence',
                'author': 'Auteur',
                'notes_title': 'Notes pour Essora Linux',
                'note_openrc': '• Compatible avec OpenRC',
                'note_pkexec': '• Utilise pkexec au lieu de gksu',
                'note_design': '• Conception cohérente avec les autres applications Essora',
                'note_xlibre': '• Support de Xlibre',
                'refreshing_menu': 'Rafraîchissement du menu...',
                'progress_unpacking': 'Extraction en cours...',
                'progress_setting_up': 'Configuration en cours...',
                'progress_removing': 'Suppression du paquet...',
                'progress_fixing': 'Correction des dépendances...',
                'progress_complete': 'Terminé',
                'update': 'Mettre à jour',
                'status_update_available': 'Mise à jour disponible (installé: {installed_ver})',
                'status_installed_newer': 'Installé (version plus récente: {installed_ver})',
            },
            'it': {
                'title': 'EssDeb - Installatore Pacchetti',
                'select_package': 'Seleziona DEB',
                'install': 'Installa',
                'reinstall': 'Reinstalla',
                'remove': 'Rimuovi',
                'cancel': 'Annulla',
                'about': 'Informazioni',
                'version': 'Versione',
                'status': 'Stato',
                'description': 'Descrizione',
                'size': 'Dimensione',
                'depends': 'Dipendenze',
                'installed': 'Installato',
                'not_installed': 'Non installato',
                'installing': 'Installazione...',
                'removing': 'Rimozione...',
                'success': 'Installazione riuscita',
                'success_remove': 'Rimozione riuscita',
                'error': 'Errore',
                'select_deb': 'Seleziona un pacchetto .deb',
                'no_package': 'Nessun pacchetto selezionato',
                'drag_drop': 'Trascina e rilascia un pacchetto .deb qui',
                'architecture': 'Architettura',
                'maintainer': 'Manutentore',
                'homepage': 'Sito web',
                'section': 'Sezione',
                'priority': 'Priorità',
                'confirm_remove': 'Sei sicuro di voler rimuovere questo pacchetto?',
                'confirm': 'Conferma',
                'package_removed': 'Pacchetto rimosso con successo',
                'fixing_deps': 'Correzione dipendenze...',
                'about_title': 'Informazioni su EssDeb',
                'license': 'Licenza',
                'author': 'Autore',
                'notes_title': 'Note per Essora Linux',
                'note_openrc': '• Compatibile con OpenRC',
                'note_pkexec': '• Usa pkexec invece di gksu',
                'note_design': '• Design coerente con le altre applicazioni Essora',
                'note_xlibre': '• Supporto per Xlibre',
                'refreshing_menu': 'Aggiornamento menu...',
                'progress_unpacking': 'Estrazione in corso...',
                'progress_setting_up': 'Configurazione in corso...',
                'progress_removing': 'Rimozione pacchetto...',
                'progress_fixing': 'Correzione dipendenze...',
                'progress_complete': 'Completato',
                'update': 'Aggiorna',
                'status_update_available': 'Aggiornamento disponibile (installato: {installed_ver})',
                'status_installed_newer': 'Installato (versione più recente: {installed_ver})',
            },
            'pt': {
                'title': 'EssDeb - Instalador de Pacotes',
                'select_package': 'Selecionar DEB',
                'install': 'Instalar',
                'reinstall': 'Reinstalar',
                'remove': 'Remover',
                'cancel': 'Cancelar',
                'about': 'Sobre',
                'version': 'Versão',
                'status': 'Estado',
                'description': 'Descrição',
                'size': 'Tamanho',
                'depends': 'Dependências',
                'installed': 'Instalado',
                'not_installed': 'Não instalado',
                'installing': 'Instalando...',
                'removing': 'Removendo...',
                'success': 'Instalação bem-sucedida',
                'success_remove': 'Remoção bem-sucedida',
                'error': 'Erro',
                'select_deb': 'Por favor, selecione um pacote .deb',
                'no_package': 'Nenhum pacote selecionado',
                'drag_drop': 'Arraste e solte um pacote .deb aqui',
                'architecture': 'Arquitetura',
                'maintainer': 'Mantenedor',
                'homepage': 'Site',
                'section': 'Seção',
                'priority': 'Prioridade',
                'confirm_remove': 'Tem certeza de que deseja remover este pacote?',
                'confirm': 'Confirmar',
                'package_removed': 'Pacote removido com sucesso',
                'fixing_deps': 'Corrigindo dependências...',
                'about_title': 'Sobre EssDeb',
                'license': 'Licença',
                'author': 'Autor',
                'notes_title': 'Notas para Essora Linux',
                'note_openrc': '• Compatível com OpenRC',
                'note_pkexec': '• Usa pkexec em vez de gksu',
                'note_design': '• Design coerente com outros aplicativos Essora',
                'note_xlibre': '• Suporte para Xlibre',
                'refreshing_menu': 'Atualizando menu...',
                'progress_unpacking': 'Descompactando...',
                'progress_setting_up': 'Configurando...',
                'progress_removing': 'Removendo pacote...',
                'progress_fixing': 'Corrigindo dependências...',
                'progress_complete': 'Concluído',
                'update': 'Atualizar',
                'status_update_available': 'Atualização disponível (instalado: {installed_ver})',
                'status_installed_newer': 'Instalado (versão mais recente: {installed_ver})',
            },
            'hu': {
                'title': 'EssDeb - Csomagtelepítő',
                'select_package': 'DEB Kiválasztása',
                'install': 'Telepítés',
                'reinstall': 'Újratelepítés',
                'remove': 'Eltávolítás',
                'cancel': 'Mégse',
                'about': 'Névjegy',
                'version': 'Verzió',
                'status': 'Állapot',
                'description': 'Leírás',
                'size': 'Méret',
                'depends': 'Függőségek',
                'installed': 'Telepítve',
                'not_installed': 'Nincs telepítve',
                'installing': 'Telepítés...',
                'removing': 'Eltávolítás...',
                'success': 'Sikeres telepítés',
                'success_remove': 'Sikeres eltávolítás',
                'error': 'Hiba',
                'select_deb': 'Kérjük, válasszon egy .deb csomagot',
                'no_package': 'Nincs kiválasztott csomag',
                'drag_drop': 'Húzzon ide egy .deb csomagot',
                'architecture': 'Architektúra',
                'maintainer': 'Karbantartó',
                'homepage': 'Weboldal',
                'section': 'Szakasz',
                'priority': 'Prioritás',
                'confirm_remove': 'Biztosan el szeretné távolítani ezt a csomagot?',
                'confirm': 'Megerősítés',
                'package_removed': 'Csomag sikeresen eltávolítva',
                'fixing_deps': 'Függőségek javítása...',
                'about_title': 'EssDeb Névjegy',
                'license': 'Licenc',
                'author': 'Szerző',
                'notes_title': 'Jegyzetek Essora Linux-hoz',
                'note_openrc': '• Kompatibilis az OpenRC-vel',
                'note_pkexec': '• A pkexec-et használja gksu helyett',
                'note_design': '• Egységes dizájn más Essora alkalmazásokkal',
                'note_xlibre': '• Xlibre támogatás',
                'refreshing_menu': 'Menü frissítése...',
                'progress_unpacking': 'Kicsomagolás...',
                'progress_setting_up': 'Konfiguráció...',
                'progress_removing': 'Csomag eltávolítása...',
                'progress_fixing': 'Függőségek javítása...',
                'progress_complete': 'Kész',
                'update': 'Frissítés',
                'status_update_available': 'Frissítés elérhető (telepítve: {installed_ver})',
                'status_installed_newer': 'Telepítve (újabb verzió: {installed_ver})',
            },
            'ru': {
                'title': 'EssDeb - Установщик Пакетов',
                'select_package': 'Выбрать DEB',
                'install': 'Установить',
                'reinstall': 'Переустановить',
                'remove': 'Удалить',
                'cancel': 'Отмена',
                'about': 'О программе',
                'version': 'Версия',
                'status': 'Статус',
                'description': 'Описание',
                'size': 'Размер',
                'depends': 'Зависимости',
                'installed': 'Установлен',
                'not_installed': 'Не установлен',
                'installing': 'Установка...',
                'removing': 'Удаление...',
                'success': 'Установка завершена',
                'success_remove': 'Удаление завершено',
                'error': 'Ошибка',
                'select_deb': 'Пожалуйста, выберите пакет .deb',
                'no_package': 'Пакет не выбран',
                'drag_drop': 'Перетащите пакет .deb сюда',
                'architecture': 'Архитектура',
                'maintainer': 'Сопровождающий',
                'homepage': 'Веб-сайт',
                'section': 'Раздел',
                'priority': 'Приоритет',
                'confirm_remove': 'Вы уверены, что хотите удалить этот пакет?',
                'confirm': 'Подтвердить',
                'package_removed': 'Пакет успешно удален',
                'fixing_deps': 'Исправление зависимостей...',
                'about_title': 'О программе EssDeb',
                'license': 'Лицензия',
                'author': 'Автор',
                'notes_title': 'Примечания для Essora Linux',
                'note_openrc': '• Совместим с OpenRC',
                'note_pkexec': '• Использует pkexec вместо gksu',
                'note_design': '• Согласованный дизайн с другими приложениями Essora',
                'note_xlibre': '• Поддержка Xlibre',
                'refreshing_menu': 'Обновление меню...',
                'progress_unpacking': 'Распаковка...',
                'progress_setting_up': 'Настройка...',
                'progress_removing': 'Удаление пакета...',
                'progress_fixing': 'Исправление зависимостей...',
                'progress_complete': 'Завершено',
                'update': 'Обновить',
                'status_update_available': 'Доступно обновление (установлена: {installed_ver})',
                'status_installed_newer': 'Установлена (более новая версия: {installed_ver})',
            },
            'ja': {
                'title': 'EssDeb - パッケージインストーラー',
                'select_package': 'DEBを選択',
                'install': 'インストール',
                'reinstall': '再インストール',
                'remove': 'アンインストール',
                'cancel': 'キャンセル',
                'about': '情報',
                'version': 'バージョン',
                'status': 'ステータス',
                'description': '説明',
                'size': 'サイズ',
                'depends': '依存関係',
                'installed': 'インストール済み',
                'not_installed': '未インストール',
                'installing': 'インストール中...',
                'removing': 'アンインストール中...',
                'success': 'インストール成功',
                'success_remove': 'アンインストール成功',
                'error': 'エラー',
                'select_deb': '.debパッケージを選択してください',
                'no_package': 'パッケージが選択されていません',
                'drag_drop': '.debパッケージをここにドロップ',
                'architecture': 'アーキテクチャ',
                'maintainer': 'メンテナー',
                'homepage': 'ホームページ',
                'section': 'セクション',
                'priority': '優先度',
                'confirm_remove': 'このパッケージをアンインストールしてもよろしいですか？',
                'confirm': '確認',
                'package_removed': 'パッケージを正常にアンインストールしました',
                'fixing_deps': '依存関係を修正中...',
                'about_title': 'EssDebについて',
                'license': 'ライセンス',
                'author': '作者',
                'notes_title': 'Essora Linuxの注意事項',
                'note_openrc': '• OpenRCと互換性があります',
                'note_pkexec': '• gksuの代わりにpkexecを使用',
                'note_design': '• 他のEssoraアプリケーションと一貫したデザイン',
                'note_xlibre': '• Xlibreサポート',
                'refreshing_menu': 'メニュー更新中...',
                'progress_unpacking': 'アンパック中...',
                'progress_setting_up': 'セットアップ中...',
                'progress_removing': 'パッケージ削除中...',
                'progress_fixing': '依存関係修正中...',
                'progress_complete': '完了',
                'update': 'アップデート',
                'status_update_available': 'アップデート利用可能 (インストール済み: {installed_ver})',
                'status_installed_newer': 'インストール済み (新しいバージョン: {installed_ver})',
            },
            'hi': {
                'title': 'EssDeb - पैकेज इंस्टॉलर',
                'select_package': 'DEB चुनें',
                'install': 'इंस्टॉल करें',
                'reinstall': 'पुनः इंस्टॉल करें',
                'remove': 'हटाएं',
                'cancel': 'रद्द करें',
                'about': 'के बारे में',
                'version': 'संस्करण',
                'status': 'स्थिति',
                'description': 'विवरण',
                'size': 'आकार',
                'depends': 'निर्भरताएं',
                'installed': 'इंस्टॉल किया गया',
                'not_installed': 'इंस्टॉल नहीं किया गया',
                'installing': 'इंस्टॉल हो रहा है...',
                'removing': 'हटाया जा रहा है...',
                'success': 'इंस्टॉलेशन सफल',
                'success_remove': 'निष्कासन सफल',
                'error': 'त्रुटि',
                'select_deb': 'कृपया एक .deb पैकेज चुनें',
                'no_package': 'कोई पैकेज चयनित नहीं',
                'drag_drop': 'यहां एक .deb पैकेज खींचें और छोड़ें',
                'architecture': 'वास्तुकला',
                'maintainer': 'अनुरक्षक',
                'homepage': 'होमपेज',
                'section': 'अनुभाग',
                'priority': 'प्राथमिकता',
                'confirm_remove': 'क्या आप वाकई इस पैकेज को हटाना चाहते हैं?',
                'confirm': 'पुष्टि करें',
                'package_removed': 'पैकेज सफलतापूर्वक हटाया गया',
                'fixing_deps': 'निर्भरताओं को ठीक किया जा रहा है...',
                'about_title': 'EssDeb के बारे में',
                'license': 'लाइसेंस',
                'author': 'लेखक',
                'notes_title': 'Essora Linux के लिए नोट्स',
                'note_openrc': '• OpenRC के साथ संगत',
                'note_pkexec': '• gksu के बजाय pkexec का उपयोग करता है',
                'note_design': '• अन्य Essora अनुप्रयोगों के साथ सुसंगत डिज़ाइन',
                'note_xlibre': '• Xlibre समर्थन',
                'refreshing_menu': 'मेनू को रिफ्रेश कर रहा है...',
                'progress_unpacking': 'अनपैक हो रहा है...',
                'progress_setting_up': 'सेटআप हो रहा है...',
                'progress_removing': 'पैकेज हटाया जा रहा है...',
                'progress_fixing': 'निर्भरताओं को ठीक किया जा रहा है...',
                'progress_complete': 'पूर्ण',
                'update': 'अपडेट करें',
                'status_update_available': 'अपडेट उपलब्ध (इंस्टॉल किया गया: {installed_ver})',
                'status_installed_newer': 'इंस्टॉल किया गया (नया संस्करण: {installed_ver})',
            },
            'th': {
                'title': 'EssDeb - ตัวติดตั้งแพ็คเกจ',
                'select_package': 'เลือก DEB',
                'install': 'ติดตั้ง',
                'reinstall': 'ติดตั้งใหม่',
                'remove': 'ถอนการติดตั้ง',
                'cancel': 'ยกเลิก',
                'about': 'เกี่ยวกับ',
                'version': 'เวอร์ชัน',
                'status': 'สถานะ',
                'description': 'คำอธิบาย',
                'size': 'ขนาด',
                'depends': 'การพึ่งพา',
                'installed': 'ติดตั้งแล้ว',
                'not_installed': 'ยังไม่ได้ติดตั้ง',
                'installing': 'กำลังติดตั้ง...',
                'removing': 'กำลังถอนการติดตั้ง...',
                'success': 'ติดตั้งสำเร็จ',
                'success_remove': 'ถอนการติดตั้งสำเร็จ',
                'error': 'ข้อผิดพลาด',
                'select_deb': 'กรุณาเลือกแพ็คเกจ .deb',
                'no_package': 'ไม่มีแพ็คเกจที่เลือก',
                'drag_drop': 'ลากและวางแพ็คเกจ .deb ที่นี่',
                'architecture': 'สถาปัตยกรรม',
                'maintainer': 'ผู้ดูแล',
                'homepage': 'โฮมเพจ',
                'section': 'ส่วน',
                'priority': 'ลำดับความสำคัญ',
                'confirm_remove': 'คุณแน่ใจหรือไม่ว่าต้องการถอนการติดตั้งแพ็คเกจนี้?',
                'confirm': 'ยืนยัน',
                'package_removed': 'ถอนการติดตั้งแพ็คเกจสำเร็จ',
                'fixing_deps': 'กำลังแก้ไขการพึ่งพา...',
                'about_title': 'เกี่ยวกับ EssDeb',
                'license': 'ใบอนุญาต',
                'author': 'ผู้เขียน',
                'notes_title': 'หมายเหตุสำหรับ Essora Linux',
                'note_openrc': '• เข้ากันได้กับ OpenRC',
                'note_pkexec': '• ใช้ pkexec แทน gksu',
                'note_design': '• การออกแบบที่สอดคล้องกับแอปพลิเคชัน Essora อื่น ๆ',
                'note_xlibre': '• รองรับ Xlibre',
                'refreshing_menu': 'กำลังรีเฟรชเมนู...',
                'progress_unpacking': 'กำลังแกเปิดกล่อง...',
                'progress_setting_up': 'กำลังตั้งค่า...',
                'progress_removing': 'กำลังเสร็จสิ้นแพ็คเกจ...',
                'progress_fixing': 'กำลังแก้ไขการพึ่งพา...',
                'progress_complete': 'เสร็จสิ้น',
                'update': 'อัปเดต',
                'status_update_available': 'อัปเดตพร้อม (ติดตั้งแล้ว: {installed_ver})',
                'status_installed_newer': 'ติดตั้งแล้ว (เวอร์ชันใหม่กว่า: {installed_ver})',
            },
        }
        
        # Detect system language
        sys_lang = locale.getdefaultlocale()[0]
        if sys_lang:
            lang_code = sys_lang.split('_')[0]
            self.lang = lang_code if lang_code in self.translations else 'en'
        else:
            self.lang = 'en'
        
        # Initialize apt
        apt_pkg.init()
        
        # Build UI
        self.build_ui()
        
        # Apply CSS
        self.apply_css()
        
        # Enable drag and drop
        self.setup_drag_drop()
        
    def _(self, key):
        """Get translation"""
        return self.translations[self.lang].get(key, key)
    
    def run_fixmenus(self):
        """Run /usr/local/bin/fixmenus after install/remove to refresh menus (Essora).
        Returns True if successfully ran, False if not found or failed."""
        fixmenus_path = "/usr/local/bin/fixmenus"

        if not os.path.exists(fixmenus_path):
            print("[EssDeb] fixmenus not found in /usr/local/bin/")
            return False

        cmd = [fixmenus_path]

        try:
            print(f"[EssDeb] Running: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            print(f"[EssDeb] fixmenus returned: {result.returncode}")
            if result.returncode == 0:
                return True
            print(f"[EssDeb] fixmenus stderr: {result.stderr}")
            return False
        except subprocess.TimeoutExpired:
            print("[EssDeb] fixmenus timed out")
            return False
        except Exception as e:
            print(f"[EssDeb] fixmenus exception: {e}")
            return False
    
    def apply_css(self):
        """Apply custom CSS styling"""
        css_provider = Gtk.CssProvider()
        css = b"""
        headerbar {
            background: linear-gradient(to bottom, #2d2d2d, #242424);
            color: #ffffff;
            border-bottom: 1px solid #1a1a1a;
        }
        
        .title {
            color: #ffffff;
            font-weight: bold;
        }
        
        .flat-button {
            border-radius: 6px;
            padding: 8px 16px;
            font-weight: 500;
            border: none;
            transition: all 0.2s;
        }
        
        .install-button {
            background: linear-gradient(to bottom, #4CAF50, #45a049);
            color: white;
        }
        
        .install-button:hover {
            background: linear-gradient(to bottom, #5CBF60, #4CAF50);
        }
        
        
        .reinstall-button {
            background: linear-gradient(to bottom, #FF9800, #F57C00);
            color: white;
        }
        
        .reinstall-button:hover {
            background: linear-gradient(to bottom, #FFA726, #FF9800);
        }
        
        .remove-button {
            background: linear-gradient(to bottom, #f44336, #d32f2f);
            color: white;
        }
        
        .remove-button:hover {
            background: linear-gradient(to bottom, #e57373, #f44336);
        }
        
        .cancel-button {
            background: linear-gradient(to bottom, #424242, #303030);
            color: white;
        }
        
        .cancel-button:hover {
            background: linear-gradient(to bottom, #525252, #424242);
        }
        
        .select-button {
            background: linear-gradient(to bottom, #2196F3, #1976D2);
            color: white;
        }
        
        .select-button:hover {
            background: linear-gradient(to bottom, #42A5F5, #2196F3);
        }
        
        .info-box {
            background-color: #2d2d2d;
            border-radius: 8px;
            padding: 12px;
            margin: 6px;
        }
        
        .info-label {
            color: #4CAF50;
            font-weight: bold;
            font-size: 10pt;
        }
        
        .info-value {
            color: #e0e0e0;
            font-size: 9pt;
        }
        
        .status-installed {
            color: #4CAF50;
            font-weight: bold;
        }
        
        .status-not-installed {
            color: #FF9800;
            font-weight: bold;
        }

        .status-update {
            color: #2196F3;
            font-weight: bold;
        }
        
        window {
            background-color: #1e1e1e;
        }
        
        textview {
            background-color: #2d2d2d;
            color: #e0e0e0;
            border-radius: 6px;
            padding: 4px;
        }
        
        textview text {
            background-color: #2d2d2d;
            color: #e0e0e0;
        }
        
        textview border {
            background-color: #2d2d2d;
        }
        
        scrolledwindow {
            border: 1px solid #3d3d3d;
            border-radius: 6px;
        }
        
        .drag-drop-area {
            border: 2px dashed #4CAF50;
            border-radius: 8px;
            background-color: #2d2d2d;
        }

        progressbar {
            border-radius: 6px;
            font-size: 9pt;
        }

        progressbar bar {
            background: linear-gradient(to right, #4CAF50, #45a049);
            border-radius: 6px;
            transition: all 0.15s;
        }

        progressbar trough {
            background-color: #3d3d3d;
            border-radius: 6px;
        }
        """
        css_provider.load_from_data(css)
        screen = self.get_screen()
        style_context = Gtk.StyleContext()
        style_context.add_provider_for_screen(
            screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def build_ui(self):
        """Build the user interface"""

        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.props.title = "EssDeb 3.2"
        header.get_style_context().add_class('title')
        self.set_titlebar(header)
        

        if os.path.exists(self.icon_path):
            icon_image = Gtk.Image.new_from_file(self.icon_path)
            icon_image.set_pixel_size(24)
            header.pack_start(icon_image)
        

        self.select_button = Gtk.Button(label=self._('select_package'))
        self.select_button.get_style_context().add_class('flat-button')
        self.select_button.get_style_context().add_class('select-button')
        self.select_button.connect("clicked", self.on_select_package)
        header.pack_start(self.select_button)
        

        menu_button = Gtk.MenuButton()
        menu_icon = Gtk.Image.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.BUTTON)
        menu_button.set_image(menu_icon)
        menu_button.get_style_context().add_class('flat-button')
        
   
        menu = Gtk.Menu()
        
        about_item = Gtk.MenuItem(label=self._('about'))
        about_item.connect("activate", self.show_about_dialog)
        menu.append(about_item)
        
        menu.show_all()
        menu_button.set_popup(menu)
        header.pack_end(menu_button)
        

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(main_box)
        

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_vexpand(True)
        main_box.pack_start(scrolled, True, True, 0)
        

        self.info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.info_box.set_margin_top(15)
        self.info_box.set_margin_bottom(15)
        self.info_box.set_margin_start(15)
        self.info_box.set_margin_end(15)
        scrolled.add(self.info_box)
        

        self.drag_drop_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.drag_drop_box.set_halign(Gtk.Align.CENTER)
        self.drag_drop_box.set_valign(Gtk.Align.CENTER)
        self.drag_drop_box.get_style_context().add_class('drag-drop-area')
        self.drag_drop_box.set_size_request(400, 200)
        
        drag_icon = Gtk.Image.new_from_icon_name("package-x-generic", Gtk.IconSize.DIALOG)
        drag_icon.set_pixel_size(64)
        self.drag_drop_box.pack_start(drag_icon, False, False, 20)
        
        drag_label = Gtk.Label()
        drag_label.set_markup(f"<span size='large'>{self._('drag_drop')}</span>")
        self.drag_drop_box.pack_start(drag_label, False, False, 0)
        
        self.info_box.pack_start(self.drag_drop_box, True, False, 0)
        

        self.icon_name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.icon_name_box.set_halign(Gtk.Align.CENTER)
        self.icon_name_box.set_no_show_all(True)
        self.info_box.pack_start(self.icon_name_box, False, False, 0)
        
        self.package_icon = Gtk.Image()
        if os.path.exists(self.icon_path):
            try:
                from gi.repository import GdkPixbuf
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.icon_path, 48, 48, True)
                self.package_icon.set_from_pixbuf(pixbuf)
            except:
                self.package_icon.set_from_icon_name("package-x-generic", Gtk.IconSize.DIALOG)
        else:
            self.package_icon.set_from_icon_name("package-x-generic", Gtk.IconSize.DIALOG)
        self.icon_name_box.pack_start(self.package_icon, False, False, 0)
        
        self.package_name_label = Gtk.Label()
        self.package_name_label.set_markup(f"<span size='x-large' weight='bold'>{self._('no_package')}</span>")
        self.icon_name_box.pack_start(self.package_name_label, False, False, 0)
        

        self.info_grid = Gtk.Grid()
        self.info_grid.set_row_spacing(10)
        self.info_grid.set_column_spacing(12)
        self.info_grid.set_halign(Gtk.Align.FILL)
        self.info_grid.set_margin_start(6)
        self.info_grid.set_margin_end(6)
        self.info_grid.get_style_context().add_class('info-box')
        self.info_grid.set_no_show_all(True)
        self.info_box.pack_start(self.info_grid, False, False, 0)
        

        self.desc_label = Gtk.Label(label=self._('description') + ":")
        self.desc_label.set_halign(Gtk.Align.START)
        self.desc_label.set_margin_top(5)
        self.desc_label.get_style_context().add_class('info-label')
        self.desc_label.set_no_show_all(True)
        self.info_box.pack_start(self.desc_label, False, False, 0)
        

        desc_scroll = Gtk.ScrolledWindow()
        desc_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        desc_scroll.set_min_content_height(120)
        desc_scroll.set_vexpand(True)
        desc_scroll.set_no_show_all(True)
        
        self.description_view = Gtk.TextView()
        self.description_view.set_editable(False)
        self.description_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.description_view.set_left_margin(10)
        self.description_view.set_right_margin(10)
        self.description_view.set_top_margin(10)
        self.description_view.set_bottom_margin(10)
        desc_scroll.add(self.description_view)
        self.info_box.pack_start(desc_scroll, True, True, 0)
        self.desc_scroll = desc_scroll
        

        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        button_box.set_margin_top(10)
        button_box.set_margin_bottom(10)
        button_box.set_margin_start(10)
        button_box.set_margin_end(10)
        button_box.set_halign(Gtk.Align.CENTER)
        main_box.pack_start(button_box, False, False, 0)
        

        self.install_button = Gtk.Button(label=self._('install'))
        self.install_button.set_size_request(120, 40)
        self.install_button.get_style_context().add_class('flat-button')
        self.install_button.get_style_context().add_class('install-button')
        self.install_button.connect("clicked", self.on_install)
        self.install_button.set_sensitive(False)
        button_box.pack_start(self.install_button, False, False, 0)
        

        

        self.reinstall_button = Gtk.Button(label=self._('reinstall'))
        self.reinstall_button.set_size_request(120, 40)
        self.reinstall_button.get_style_context().add_class('flat-button')
        self.reinstall_button.get_style_context().add_class('reinstall-button')
        self.reinstall_button.connect("clicked", self.on_install)
        self.reinstall_button.set_sensitive(False)
        self.reinstall_button.set_no_show_all(True)
        button_box.pack_start(self.reinstall_button, False, False, 0)
        

        self.remove_button = Gtk.Button(label=self._('remove'))
        self.remove_button.set_size_request(120, 40)
        self.remove_button.get_style_context().add_class('flat-button')
        self.remove_button.get_style_context().add_class('remove-button')
        self.remove_button.connect("clicked", self.on_remove)
        self.remove_button.set_sensitive(False)
        self.remove_button.set_no_show_all(True)
        button_box.pack_start(self.remove_button, False, False, 0)
        

        cancel_button = Gtk.Button(label=self._('cancel'))
        cancel_button.set_size_request(120, 40)
        cancel_button.get_style_context().add_class('flat-button')
        cancel_button.get_style_context().add_class('cancel-button')
        cancel_button.connect("clicked", lambda x: self.destroy())
        button_box.pack_start(cancel_button, False, False, 0)
    
    def setup_drag_drop(self):
        """Setup drag and drop functionality"""
        self.drag_dest_set(
            Gtk.DestDefaults.ALL,
            [],
            Gdk.DragAction.COPY
        )
        
        self.drag_dest_add_uri_targets()
        self.connect("drag-data-received", self.on_drag_data_received)
    
    def on_drag_data_received(self, widget, drag_context, x, y, data, info, time):
        """Handle dragged files"""
        uris = data.get_uris()
        if uris:
            file_path = uris[0].replace('file://', '').replace('%20', ' ')
            if file_path.endswith('.deb'):
                self.package_file = file_path
                self.load_package_info()
    
    def show_about_dialog(self, widget):
        """Show about dialog"""
        dialog = Gtk.Dialog(
            title=self._('about_title'),
            parent=self,
            flags=0
        )
        dialog.set_default_size(450, 350)
        
        content = dialog.get_content_area()
        content.set_spacing(15)
        content.set_margin_top(15)
        content.set_margin_bottom(15)
        content.set_margin_start(15)
        content.set_margin_end(15)
        

        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header_box.set_halign(Gtk.Align.CENTER)
        
        if os.path.exists(self.icon_path):
            about_icon = Gtk.Image.new_from_file(self.icon_path)
            about_icon.set_pixel_size(64)
        else:
            about_icon = Gtk.Image.new_from_icon_name("package-x-generic", Gtk.IconSize.DIALOG)
        header_box.pack_start(about_icon, False, False, 0)
        
        title_label = Gtk.Label()
        title_label.set_markup("<span size='xx-large' weight='bold' color='#4CAF50'>EssDeb</span>")
        header_box.pack_start(title_label, False, False, 0)
        
        content.pack_start(header_box, False, False, 0)
        
        # License
        license_label = Gtk.Label()
        license_label.set_markup(f"<span weight='bold' color='#4CAF50'>{self._('license')}:</span> GPL-3.0")
        license_label.set_halign(Gtk.Align.START)
        content.pack_start(license_label, False, False, 0)
        
        # Author
        author_label = Gtk.Label()
        author_label.set_markup(f"<span weight='bold' color='#4CAF50'>{self._('author')}:</span> josejp2424")
        author_label.set_halign(Gtk.Align.START)
        content.pack_start(author_label, False, False, 0)
        
        # Separator
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        content.pack_start(separator, False, False, 0)
        
        # Notes title
        notes_title = Gtk.Label()
        notes_title.set_markup(f"<span weight='bold' color='#4CAF50' size='large'>{self._('notes_title')}</span>")
        notes_title.set_halign(Gtk.Align.START)
        content.pack_start(notes_title, False, False, 0)
        
        # Notes
        notes = [
            self._('note_openrc'),
            self._('note_pkexec'),
            self._('note_design'),
            self._('note_xlibre'),
        ]
        
        for note in notes:
            note_label = Gtk.Label(label=note)
            note_label.set_halign(Gtk.Align.START)
            note_label.set_line_wrap(True)
            note_label.set_max_width_chars(50)
            content.pack_start(note_label, False, False, 0)
        
        # Close button
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)
        
        dialog.show_all()
        dialog.run()
        dialog.destroy()
    
    def on_select_package(self, widget):
        """Open file chooser to select DEB package"""
        dialog = Gtk.FileChooserDialog(
            title=self._('select_package'),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        

        filter_deb = Gtk.FileFilter()
        filter_deb.set_name("DEB Packages (*.deb)")
        filter_deb.add_pattern("*.deb")
        dialog.add_filter(filter_deb)
        
        filter_all = Gtk.FileFilter()
        filter_all.set_name("All files")
        filter_all.add_pattern("*")
        dialog.add_filter(filter_all)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.package_file = dialog.get_filename()
            self.load_package_info()
        
        dialog.destroy()
    
    def load_package_info(self):
        """Load and display package information"""
        if not self.package_file:
            return
        
        try:

            result = subprocess.run(
                ['dpkg-deb', '-f', self.package_file],
                capture_output=True,
                text=True,
                check=True
            )
            

            info = {}
            for line in result.stdout.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    info[key.strip()] = value.strip()
            
            self.package_info = info

            package_name = info.get('Package', '')
            deb_version = info.get('Version', '')
            self.installed_version = self.get_installed_version(package_name)

            if self.installed_version is None:
                self.is_installed = False
                self.version_state = 'not_installed'
            else:
                self.is_installed = True
                cmp = self.compare_versions(deb_version, self.installed_version)
                if cmp > 0:
                    self.version_state = 'update'
                elif cmp == 0:
                    self.version_state = 'same'
                else:
                    self.version_state = 'older'

            self.update_package_display()
            
        except subprocess.CalledProcessError as e:
            self.show_error_dialog(self._('error'), str(e))
    
    def get_installed_version(self, package_name):
        """Return the installed version string, or None if not installed.
        Creates a fresh apt.Cache each time to guarantee up-to-date state."""
        try:
            cache = apt.Cache()
            if package_name in cache:
                pkg = cache[package_name]
                if pkg.is_installed:
                    return pkg.installed.version
        except:
            pass
        return None

    def compare_versions(self, ver_new, ver_installed):
        """Compare two version strings using dpkg rules.
        Returns: 1 if ver_new > ver_installed
                 0 if equal
                -1 if ver_new < ver_installed"""
        return apt_pkg.version_compare(ver_new, ver_installed)
    
    def update_package_display(self):
        """Update the UI with package information"""
        info = self.package_info
        

        self.drag_drop_box.hide()
        

        self.icon_name_box.set_no_show_all(False)
        self.info_grid.set_no_show_all(False)
        self.desc_label.set_no_show_all(False)
        self.desc_scroll.set_no_show_all(False)
        
        self.icon_name_box.show_all()
        self.info_grid.show_all()
        self.desc_label.show()
        self.desc_scroll.show_all()
        

        package_name = info.get('Package', self._('no_package'))
        self.package_name_label.set_markup(
            f"<span size='x-large' weight='bold' color='#4CAF50'>{package_name}</span>"
        )
        

        for child in self.info_grid.get_children():
            self.info_grid.remove(child)
        

        row = 0
        fields = [
            ('Version', 'version'),
            ('Architecture', 'architecture'),
            ('Maintainer', 'maintainer'),
            ('Installed-Size', 'size'),
            ('Section', 'section'),
            ('Priority', 'priority'),
            ('Homepage', 'homepage'),
        ]
        
        for field, label_key in fields:
            if field in info:
                label = Gtk.Label(label=self._(label_key) + ":")
                label.set_halign(Gtk.Align.START)
                label.get_style_context().add_class('info-label')
                self.info_grid.attach(label, 0, row, 1, 1)
                
                value = Gtk.Label(label=info[field])
                value.set_halign(Gtk.Align.START)
                value.set_selectable(True)
                value.set_line_wrap(True)
                value.set_max_width_chars(50)
                value.get_style_context().add_class('info-value')
                self.info_grid.attach(value, 1, row, 1, 1)
                row += 1
        
        # Status
        status_label = Gtk.Label(label=self._('status') + ":")
        status_label.set_halign(Gtk.Align.START)
        status_label.get_style_context().add_class('info-label')
        self.info_grid.attach(status_label, 0, row, 1, 1)

        if self.version_state == 'not_installed':
            status_text = self._('not_installed')
            status_class = 'status-not-installed'
        elif self.version_state == 'update':
            status_text = self._('status_update_available').format(installed_ver=self.installed_version)
            status_class = 'status-update'
        elif self.version_state == 'same':
            status_text = self._('installed')
            status_class = 'status-installed'
        else:  # older
            status_text = self._('status_installed_newer').format(installed_ver=self.installed_version)
            status_class = 'status-installed'

        status_value = Gtk.Label(label=status_text)
        status_value.set_halign(Gtk.Align.START)
        status_value.set_line_wrap(True)
        status_value.set_max_width_chars(50)
        status_value.get_style_context().add_class(status_class)
        self.info_grid.attach(status_value, 1, row, 1, 1)
        
        # Dependencies
        if 'Depends' in info:
            row += 1
            dep_label = Gtk.Label(label=self._('depends') + ":")
            dep_label.set_halign(Gtk.Align.START)
            dep_label.set_valign(Gtk.Align.START)
            dep_label.get_style_context().add_class('info-label')
            self.info_grid.attach(dep_label, 0, row, 1, 1)
            
            dep_value = Gtk.Label(label=info['Depends'])
            dep_value.set_halign(Gtk.Align.START)
            dep_value.set_line_wrap(True)
            dep_value.set_max_width_chars(50)
            dep_value.set_selectable(True)
            dep_value.get_style_context().add_class('info-value')
            self.info_grid.attach(dep_value, 1, row, 1, 1)
        

        description = info.get('Description', '')
        buffer = self.description_view.get_buffer()
        buffer.set_text(description)
        

        self.info_grid.show_all()
        

        # Buttons based on version_state
        if self.version_state == 'not_installed':
            self.install_button.set_label(self._('install'))
            self.install_button.show()
            self.install_button.set_sensitive(True)
            self.reinstall_button.hide()
            self.remove_button.hide()
        elif self.version_state == 'update':
            self.install_button.set_label(self._('update'))
            self.install_button.show()
            self.install_button.set_sensitive(True)
            self.reinstall_button.hide()
            self.remove_button.show()
            self.remove_button.set_sensitive(True)
        elif self.version_state == 'same':
            self.install_button.hide()
            self.reinstall_button.show()
            self.reinstall_button.set_sensitive(True)
            self.remove_button.show()
            self.remove_button.set_sensitive(True)
        else:  # older
            self.install_button.hide()
            self.reinstall_button.show()
            self.reinstall_button.set_sensitive(True)
            self.remove_button.show()
            self.remove_button.set_sensitive(True)
    
    def on_install(self, widget):
        """Install or reinstall the package (always forced)"""
        if not self.package_file:
            self.show_error_dialog(self._('error'), self._('select_deb'))
            return
        
        self._install_package()
    
    
    def _create_progress_dialog(self, title_text):
        """Create a progress dialog with a ProgressBar and percentage label"""
        dialog = Gtk.Dialog(
            title=title_text,
            parent=self,
            flags=Gtk.DialogFlags.MODAL
        )
        dialog.set_default_size(380, 120)
        dialog.set_deletable(False)

        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_top(18)
        content.set_margin_bottom(14)
        content.set_margin_start(22)
        content.set_margin_end(22)

        self._prog_status_label = Gtk.Label(label="")
        self._prog_status_label.set_halign(Gtk.Align.START)
        self._prog_status_label.set_markup(f"<span size='small' color='#aaaaaa'>{title_text}</span>")
        content.pack_start(self._prog_status_label, False, False, 0)

        # ProgressBar
        self._prog_bar = Gtk.ProgressBar()
        self._prog_bar.set_fraction(0.0)
        self._prog_bar.set_show_text(True)  
        content.pack_start(self._prog_bar, False, False, 0)

        dialog.show_all()
        return dialog

    def _update_progress(self, fraction, status_text=None):
        """Thread-safe update of progress bar (call via GLib.idle_add)"""
        if fraction > 1.0:
            fraction = 1.0
        self._prog_bar.set_fraction(fraction)
        if status_text:
            self._prog_status_label.set_markup(f"<span size='small' color='#aaaaaa'>{status_text}</span>")

    def _install_package(self):
        """Install package (always with --force-all) using a threaded progress dialog"""

        self.install_button.set_sensitive(False)
        self.reinstall_button.set_sensitive(False)
        self.remove_button.set_sensitive(False)
        self.select_button.set_sensitive(False)

        self._prog_dialog = self._create_progress_dialog(self._('installing'))

        # Run the heavy work in a thread
        thread = threading.Thread(target=self._install_thread, daemon=True)
        thread.start()

    def _resolve_dependencies(self):
        """Use apt.debfile.DebPackage (gdebi approach) to get the list of
        packages that must be installed/removed to satisfy the .deb deps.
        Returns (install_list, remove_list, error_str).
        install_list / remove_list are lists of package name strings.
        On error, both lists are empty and error_str is set."""
        try:
            cache = apt.Cache()
            deb = apt.debfile.DebPackage(filename=self.package_file, cache=cache)
            # check() populates missing_deps and required_changes
            deb.check()
            install_pkgs, remove_pkgs, _unauthenticated = deb.required_changes
            return install_pkgs, remove_pkgs, None
        except Exception as e:
            print(f"[EssDeb] Dependency resolution error: {e}")
            return [], [], str(e)

    def _install_thread(self):
        """Worker thread: resolves deps via apt.debfile (gdebi approach),
        installs missing dependencies first, then installs the .deb with dpkg."""

        # --- Step 1: resolve dependencies ---
        GLib.idle_add(self._update_progress, 0.05, self._('fixing_deps'))
        install_pkgs, remove_pkgs, dep_error = self._resolve_dependencies()

        if dep_error:
            print(f"[EssDeb] Dependency resolution failed: {dep_error}")
            # Fall through — still try to install; dpkg may handle it
            install_pkgs = []
            remove_pkgs = []

        print(f"[EssDeb] Deps to install: {install_pkgs}")
        print(f"[EssDeb] Deps to remove:  {remove_pkgs}")

        # --- Step 2: install missing dependencies with apt-get ---
        if install_pkgs:
            GLib.idle_add(self._update_progress, 0.10, self._('progress_fixing'))
            dep_cmd = ['pkexec', 'apt-get', 'install', '-y', '--no-install-recommends'] + install_pkgs
            print(f"[EssDeb] Installing deps: {' '.join(dep_cmd)}")
            try:
                dep_proc = subprocess.Popen(
                    dep_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True
                )
                dep_fraction = 0.12
                for line in dep_proc.stdout:
                    print(f"[EssDeb] apt-get deps: {line.strip()}")
                    dep_fraction += 0.004
                    if dep_fraction > 0.38:
                        dep_fraction = 0.38
                    GLib.idle_add(self._update_progress, dep_fraction, self._('progress_fixing'))
                dep_proc.wait()
                if dep_proc.returncode != 0:
                    print("[EssDeb] Warning: apt-get dep install returned non-zero, continuing anyway")
            except Exception as e:
                print(f"[EssDeb] Exception installing deps: {e}")
                GLib.idle_add(self._install_done, -1, str(e))
                return

        # --- Step 3: install the .deb package with dpkg ---
        GLib.idle_add(self._update_progress, 0.40, self._('progress_unpacking'))
        cmd = ['pkexec', 'dpkg', '-i', self.package_file]
        print(f"[EssDeb] Running: {' '.join(cmd)}")

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            phase_fraction = 0.40
            phase_target = 0.85
            phase_label = self._('progress_unpacking')

            for line in proc.stdout:
                line = line.strip()
                print(f"[EssDeb] dpkg: {line}")
                lower = line.lower()

                if 'setting up' in lower:
                    phase_fraction = 0.70
                    phase_target = 0.90
                    phase_label = self._('progress_setting_up')
                elif 'processing triggers' in lower or 'running post-installation' in lower:
                    phase_fraction = 0.88
                    phase_target = 0.95
                    phase_label = self._('progress_setting_up')
                else:
                    step = (phase_target - phase_fraction) * 0.15
                    if step > 0.001:
                        phase_fraction += step

                GLib.idle_add(self._update_progress, phase_fraction, phase_label)

            proc.wait()
            returncode = proc.returncode

        except Exception as e:
            print(f"[EssDeb] Exception during install: {e}")
            GLib.idle_add(self._install_done, -1, str(e))
            return

        # --- Step 4: if dpkg still fails, run apt-get install -f as last resort ---
        if returncode != 0:
            GLib.idle_add(self._update_progress, 0.88, self._('progress_fixing'))
            print("[EssDeb] dpkg returned non-zero, running apt-get install -f...")
            try:
                fix_proc = subprocess.Popen(
                    ['pkexec', 'apt-get', 'install', '-f', '-y'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True
                )
                fix_fraction = 0.90
                for line in fix_proc.stdout:
                    print(f"[EssDeb] apt-get fix: {line.strip()}")
                    fix_fraction += 0.002
                    if fix_fraction > 0.95:
                        fix_fraction = 0.95
                    GLib.idle_add(self._update_progress, fix_fraction, self._('progress_fixing'))
                fix_proc.wait()
                returncode = fix_proc.returncode
            except Exception as e:
                GLib.idle_add(self._install_done, -1, str(e))
                return

        if returncode == 0:
            GLib.idle_add(self._update_progress, 0.97, self._('refreshing_menu'))
            self.run_fixmenus()
            GLib.idle_add(self._update_progress, 1.0, self._('progress_complete'))
            GLib.idle_add(self._install_done, 0, None)
        else:
            GLib.idle_add(self._install_done, -1, "Installation failed. Check that all dependencies are available in your repositories.")

    def _install_done(self, returncode, error_msg):
        """Called on the GTK main thread after install finishes"""
        self._prog_dialog.destroy()

        if returncode == 0:
            package_name = self.package_info.get('Package', '')
            deb_version = self.package_info.get('Version', '')
            self.installed_version = self.get_installed_version(package_name)

            if self.installed_version is None:
                self.is_installed = False
                self.version_state = 'not_installed'
            else:
                self.is_installed = True
                cmp = self.compare_versions(deb_version, self.installed_version)
                if cmp > 0:
                    self.version_state = 'update'
                elif cmp == 0:
                    self.version_state = 'same'
                else:
                    self.version_state = 'older'

            self.update_package_display()
        else:
            self.show_error_dialog(self._('error'), error_msg or "Unknown error")

        self.install_button.set_sensitive(True)
        self.reinstall_button.set_sensitive(True)
        self.remove_button.set_sensitive(True)
        self.select_button.set_sensitive(True)
        return False
    
    def on_remove(self, widget):
        """Remove the package"""
        package_name = self.package_info.get('Package', '')
        if not package_name:
            return

        confirm_dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=self._('confirm')
        )
        confirm_dialog.format_secondary_text(self._('confirm_remove'))
        response = confirm_dialog.run()
        confirm_dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        self.remove_button.set_sensitive(False)
        self.reinstall_button.set_sensitive(False)
        self.install_button.set_sensitive(False)
        self.select_button.set_sensitive(False)

        self._prog_dialog = self._create_progress_dialog(self._('removing'))

        thread = threading.Thread(target=self._remove_thread, args=(package_name,), daemon=True)
        thread.start()

    def _remove_thread(self, package_name):
        """Worker thread: runs dpkg -r"""
        cmd = ['pkexec', 'dpkg', '-r', package_name]
        print(f"[EssDeb] Removing package: {package_name}")

        try:
            GLib.idle_add(self._update_progress, 0.10, self._('progress_removing'))

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            fraction = 0.15
            for line in proc.stdout:
                print(f"[EssDeb] dpkg -r: {line.strip()}")
                fraction += 0.08
                if fraction > 0.75:
                    fraction = 0.75
                GLib.idle_add(self._update_progress, fraction, self._('progress_removing'))

            proc.wait()

            if proc.returncode == 0:
                GLib.idle_add(self._update_progress, 0.85, self._('refreshing_menu'))
                self.run_fixmenus()
                GLib.idle_add(self._update_progress, 1.0, self._('progress_complete'))
                GLib.idle_add(self._remove_done, 0, None)
            else:
                GLib.idle_add(self._remove_done, -1, "dpkg -r failed")

        except Exception as e:
            print(f"[EssDeb] Exception during remove: {e}")
            GLib.idle_add(self._remove_done, -1, str(e))

    def _remove_done(self, returncode, error_msg):
        """Called on GTK main thread after remove finishes"""
        self._prog_dialog.destroy()

        if returncode == 0:
            self.is_installed = False
            self.installed_version = None
            self.version_state = 'not_installed'
            self.update_package_display()
        else:
            self.show_error_dialog(self._('error'), error_msg or "Unknown error")

        self.remove_button.set_sensitive(True)
        self.reinstall_button.set_sensitive(True)
        self.install_button.set_sensitive(True)
        self.select_button.set_sensitive(True)
        return False

    def show_error_dialog(self, title, message):
        """Show error dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    



def main():
    app = EssDeb()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    

    if len(sys.argv) > 1 and sys.argv[1].endswith('.deb'):
        app.package_file = sys.argv[1]
        app.load_package_info()
    
    Gtk.main()


if __name__ == "__main__":
    main()
