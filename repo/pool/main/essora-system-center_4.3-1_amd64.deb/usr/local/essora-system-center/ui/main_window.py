#!/usr/bin/env python3
# ==================== ESSORA SYSTEM CENTER ====================
# DESARROLLADO POR josejp2424 y contribuidores
# Description: Sistema de información y gestión para Essora Linux
# Version: 4.0
# License: GPL-3.0
# ====================================================================
# GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Copyright (C) 2025 josejp2424
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Author: josejp2424
# Project: Essora Community
# ====================================================================

"""Main window for Essora System Center.

Objetivos (según tu pedido):
- Ventana con mejor estética (estilo Hardinfo: sidebar + páginas)
- Integrar "Essora Top" y "About" como páginas internas (sin abrir ventanas aparte)
- Arreglar errores de on_activate() faltante
- Mantener icono de marco: /usr/local/essora-system-center/icons/essora-center.png
- GUI base en inglés (translator default 'en'), con traducciones externas en /lang
"""

import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango

import logging
import os
from pathlib import Path
from typing import Dict, Optional, Any, List, Tuple

logger = logging.getLogger('EssoraSystemCenter')

from utils.translations import translator, SUPPORTED_LANGUAGES
from ui.headerbar import EssoraHeaderBar


try:
    from modules.summary import SummaryModule
except Exception as e:
    SummaryModule = None
    logger.warning(f"SummaryModule not available: {e}")

try:
    from modules.essora_top import EssoraTopModule
except Exception as e:
    EssoraTopModule = None
    logger.warning(f"EssoraTopModule not available: {e}")


try:
    from modules.system_info import SystemInfoModule
    from modules.hardware_info import HardwareInfoModule
    from modules.software_info import SoftwareInfoModule
    from modules.network_info import NetworkInfoModule
    from modules.disk_info import DiskInfoModule
    from modules.resources_monitor import ResourcesMonitorModule
    from modules.benchmarks import BenchmarksModule
    from modules.tools import ToolsModule
except Exception as e:
    logger.warning(f"Some built-in modules could not be imported: {e}")
    SystemInfoModule = HardwareInfoModule = SoftwareInfoModule = NetworkInfoModule = None
    DiskInfoModule = ResourcesMonitorModule = BenchmarksModule = ToolsModule = None


class NavRow(Gtk.ListBoxRow):
    def __init__(self, key: str, title: str, icon_name: str):
        super().__init__()
        self.key = key
        self._title = title

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_margin_start(12)
        box.set_margin_end(12)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
        img.get_style_context().add_class('nav-icon')
        box.pack_start(img, False, False, 0)

        lab = Gtk.Label(label=title)
        lab.set_xalign(0)
        lab.set_ellipsize(Pango.EllipsizeMode.END)
        lab.get_style_context().add_class('nav-label')
        box.pack_start(lab, True, True, 0)

        self.add(box)


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, application):
        super().__init__(application=application, title=translator.get('Essora System Center'))

        self.set_default_size(1180, 760)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(0)


        self._apply_window_icon()

        self.modules: Dict[str, Any] = {}
        self.module_titles: Dict[str, str] = {}
        self._active_key: Optional[str] = None

        self.update_interval_ms = 1500

        self.apply_css()
        self.setup_ui()
        self.load_modules()


        GLib.idle_add(self._select_first)


        GLib.timeout_add(self.update_interval_ms, self._auto_refresh_tick)

    def _apply_window_icon(self):
        icon_paths = [
            Path('/usr/local/essora-system-center/icons/essora-center.png'),
            Path(__file__).resolve().parent.parent / 'icons' / 'essora-center.png',
            Path('/usr/share/pixmaps/essora-system-center.png'),
        ]
        for p in icon_paths:
            try:
                p = Path(p)
                if p.exists():
                    self.set_icon_from_file(str(p))
                    return
            except Exception:
                continue

    def apply_css(self):
        css_provider = Gtk.CssProvider()

        css = """
        * { font-family: Ubuntu, Cantarell, DejaVu Sans, sans-serif; }

        window { background-color: #2d2d2d; }

        /* HeaderBar */
        .essora-headerbar {
            background: linear-gradient(to right, #3a4049, #2c3e50);
            border-bottom: 1px solid #1a1a1a;
        }
        .header-title { color: #ffffff; font-weight: bold; font-size: 14px; }
        .header-subtitle { color: #b0b0b0; font-size: 11px; }

        /* Layout */
        .top-stats {
            background-color: #3a4049;
            border-bottom: 1px solid #262b31;
            padding: 8px 10px;
        }

        .sidebar {
            background-color: #24272c;
            border-right: 1px solid #1b1e22;
        }

        .sidebar-header {
            color: #b0b0b0;
            font-weight: bold;
            font-size: 11px;
            padding: 10px 12px;
        }

        .nav-label { color: #e0e0e0; font-size: 13px; }
        .nav-icon { opacity: 0.95; }

        list {
            background-color: transparent;
        }

        list row {
            background-color: transparent;
        }

        list row:selected {
            background-color: rgba(52, 152, 219, 0.22);
            border-left: 3px solid #3498db;
        }

        list row:selected .nav-label { color: #ffffff; font-weight: bold; }

        .content-stack {
            background-color: #2d2d2d;
        }

        /* Frames estilo About */
        .info-frame {
            background-color: #3a3a3a;
            border-radius: 6px;
            border: 1px solid #4a4a4a;
            padding: 0;
            margin: 8px;
        }

        .frame-header {
            background-color: transparent;
            color: #4A9EFF;
            font-weight: bold;
            font-size: 14px;
            padding: 8px 12px;
        }

        separator {
            background-color: #4a4a4a;
            min-height: 1px;
        }

        .kv-key { color: #e0e0e0; font-size: 13px; }
        .kv-val { color: #b0b0b0; font-size: 13px; }

        .essora-button {
            background-color: #3498db;
            color: #ffffff;
            border-radius: 5px;
            padding: 6px 10px;
        }
        .essora-button:hover { background-color: #2980b9; }

        /* Essora Top embedded */
        .stats-bar {
            background: linear-gradient(to bottom, #2c3e50, #34495e);
            color: white;
            padding: 8px;
            border-bottom: 2px solid #3498db;
        }
        .stats-label { font-weight: bold; color: white; font-size: 11px; }
        .process-row { padding: 2px; }
        """

        css_provider.load_from_data(css.encode('utf-8'))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def setup_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(root)


        self.headerbar = EssoraHeaderBar(self)
        self.set_titlebar(self.headerbar)


        self.top_stats = self._create_top_stats_bar()
        self.top_stats.get_style_context().add_class('top-stats')
        root.pack_start(self.top_stats, False, False, 0)


        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(paned, True, True, 0)


        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        left.get_style_context().add_class('sidebar')
        left.set_size_request(250, -1)

        lab = Gtk.Label(label=translator.get('Categories'))
        lab.set_xalign(0)
        lab.get_style_context().add_class('sidebar-header')
        left.pack_start(lab, False, False, 0)

        self.nav = Gtk.ListBox()
        self.nav.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.nav.set_activate_on_single_click(True)
        self.nav.connect('row-selected', self.on_nav_selected)

        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.set_overlay_scrolling(False)
        sc.add(self.nav)
        left.pack_start(sc, True, True, 0)

        paned.add1(left)


        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(160)
        self.stack.get_style_context().add_class('content-stack')

        paned.add2(self.stack)

        self.show_all()

    def _select_first(self):
        try:
            row = self.nav.get_row_at_index(0)
            if row:
                self.nav.select_row(row)
        except Exception:
            pass
        return False


    def _create_top_stats_bar(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)

        self._cpu_bar = Gtk.ProgressBar()
        self._cpu_bar.set_show_text(True)
        self._cpu_bar.set_text(translator.get('CPU'))
        self._cpu_bar.set_size_request(160, -1)

        self._mem_bar = Gtk.ProgressBar()
        self._mem_bar.set_show_text(True)
        self._mem_bar.set_text(translator.get('Memory'))
        self._mem_bar.set_size_request(160, -1)

        self._tasks_label = Gtk.Label(label=translator.get('Tasks') + ': -')
        self._tasks_label.get_style_context().add_class('stats-label')

        self._boot_label = Gtk.Label(label=translator.get('Boot') + ': -')
        self._boot_label.get_style_context().add_class('stats-label')

        self._clock_label = Gtk.Label(label='')
        self._clock_label.get_style_context().add_class('stats-label')
        self._clock_label.set_halign(Gtk.Align.END)

        box.pack_start(self._cpu_bar, False, False, 0)
        box.pack_start(self._mem_bar, False, False, 0)
        box.pack_start(self._tasks_label, False, False, 0)
        box.pack_start(self._boot_label, False, False, 0)
        box.pack_end(self._clock_label, True, True, 0)

        self._update_top_stats()
        return box

    def _update_top_stats(self):
        
        try:

            if not hasattr(self, '_prev_cpu'): 
                self._prev_cpu = None

            with open('/proc/stat', 'r', encoding='utf-8', errors='ignore') as f:
                line = f.readline()
            parts = line.split()
            times = [int(x) for x in parts[1:]]

            if self._prev_cpu is None:
                self._prev_cpu = times
                cpu_percent = 0.0
            else:
                prev = self._prev_cpu
                deltas = [c - p for c, p in zip(times, prev)]
                total = sum(deltas)
                idle = deltas[3] if len(deltas) > 3 else 0
                self._prev_cpu = times
                cpu_percent = 0.0 if total <= 0 else 100.0 * (1.0 - (idle / total))

            self._cpu_bar.set_fraction(max(0.0, min(1.0, cpu_percent / 100.0)))
            self._cpu_bar.set_text(f"{translator.get('CPU')}: {cpu_percent:.1f}%")
        except Exception:
            pass

        try:
            mem_total = mem_avail = None
            with open('/proc/meminfo', 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        mem_total = int(line.split()[1]) * 1024
                    elif line.startswith('MemAvailable:'):
                        mem_avail = int(line.split()[1]) * 1024
            if mem_total and mem_avail is not None:
                used = mem_total - mem_avail
                pct = 0.0 if mem_total == 0 else (used / mem_total) * 100.0
                self._mem_bar.set_fraction(max(0.0, min(1.0, pct / 100.0)))
                self._mem_bar.set_text(f"{translator.get('Memory')}: {pct:.1f}%")
        except Exception:
            pass

        try:
           
            tasks = 0
            for name in os.listdir('/proc'):
                if name.isdigit():
                    tasks += 1
            self._tasks_label.set_text(f"{translator.get('Tasks')}: {tasks}")
        except Exception:
            pass

        try:
            up = 0.0
            with open('/proc/uptime', 'r', encoding='utf-8', errors='ignore') as f:
                up = float(f.readline().split()[0])

            mins = int(up // 60)
            hrs = mins // 60
            mins = mins % 60
            if hrs:
                boot_txt = f"{hrs}h {mins}m"
            else:
                boot_txt = f"{mins}m"
            self._boot_label.set_text(f"{translator.get('Uptime')}: {boot_txt}")
        except Exception:
            pass

        try:
            import datetime
            self._clock_label.set_text(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        except Exception:
            pass


    def _add_page(self, key: str, title: str, icon_name: str, module_obj: Any):

        row = NavRow(key, title, icon_name)
        self.nav.add(row)


        content = None
        try:
            if hasattr(module_obj, 'get_content'):
                content = module_obj.get_content()
        except Exception as e:
            logger.error(f"Error building content for {key}: {e}")
            content = None

        if content is None:
            content = Gtk.Label(label=translator.get('Not available'))
            content.set_margin_top(20)

        
        if isinstance(content, Gtk.ScrolledWindow):
            page = content
        else:
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            sw.set_overlay_scrolling(False)
            sw.add(content)
            page = sw

        self.stack.add_named(page, key)
        self.modules[key] = module_obj
        self.module_titles[key] = title

    def load_modules(self):

        configs: List[Tuple[str, str, str, Any]] = []

        if SummaryModule is not None:
            configs.append(('summary', translator.get('Summary'), 'dialog-information-symbolic', SummaryModule(self)))

        if SystemInfoModule is not None:
            configs.append(('system', translator.get('System'), 'computer-symbolic', SystemInfoModule(self)))

        if HardwareInfoModule is not None:
            configs.append(('hardware', translator.get('Hardware'), 'drive-harddisk-symbolic', HardwareInfoModule(self)))

        if SoftwareInfoModule is not None:
            configs.append(('software', translator.get('Software'), 'application-x-executable-symbolic', SoftwareInfoModule(self)))

        if NetworkInfoModule is not None:
            configs.append(('network', translator.get('Network'), 'network-workgroup-symbolic', NetworkInfoModule(self)))

        if DiskInfoModule is not None:
            configs.append(('disks', translator.get('Disks'), 'drive-harddisk-symbolic', DiskInfoModule(self)))

        if ResourcesMonitorModule is not None:
            configs.append(('resources', translator.get('Resources'), 'utilities-system-monitor-symbolic', ResourcesMonitorModule(self)))

        if BenchmarksModule is not None:
            configs.append(('benchmarks', translator.get('Benchmarks'), 'speedometer-symbolic', BenchmarksModule(self)))

        if EssoraTopModule is not None:
            configs.append(('processes', translator.get('Processes'), 'system-run-symbolic', EssoraTopModule(self)))

        if ToolsModule is not None:
            configs.append(('tools', translator.get('Tools'), 'preferences-system-symbolic', ToolsModule(self)))

        if not configs:

            placeholder = Gtk.Label(label=translator.get('No modules available.'))
            placeholder.set_margin_top(30)
            self.stack.add_named(placeholder, 'empty')
            self.nav.add(NavRow('empty', translator.get('Empty'), 'dialog-warning-symbolic'))
            self.show_all()
            return

        for key, title, icon, module_obj in configs:
            self._add_page(key, title, icon, module_obj)

        self.show_all()

    def on_nav_selected(self, _listbox: Gtk.ListBox, row: Optional[Gtk.ListBoxRow]):
        if row is None:
            return

        key = getattr(row, 'key', None)
        if not key:
            return


        if self._active_key and self._active_key in self.modules:
            prev = self.modules[self._active_key]
            if hasattr(prev, 'on_deactivate'):
                try:
                    prev.on_deactivate()
                except Exception as e:
                    logger.debug(f"on_deactivate failed for {self._active_key}: {e}")

       
        self._active_key = key
        self.stack.set_visible_child_name(key)

       
        title = self.module_titles.get(key, '')
        try:
            self.headerbar.set_subtitle(title)
        except Exception:
            pass

        mod = self.modules.get(key)
        if mod and hasattr(mod, 'on_activate'):
            try:
                mod.on_activate()
            except Exception as e:
                logger.debug(f"on_activate failed for {key}: {e}")

        
        self._update_active_module()

    def _update_active_module(self):
        if not self._active_key:
            return
        mod = self.modules.get(self._active_key)
        if not mod:
            return

        
        for meth in ('update', 'reload'):
            if hasattr(mod, meth):
                try:
                    getattr(mod, meth)()
                except Exception as e:
                    logger.debug(f"{meth} failed for {self._active_key}: {e}")
                break

    def _auto_refresh_tick(self):

        self._update_top_stats()


        self._update_active_module()
        return True

    
    def reload_all_info(self):
        for k, mod in self.modules.items():
            for meth in ('reload', 'update'):
                if hasattr(mod, meth):
                    try:
                        getattr(mod, meth)()
                    except Exception:
                        pass
                    break

    def show_about_dialog(self):
        dlg = Gtk.AboutDialog(transient_for=self, modal=True)
        dlg.set_program_name('Essora System Center')
        dlg.set_version('4.3')
        dlg.set_comments(translator.get('System information and management tool for Essora Linux.'))
        dlg.set_license_type(Gtk.License.GPL_3_0)
        dlg.set_website('https://sourceforge.net/projects/essora-linux/')
        dlg.set_authors(['josejp2424'])
        try:
            icon_path = Path('/usr/local/essora-system-center/icons/essora-center.png')
            if icon_path.exists():
                dlg.set_logo_icon_name(None)
                dlg.set_logo(Gtk.Image.new_from_file(str(icon_path)).get_pixbuf())
        except Exception:
            pass
        dlg.run()
        dlg.destroy()

    def show_preferences_dialog(self):
        """Preferences dialog (currently: language selector)."""
        dlg = Gtk.Dialog(title=translator.get('Preferences'), transient_for=self, modal=True)
        dlg.add_button(translator.get('Close'), Gtk.ResponseType.CLOSE)

        box = dlg.get_content_area()
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(12)
        box.set_margin_end(12)
        box.set_spacing(10)

        lab = Gtk.Label(label=translator.get('Language'))
        lab.set_xalign(0)
        box.pack_start(lab, False, False, 0)

        combo = Gtk.ComboBoxText()
        combo.append('auto', translator.get('Auto (system)'))
        for code, name in SUPPORTED_LANGUAGES.items():
            combo.append(code, name)

       
        try:
            current = getattr(translator, 'current_lang', 'en')
            model = combo.get_model()
            if model:
                for i, row in enumerate(model):
                    if row[0] == current:
                        combo.set_active(i)
                        break
        except Exception:
            pass

        info = Gtk.Label(label=translator.get('Language changed. Restart to apply.'))
        info.set_xalign(0)
        info.set_no_show_all(True)
        info.hide()

        def _on_changed(_c):
            try:
                code = combo.get_active_id() or 'en'
                translator.save_language(code)
                info.show()
            except Exception:
                pass

        combo.connect('changed', _on_changed)
        box.pack_start(combo, False, False, 0)
        box.pack_start(info, False, False, 0)

        dlg.show_all()
        dlg.run()
        dlg.destroy()
