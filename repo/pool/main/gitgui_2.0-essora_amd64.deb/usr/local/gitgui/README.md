GitGUI (GTK3) - Full (basic Git client)
====================================

This build extends the original "safe setup" idea (identity/SSH/clone) with a new tab:
  - Repository: status, stage/unstage, discard, diff, commit, pull, push, log, remotes

Run:
  python3 gitgui.py

Icon:
  /usr/share/pixmaps/gitgui.svg

Notes:
- Commit will use the staged files (normal git commit).
- Push/Pull depends on your remote auth:
  * SSH: make sure your key is added to GitHub/GitLab.
  * HTTPS: you may need credential helper or PAT.

If SVG doesn't render:
  sudo apt-get install gir1.2-rsvg-2.0 librsvg2-common
