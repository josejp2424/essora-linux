#!/bin/bash
# ============================================================================
# Script: brightness-control.sh
# Descripción: Control gráfico del brillo de pantalla con yad y brightnessctl.
# 
# Funciones principales:
# - Muestra una ventana gráfica (yad) para ajustar el brillo mediante un deslizador.
# - Aplica el brillo seleccionado usando brightnessctl.
# - Guarda el brillo final en un script que se ejecuta automáticamente al iniciar el sistema.
# - Copia un archivo .desktop al autostart del sistema para aplicar el brillo al arranque.
# - Detecta automáticamente el idioma del sistema y muestra la interfaz traducida.
#
# Requisitos:
# - brightnessctl
# - yad
# - Un ícono SVG en: /usr/local/KLA-Shutdown/shutdowm/suspend.svg
# - Un archivo .desktop en: /usr/local/brightness-control/brightness-control.desktop
#
# Compatible con los siguientes idiomas:
# ar, ca, es, fr, it, ja, ko, pt, ru, vi, hu, zh_CN
#
# Autor: josejp2424
# Fecha: 28062025
# version 01
# ============================================================================


ICON_PATH="/usr/local/KLA-Shutdown/shutdowm/suspend.svg"
DESKTOP_SRC="/usr/local/brightness-control/brightness-control.desktop"
DESKTOP_DST="/etc/xdg/autostart/brightness-control.desktop"
SCRIPT_PATH="/usr/local/bin/brightness-control-start"

# Detectar idioma del sistema
LANG_CODE=$(echo "$LANG" | cut -d '_' -f1 | tr '[:upper:]' '[:lower:]')
LANG_CODE_FULL=$(echo "$LANG" | tr '[:upper:]' '[:lower:]')

set_language_strings() {
    case "$LANG_CODE_FULL" in
        zh_cn)
            TITLE="亮度控制"
            TEXT_SLIDER="调整亮度："
            TEXT_ADDED="✔️ 启动时已添加亮度设置。"
            BTN_OK="确定"
            ;;
        *)
            case "$1" in
                ar)
                    TITLE="التحكم في السطوع"
                    TEXT_SLIDER="ضبط السطوع:"
                    TEXT_ADDED="✔️ تمت إضافة إعداد السطوع إلى بدء التشغيل."
                    BTN_OK="موافق"
                    ;;
                ca)
                    TITLE="Control de brillantor"
                    TEXT_SLIDER="Ajustar la brillantor:"
                    TEXT_ADDED="✔️ S'ha afegit el paràmetre de brillantor a l'inici del sistema."
                    BTN_OK="Acceptar"
                    ;;
                es)
                    TITLE="Control de Brillo"
                    TEXT_SLIDER="Ajustar brillo:"
                    TEXT_ADDED="✔️ Se agregó el ajuste de brillo al inicio del sistema."
                    BTN_OK="Aceptar"
                    ;;
                fr)
                    TITLE="Contrôle de la luminosité"
                    TEXT_SLIDER="Ajuster la luminosité :"
                    TEXT_ADDED="✔️ Le réglage de la luminosité a été ajouté au démarrage du système."
                    BTN_OK="Accepter"
                    ;;
                it)
                    TITLE="Controllo della luminosità"
                    TEXT_SLIDER="Regola la luminosità:"
                    TEXT_ADDED="✔️ La regolazione della luminosità è stata aggiunta all'avvio del sistema."
                    BTN_OK="Accetta"
                    ;;
                ja)
                    TITLE="明るさの調整"
                    TEXT_SLIDER="明るさを調整:"
                    TEXT_ADDED="✔️ 起動時に明るさの設定が追加されました。"
                    BTN_OK="了解"
                    ;;
                ko)
                    TITLE="밝기 조절"
                    TEXT_SLIDER="밝기 조절:"
                    TEXT_ADDED="✔️ 시스템 시작 시 밝기 설정이 추가되었습니다."
                    BTN_OK="확인"
                    ;;
                pt)
                    TITLE="Controle de Brilho"
                    TEXT_SLIDER="Ajustar o brilho:"
                    TEXT_ADDED="✔️ O ajuste de brilho foi adicionado à inicialização do sistema."
                    BTN_OK="Aceitar"
                    ;;
                ru)
                    TITLE="Настройка яркости"
                    TEXT_SLIDER="Настроить яркость:"
                    TEXT_ADDED="✔️ Настройка яркости добавлена в автозапуск."
                    BTN_OK="ОК"
                    ;;
                vi)
                    TITLE="Điều chỉnh độ sáng"
                    TEXT_SLIDER="Điều chỉnh độ sáng:"
                    TEXT_ADDED="✔️ Đã thêm thiết lập độ sáng vào khởi động hệ thống."
                    BTN_OK="Đồng ý"
                    ;;
                hu)
                    TITLE="Fényerő szabályozása"
                    TEXT_SLIDER="Fényerő beállítása:"
                    TEXT_ADDED="✔️ A fényerő beállítása hozzá lett adva a rendszerindításhoz."
                    BTN_OK="Rendben"
                    ;;
                *)
                    TITLE="Brightness Control"
                    TEXT_SLIDER="Adjust brightness:"
                    TEXT_ADDED="✔️ Brightness setting added to system startup."
                    BTN_OK="OK"
                    ;;
            esac
        ;;
    esac
}

set_language_strings "$LANG_CODE"

mkdir -p "$(dirname "$SCRIPT_PATH")"
mkdir -p "$(dirname "$DESKTOP_DST")"

# Obtener valores actuales de brillo
current_brightness=$(brightnessctl get)
max_brightness=$(brightnessctl max)
current_percentage=$(( (current_brightness * 100) / max_brightness ))

update_brightness() {
    brightnessctl set "${1}%" > /dev/null
}

TMP_VAL=$(mktemp)

# gui principal
yad --center --window-icon="$ICON_PATH" --image="$ICON_PATH" --scale \
    --title "$TITLE" \
    --text "$TEXT_SLIDER" \
    --min-value 1 \
    --max-value 100 \
    --value "$current_percentage" \
    --step 1 \
    --print-partial \
    --no-buttons \
    --width 280 \
    --height 280 \
    --vertical \
    --mouse \
    | tee "$TMP_VAL" | while read -r new_percentage; do
        update_brightness "$new_percentage"
    done

last_value=$(tail -n 1 "$TMP_VAL")
rm -f "$TMP_VAL"

# Crea el script de inicio
cat <<EOF > "$SCRIPT_PATH"
#!/bin/bash
brightnessctl set ${last_value}%
EOF

chmod +x "$SCRIPT_PATH"

cp -f "$DESKTOP_SRC" "$DESKTOP_DST"

# gui del mensaje final
yad --center --window-icon="$ICON_PATH" --image="$ICON_PATH" \
    --title "$TITLE" \
    --text "$TEXT_ADDED" \
    --button="$BTN_OK":0 \
    --width=280 \
    --height=100
