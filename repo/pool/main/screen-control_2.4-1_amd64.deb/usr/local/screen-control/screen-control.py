#!/usr/bin/env python3
# autor: josejp2424
# descripción: Herramienta gráfica para configurar el comportamiento de apagado de pantalla (DPMS)
# licencia: MIT
# versión: 1.0
# compatible con: Debian, Ubuntu, Essora, etc.
# sitio web: https://sourceforge.net/projects/essora/
# dependencias: python3, python3-pil, xset, notify-send, tkinter
import os
import subprocess
import locale
import configparser
import shutil
from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

# Configuración de rutas
CONFIG_DIR = "/usr/local/screen-control"
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.conf")
ICON_FILE = os.path.join(CONFIG_DIR, "screen-control.png")
DESKTOP_FILE_SOURCE = os.path.join(CONFIG_DIR, "screen-control.desktop")
AUTOSTART_FILE = "/etc/xdg/autostart/screen-control.desktop"
os.makedirs(CONFIG_DIR, exist_ok=True)

# Detectar idioma del sistema
lang_code = locale.getlocale()[0]
if lang_code:
    lang_code = lang_code.split('_')[0].lower()

# Definir textos multiidioma
LANGUAGE_STRINGS = {
    'es': {
        'title': "Control de Pantalla",
        'header': "Estado Actual: %s",
        'text': "Configura el comportamiento de la pantalla:",
        'keep_on': "Mantener pantalla siempre encendida",
        'timeout': "Tiempo de inactividad (minutos):",
        'msg_on': "✅ Pantalla siempre encendida\nDPMS desactivado.",
        'msg_off': "⏱ Apagado tras %d minutos",
        'btn_apply': "Aplicar",
        'btn_cancel': "Cancelar",
        'status_on': "ACTIVADO - Pantalla nunca se apagará",
        'status_off': "DESACTIVADO - Se apagará en %d min",
        'activate_btn': "Activar ahora",
        'deactivate_btn': "Desactivar ahora"
    },
    'fr': {
        'title': "Contrôle d'écran",
        'header': "État Actuel: %s",
        'text': "Configurez le comportement de l'écran:",
        'keep_on': "Garder l'écran toujours allumé",
        'timeout': "Temps d'inactivité (minutes):",
        'msg_on': "✅ Écran toujours allumé\nDPMS désactivé.",
        'msg_off': "⏱ Éteint après %d minutes",
        'btn_apply': "Appliquer",
        'btn_cancel': "Annuler",
        'status_on': "ACTIVÉ - L'écran ne s'éteindra jamais",
        'status_off': "DÉSACTIVÉ - S'éteindra après %d min",
        'activate_btn': "Activer maintenant",
        'deactivate_btn': "Désactiver maintenant"
    },
    'de': {
        'title': "Bildschirmsteuerung",
        'header': "Aktueller Status: %s",
        'text': "Konfigurieren Sie das Bildschirmverhalten:",
        'keep_on': "Bildschirm immer eingeschaltet lassen",
        'timeout': "Inaktivitätszeit (Minuten):",
        'msg_on': "✅ Bildschirm immer an\nDPMS deaktiviert.",
        'msg_off': "⏱ Aus nach %d Minuten",
        'btn_apply': "Übernehmen",
        'btn_cancel': "Abbrechen",
        'status_on': "AKTIVIERT - Bildschirm bleibt immer an",
        'status_off': "DEAKTIVIERT - Schaltet nach %d min ab",
        'activate_btn': "Jetzt aktivieren",
        'deactivate_btn': "Jetzt deaktivieren"
    },
    'it': {
        'title': "Controllo Schermo",
        'header': "Stato Attuale: %s",
        'text': "Configura il comportamento dello schermo:",
        'keep_on': "Mantenere sempre acceso lo schermo",
        'timeout': "Tempo di inattività (minuti):",
        'msg_on': "✅ Schermo sempre acceso\nDPMS disattivato.",
        'msg_off': "⏱ Spento dopo %d minuti",
        'btn_apply': "Applica",
        'btn_cancel': "Annulla",
        'status_on': "ATTIVATO - Schermo sempre acceso",
        'status_off': "DISATTIVATO - Si spegne dopo %d min",
        'activate_btn': "Attiva ora",
        'deactivate_btn': "Disattiva ora"
    },
    'pt': {
        'title': "Controle de Tela",
        'header': "Estado Atual: %s",
        'text': "Configure o comportamento da tela:",
        'keep_on': "Manter tela sempre ligada",
        'timeout': "Tempo de inatividade (minutos):",
        'msg_on': "✅ Tela sempre ligada\nDPMS desativado.",
        'msg_off': "⏱ Desliga após %d minutos",
        'btn_apply': "Aplicar",
        'btn_cancel': "Cancelar",
        'status_on': "ATIVADO - Tela nunca desliga",
        'status_off': "DESATIVADO - Desliga em %d min",
        'activate_btn': "Ativar agora",
        'deactivate_btn': "Desativar agora"
    },
    'ru': {
        'title': "Управление экраном",
        'header': "Текущий статус: %s",
        'text': "Настройте поведение экрана:",
        'keep_on': "Держать экран всегда включённым",
        'timeout': "Время бездействия (минуты):",
        'msg_on': "✅ Экран всегда включён\nDPMS отключён.",
        'msg_off': "⏱ Выключится через %d минут",
        'btn_apply': "Применить",
        'btn_cancel': "Отмена",
        'status_on': "ВКЛЮЧЕНО - Экран не выключается",
        'status_off': "ОТКЛЮЧЕНО - Выключится через %d мин",
        'activate_btn': "Включить сейчас",
        'deactivate_btn': "Отключить сейчас"
    },
    'ar': {
        'title': "التحكم في الشاشة",
        'header': "الحالة الحالية: %s",
        'text': "قم بتكوين سلوك الشاشة:",
        'keep_on': "الإبقاء على الشاشة قيد التشغيل دائمًا",
        'timeout': "مهلة الخمول (بالدقائق):",
        'msg_on': "✅ الشاشة تعمل دائمًا\nتم تعطيل DPMS.",
        'msg_off': "⏱ سيتم الإيقاف بعد %d دقيقة",
        'btn_apply': "تطبيق",
        'btn_cancel': "إلغاء",
        'status_on': "مُفعل - لن تُطفأ الشاشة أبدًا",
        'status_off': "معطل - ستُطفأ خلال %d دقيقة",
        'activate_btn': "تفعيل الآن",
        'deactivate_btn': "تعطيل الآن"
    },
    'ca': {
        'title': "Control de Pantalla",
        'header': "Estat Actual: %s",
        'text': "Configura el comportament de la pantalla:",
        'keep_on': "Mantenir la pantalla sempre encesa",
        'timeout': "Temps d'inactivitat (minuts):",
        'msg_on': "✅ Pantalla sempre encesa\nDPMS desactivat.",
        'msg_off': "⏱ Apagat després de %d minuts",
        'btn_apply': "Aplica",
        'btn_cancel': "Cancel·la",
        'status_on': "ACTIVAT - La pantalla no s'apagarà mai",
        'status_off': "DESACTIVAT - S'apagarà en %d min",
        'activate_btn': "Activa ara",
        'deactivate_btn': "Desactiva ara"
    },
    'hu': {
        'title': "Képernyővezérlés",
        'header': "Jelenlegi állapot: %s",
        'text': "Állítsa be a képernyő viselkedését:",
        'keep_on': "Képernyő mindig bekapcsolva",
        'timeout': "Tétlenségi idő (perc):",
        'msg_on': "✅ A képernyő mindig be van kapcsolva\nDPMS letiltva.",
        'msg_off': "⏱ Kikapcsol %d perc után",
        'btn_apply': "Alkalmaz",
        'btn_cancel': "Mégse",
        'status_on': "ENGEDÉLYEZVE - A képernyő soha nem kapcsol ki",
        'status_off': "LETILTVA - Kikapcsol %d perc múlva",
        'activate_btn': "Bekapcsolás most",
        'deactivate_btn': "Kikapcsolás most"
    },
    'ja': {
        'title': "画面コントロール",
        'header': "現在の状態: %s",
        'text': "画面の動作を設定してください:",
        'keep_on': "画面を常にオンにする",
        'timeout': "アイドルタイムアウト（分）:",
        'msg_on': "✅ 画面は常にオン\nDPMSは無効です。",
        'msg_off': "⏱ %d分後にオフになります",
        'btn_apply': "適用",
        'btn_cancel': "キャンセル",
        'status_on': "有効 - 画面は常にオン",
        'status_off': "無効 - %d分後にオフ",
        'activate_btn': "今すぐ有効化",
        'deactivate_btn': "今すぐ無効化"
    },
    'zh': {
        'title': "屏幕控制",
        'header': "当前状态：%s",
        'text': "配置屏幕行为：",
        'keep_on': "始终保持屏幕开启",
        'timeout': "闲置超时（分钟）：",
        'msg_on': "✅ 屏幕始终开启\nDPMS 已禁用。",
        'msg_off': "⏱ %d 分钟后关闭",
        'btn_apply': "应用",
        'btn_cancel': "取消",
        'status_on': "已启用 - 屏幕不会关闭",
        'status_off': "已禁用 - %d 分钟后关闭",
        'activate_btn': "立即启用",
        'deactivate_btn': "立即禁用"
    },
    'default': {
        'title': "Screen Control",
        'header': "Current Status: %s",
        'text': "Configure screen behavior:",
        'keep_on': "Keep screen always on",
        'timeout': "Inactivity timeout (minutes):",
        'msg_on': "✅ Screen always on\nDPMS disabled.",
        'msg_off': "⏱ Turns off after %d minutes",
        'btn_apply': "Apply",
        'btn_cancel': "Cancel",
        'status_on': "ENABLED - Screen never turns off",
        'status_off': "DISABLED - Turns off in %d min",
        'activate_btn': "Activate now",
        'deactivate_btn': "Deactivate now"
    }
}

# Seleccionar idioma
strings = LANGUAGE_STRINGS.get(lang_code, LANGUAGE_STRINGS['default'])


def load_config():
    config = configparser.ConfigParser()
    keep_on = False
    timeout = 5

    if os.path.exists(CONFIG_FILE):
        try:
            config.read(CONFIG_FILE)
            keep_on = config.getboolean('Settings', 'KEEP_SCREEN_ON', fallback=False)
            timeout = config.getint('Settings', 'SCREEN_TIMEOUT', fallback=5)
        except (configparser.Error, ValueError) as e:
            print(f"Error reading config: {e}. Using default values.")
    return keep_on, timeout

def save_config(keep_on, timeout):
    config = configparser.ConfigParser()
    config['Settings'] = {
        'KEEP_SCREEN_ON': 'TRUE' if keep_on else 'FALSE',
        'SCREEN_TIMEOUT': str(timeout)
    }
    with open(CONFIG_FILE, 'w') as configfile:
        config.write(configfile)

def apply_screen_settings(keep_on, timeout):
    if keep_on:
        subprocess.run(['xset', 's', 'off'])
        subprocess.run(['xset', '-dpms'])
        show_notification(strings['title'], strings['msg_on'])
    else:
        timeout_seconds = timeout * 60
        subprocess.run(['xset', 's', 'on'])
        subprocess.run(['xset', '+dpms'])
        subprocess.run(['xset', 's', str(timeout_seconds), str(timeout_seconds)])
        show_notification(strings['title'], strings['msg_off'] % timeout)

def show_notification(title, message):
    icon_option = ['-i', ICON_FILE] if os.path.exists(ICON_FILE) else []
    subprocess.run(['notify-send', title, message] + icon_option)

def get_status_text(keep_on, timeout):
    if keep_on:
        return strings['status_on']
    else:
        return strings['status_off'] % timeout

def copy_autostart_file():
    """Copia el archivo .desktop al directorio de autostart si no existe"""
    if not os.path.exists(AUTOSTART_FILE) and os.path.exists(DESKTOP_FILE_SOURCE):
        try:
            shutil.copy(DESKTOP_FILE_SOURCE, AUTOSTART_FILE)
            print(f"Archivo de inicio automático copiado a: {AUTOSTART_FILE}")
        except PermissionError:
            try:
                subprocess.run(['sudo', 'cp', DESKTOP_FILE_SOURCE, AUTOSTART_FILE], check=True)
                print(f"Archivo copiado usando sudo: {AUTOSTART_FILE}")
            except subprocess.CalledProcessError as e:
                print(f"Error al copiar con sudo: {e}")
                messagebox.showerror(
                    strings['title'],
                    "Error: Se requieren permisos de administrador para copiar el archivo de inicio automático.\n"
                    f"Por favor copia manualmente:\n{DESKTOP_FILE_SOURCE}\na:\n{AUTOSTART_FILE}"
                )
        except Exception as e:
            print(f"Error al copiar archivo: {e}")
            messagebox.showerror(
                strings['title'],
                f"Error al copiar el archivo de inicio automático: {e}"
            )

def apply_changes():
    new_keep_on = keep_on_var.get()
    new_timeout = timeout_var.get()
    
    save_config(new_keep_on, new_timeout)
    apply_screen_settings(new_keep_on, new_timeout)
    
    copy_autostart_file()
    
    status_text = get_status_text(new_keep_on, new_timeout)
    header_text.set(strings['header'] % status_text)
    status_label.config(text=header_text.get())

root = Tk()
root.title(strings['title'])
root.resizable(False, False)

if os.path.exists(ICON_FILE):
    root.iconphoto(True, PhotoImage(file=ICON_FILE))

keep_on, timeout_val = load_config()
keep_on_var = BooleanVar(value=keep_on)
timeout_var = IntVar(value=timeout_val)
header_text = StringVar()

initial_status = get_status_text(keep_on, timeout_val)
header_text.set(strings['header'] % initial_status)

mainframe = ttk.Frame(root, padding="20")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

def center_window():
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'+{x}+{y}')

# Icono en la interfaz (60x60)
icon_frame = ttk.Frame(mainframe)
icon_frame.grid(column=0, row=0, columnspan=3, sticky=N, pady=(0, 10))

if os.path.exists(ICON_FILE):
    try:
        img = Image.open(ICON_FILE)
        img = img.resize((60, 60), Image.LANCZOS)
        icon_img = ImageTk.PhotoImage(img)
        icon_label = Label(icon_frame, image=icon_img)
        icon_label.image = icon_img  # Guardar referencia
        icon_label.pack(side=TOP)
    except Exception as e:
        print(f"Error loading icon: {e}")
else:
    Label(icon_frame, text="", height=3).pack(side=TOP)

# Encabezado
ttk.Label(mainframe, textvariable=header_text, font=("Arial", 12, "bold")).grid(
    column=0, row=1, columnspan=3, pady=(0, 15), sticky=N)

# Texto 
ttk.Label(mainframe, text=strings['text']).grid(
    column=0, row=2, columnspan=3, sticky=W, pady=(0, 10))

keep_on_check = ttk.Checkbutton(
    mainframe, 
    text=strings['keep_on'], 
    variable=keep_on_var,
    command=lambda: timeout_entry.configure(state=DISABLED if keep_on_var.get() else NORMAL)
)
keep_on_check.grid(column=0, row=3, columnspan=3, sticky=W, pady=(0, 10))

ttk.Label(mainframe, text=strings['timeout']).grid(
    column=0, row=4, sticky=W, pady=(0, 10))

timeout_entry = ttk.Spinbox(
    mainframe, 
    from_=1, 
    to=120, 
    textvariable=timeout_var,
    width=5,
    state=DISABLED if keep_on_var.get() else NORMAL
)
timeout_entry.grid(column=1, row=4, sticky=W, padx=(5, 0), pady=(0, 10))


button_frame = ttk.Frame(mainframe)
button_frame.grid(column=0, row=5, columnspan=3, sticky=E, pady=(15, 0))

apply_btn = ttk.Button(
    button_frame, 
    text=strings['btn_apply'], 
    command=apply_changes
)
apply_btn.pack(side=RIGHT, padx=(5, 0))

cancel_btn = ttk.Button(
    button_frame, 
    text=strings['btn_cancel'], 
    command=root.destroy
)
cancel_btn.pack(side=RIGHT)


status_frame = ttk.Frame(mainframe)
status_frame.grid(column=0, row=6, columnspan=3, pady=(15, 0), sticky=W)

status_label = ttk.Label(
    status_frame, 
    textvariable=header_text,
    font=("Arial", 10),
    foreground="blue"
)
status_label.pack(side=TOP, anchor=W)


action_frame = ttk.Frame(mainframe)
action_frame.grid(column=0, row=7, columnspan=3, sticky=W, pady=(10, 0))

activate_btn = ttk.Button(
    action_frame,
    text=strings['activate_btn'],
    command=lambda: [keep_on_var.set(True), apply_changes()]
)
activate_btn.pack(side=LEFT)

deactivate_btn = ttk.Button(
    action_frame,
    text=strings['deactivate_btn'],
    command=lambda: [keep_on_var.set(False), apply_changes()]
)
deactivate_btn.pack(side=LEFT, padx=(5, 0))


def update_timeout_state():
    timeout_entry.configure(state=DISABLED if keep_on_var.get() else NORMAL)

keep_on_var.trace_add('write', lambda *_: update_timeout_state())


center_window()
root.after(100, center_window)  


root.mainloop()
