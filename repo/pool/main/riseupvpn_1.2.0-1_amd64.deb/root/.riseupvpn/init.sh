#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -e
BASE="/root/.riseupvpn"
mkdir -p "$BASE"
chmod 700 "$BASE"
echo 'first_run="false"' > "$BASE/first_run"
chmod 700 "$BASE"
