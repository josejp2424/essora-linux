#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
BASE="/root/.riseupvpn"

"$BASE/select_server.sh" || exit 1

"$BASE/ensure_creds.sh" --force

"$BASE/disconnect.sh" || true
exec /usr/local/riseupvpn/riseupvpn
