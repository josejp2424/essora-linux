#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
BASE="/root/.riseupvpn"
CA="$BASE/ca_bundle.pem"
CLIENT="$BASE/client.pem"
REMOTES_FILE="$BASE/remotes.list"
SELECTED_FILE="$BASE/remotes.selected"
OVPN_FILE="$BASE/riseup_configuration.ovpn"

force=0
if [[ "${1:-}" == "--force" ]]; then
  force=1
fi

download_ca() {
  mkdir -p "$BASE"
  chmod 700 "$BASE"
  echo "[+] Descargando CA (LEAP Root CA)"
  if curl -fsSL -o "$CA" https://black.riseup.net/ca.crt; then
    echo "[OK] CA desde black.riseup.net"
    return 0
  fi
  if curl -fsSL -o "$CA" https://riseup.net/security/network-security/riseup-ca/RiseupCA.pem; then
    echo "[OK] CA desde riseup.net"
    return 0
  fi
  echo "ERROR: No pude descargar una CA valida" >&2
  return 1
}

download_cert() {
  echo "[+] Obteniendo certificado de cliente..."
  curl -fsSL --cacert "$CA" -o "$CLIENT" https://api.black.riseup.net/3/cert
  chmod 600 "$CLIENT"
}

build_ovpn() {
  echo "[+] Generando config OVPN"
  cat >"$OVPN_FILE" <<'EOF'
client
dev tun
nobind
persist-key
persist-tun
verb 3
auth-nocache
resolv-retry infinite
remote-cert-tls server
setenv CLIENT_CERT 0
verify-x509-name vpn name-prefix
data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305
auth SHA256
redirect-gateway def1
EOF

  SRC="$REMOTES_FILE"
  if [[ -s "$SELECTED_FILE" ]]; then SRC="$SELECTED_FILE"; fi


  while read -r host rest; do
    [[ -z "$host" ]] && continue
    [[ "$host" =~ ^# ]] && continue
    for proto in udp udp udp tcp-client tcp-client tcp-client tcp-client; do
      case "$proto" in
        udp) ports="1194 80 53" ;;
        tcp-client) ports="443 1194 80 53" ;;
      esac
      for port in $ports; do
        cat >>"$OVPN_FILE" <<EOF

<connection>
remote $host $port
proto $proto
</connection>
EOF
      done
    done
  done < "$SRC"

  cat >>"$OVPN_FILE" <<EOF

ca $BASE/ca_bundle.pem
cert $BASE/client.pem
key $BASE/client.pem
EOF
}

mkdir -p "$BASE"
chmod 700 "$BASE"


if [[ ! -s "$REMOTES_FILE" ]]; then
  cp -f "$BASE/remotes.catalog" "$REMOTES_FILE" || true

  awk -F',' 'NR>1 {print $4}' "$BASE/remotes.catalog" | sed '/^$/d' > "$REMOTES_FILE" || true
fi

if [[ ! -s "$CA" ]]; then
  download_ca || { echo "ERROR: No pude descargar CA"; exit 1; }
fi

if [[ $force -eq 1 && -f "$CLIENT" ]]; then
  rm -f "$CLIENT"
fi
if [[ ! -s "$CLIENT" ]]; then
  download_cert || { echo "ERROR: No pude obtener client.pem"; exit 1; }
fi

build_ovpn
echo "[OK] Credenciales y config listas."
