#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
BASE="/root/.riseupvpn"
OVPN="$BASE/riseup_configuration.ovpn"
PID_OVPN="$BASE/openvpn.pid"
PID_YAD="$BASE/yad.pid"

# Kill OpenVPN by PID if present
if [[ -f "$PID_OVPN" ]]; then
  OVPN_PID=$(cat "$PID_OVPN" 2>/dev/null || echo "")
  if [[ -n "$OVPN_PID" ]] && kill -0 "$OVPN_PID" 2>/dev/null; then
    kill "$OVPN_PID" || true
    sleep 1
    kill -9 "$OVPN_PID" 2>/dev/null || true
  fi
  rm -f "$PID_OVPN"
fi

# Fallback: kill any openvpn processes
pkill -f "openvpn --config $OVPN" 2>/dev/null || true
pkill -x openvpn 2>/dev/null || true

# Bring down and delete tun interfaces
for IFACE in $(ip -o link show | awk -F': ' '/^ *[0-9]+: tun[0-9]+/ {print $2}'); do
  ip link set "$IFACE" down 2>/dev/null || true
  ip link delete "$IFACE" 2>/dev/null || true
done

# Flush common policy routing table if used
ip route flush table 128 2>/dev/null || true

# Kill any Yad tray
pkill -f "yad --notification" 2>/dev/null || true
if [[ -f "$PID_YAD" ]]; then
  YAD_PID=$(cat "$PID_YAD" 2>/dev/null || echo "")
  if [[ -n "$YAD_PID" ]] && kill -0 "$YAD_PID" 2>/dev/null; then
    kill "$YAD_PID" || true
    sleep 1
    kill -9 "$YAD_PID" 2>/dev/null || true
  fi
  rm -f "$PID_YAD"
fi

exit 0
