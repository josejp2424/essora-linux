#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
APP="/usr/local/riseupvpn"
source "$APP/i18n.sh"
load_locale
IP=$(curl -s ifconfig.me || echo "N/A")
yad --center --image="/usr/local/riseupvpn/riseup.png" --title="$T_TITLE_IP" --text="$T_IP_PREFIX <b>$IP</b>" --button="$T_BTN_CLOSE:0"
