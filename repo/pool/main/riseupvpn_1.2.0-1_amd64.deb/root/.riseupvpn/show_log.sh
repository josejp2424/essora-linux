#!/usr/bin/env bash
#autor josejp2424 para essora Eos
set -euo pipefail
APP="/usr/local/riseupvpn"
source "$APP/i18n.sh"
load_locale
LOG="/tmp/riseupvpn.log"
touch "$LOG"
yad --width=860 --height=420 --window-icon="/usr/local/riseupvpn/vpn.png" --center --title="$T_TITLE_LOG" --text-info --filename="$LOG" --justify="left" --button="$T_BTN_CLOSE:0"
