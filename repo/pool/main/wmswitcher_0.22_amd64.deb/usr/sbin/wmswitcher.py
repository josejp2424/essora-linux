#!/usr/bin/env python3
# WM Switcher for SLiM — 2025-08-08
# Autor: josejp2424
#version 0.22
#
# MIT License
#
# Copyright (c) 2025 josejp2424
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import os, pwd, getpass, shutil, subprocess, tkinter as tk
from tkinter import ttk, messagebox, PhotoImage

# --- Translations based on LANG ---
def get_translations():
    lang = os.getenv("LANG", "en").split('.')[0]
    
    translations = {
        'en': {
            'title': "WM Switcher (SLiM)",
            'error_root': "Run as root (sudo).",
            'error_user': "Could not detect graphical user.",
            'error_wms': "No installed WMs detected.",
            'current': "User: {} | Current WM: {}",
            'select': "Select WM (will be written exactly in ~/.xsession)",
            'dmrc': "Also update ~/.dmrc (optional, not needed for SLiM)",
            'apply': "Apply",
            'error_write': "Could not write:\n{}",
            'success': "Changes saved successfully!\nNew WM: {}",
            'restart_title': "Restart required",
            'restart_msg': "You need to restart for changes to take effect.",
            'restart_now': "Restart Now",
            'restart_later': "Restart Later",
            'restart_warn': "WARNING: The system will restart.\nClose all your applications."
        },
        'es': {
            'title': "Selector de WM (SLiM)",
            'error_root': "Ejecuta como root (sudo).",
            'error_user': "No se detectó el usuario gráfico.",
            'error_wms': "No se detectaron WMs instalados.",
            'current': "Usuario: {} | WM actual: {}",
            'select': "Seleccione WM (se escribirá tal cual en ~/.xsession)",
            'dmrc': "También actualizar ~/.dmrc (opcional, no necesario para SLiM)",
            'apply': "Aplicar",
            'error_write': "No se pudo escribir:\n{}",
            'success': "¡Cambios guardados correctamente!\nNuevo WM: {}",
            'restart_title': "Reinicio requerido",
            'restart_msg': "Necesitas reiniciar para que los cambios surtan efecto.",
            'restart_now': "Reiniciar Ahora",
            'restart_later': "Reiniciar Más Tarde",
            'restart_warn': "ADVERTENCIA: El sistema se reiniciará.\nCierre todas sus aplicaciones."
        },
        'fr': {
            'title': "Sélecteur de WM (SLiM)",
            'error_root': "Exécutez en tant que root (sudo).",
            'error_user': "Impossible de détecter l'utilisateur graphique.",
            'error_wms': "Aucun WM installé détecté.",
            'current': "Utilisateur: {} | WM actuel: {}",
            'select': "Sélectionnez WM (sera écrit tel quel dans ~/.xsession)",
            'dmrc': "Mettre aussi à jour ~/.dmrc (optionnel, pas nécessaire pour SLiM)",
            'apply': "Appliquer",
            'error_write': "Impossible d'écrire:\n{}",
            'success': "Modifications enregistrées avec succès !\nNouveau WM: {}",
            'restart_title': "Redémarrage requis",
            'restart_msg': "Vous devez redémarrer pour que les modifications prennent effet.",
            'restart_now': "Redémarrer Maintenant",
            'restart_later': "Redémarrer Plus Tard",
            'restart_warn': "ATTENTION : Le système va redémarrer.\nFermez toutes vos applications."
        },
        'de': {
            'title': "WM Auswahl (SLiM)",
            'error_root': "Als root ausführen (sudo).",
            'error_user': "Konnte grafischen Benutzer nicht erkennen.",
            'error_wms': "Keine installierten WMs gefunden.",
            'current': "Benutzer: {} | Aktuelles WM: {}",
            'select': "WM auswählen (wird genau so in ~/.xsession geschrieben)",
            'dmrc': "Auch ~/.dmrc aktualisieren (optional, nicht benötigt für SLiM)",
            'apply': "Anwenden",
            'error_write': "Konnte nicht schreiben:\n{}",
            'success': "Änderungen erfolgreich gespeichert!\nNeues WM: {}",
            'restart_title': "Neustart erforderlich",
            'restart_msg': "Sie müssen neu starten, damit die Änderungen wirksam werden.",
            'restart_now': "Jetzt neu starten",
            'restart_later': "Später neu starten",
            'restart_warn': "WARNUNG: Das System wird neu gestartet.\nSchließen Sie alle Anwendungen."
        },
        'it': {
            'title': "Selettore WM (SLiM)",
            'error_root': "Esegui come root (sudo).",
            'error_user': "Impossibile rilevare l'utente grafico.",
            'error_wms': "Nessun WM installato rilevato.",
            'current': "Utente: {} | WM attuale: {}",
            'select': "Seleziona WM (verrà scritto esattamente in ~/.xsession)",
            'dmrc': "Aggiorna anche ~/.dmrc (opzionale, non necessario per SLiM)",
            'apply': "Applica",
            'error_write': "Impossibile scrivere:\n{}",
            'success': "Modifiche salvate con successo!\nNuovo WM: {}",
            'restart_title': "Riavvio richiesto",
            'restart_msg': "È necessario riavviare per applicare le modifiche.",
            'restart_now': "Riavvia Ora",
            'restart_later': "Riavvia Più Tardi",
            'restart_warn': "ATTENZIONE: Il sistema verrà riavviato.\nChiudi tutte le applicazioni."
        },
        'pt': {
            'title': "Seletor de WM (SLiM)",
            'error_root': "Execute como root (sudo).",
            'error_user': "Não foi possível detectar o usuário gráfico.",
            'error_wms': "Nenhum WM instalado detectado.",
            'current': "Usuário: {} | WM atual: {}",
            'select': "Selecione WM (será escrito exatamente em ~/.xsession)",
            'dmrc': "Atualizar também ~/.dmrc (opcional, não necessário para SLiM)",
            'apply': "Aplicar",
            'error_write': "Não foi possível escrever:\n{}",
            'success': "Alterações salvas com sucesso!\nNovo WM: {}",
            'restart_title': "Reinicialização necessária",
            'restart_msg': "Você precisa reiniciar para que as alterações tenham efeito.",
            'restart_now': "Reiniciar Agora",
            'restart_later': "Reiniciar Mais Tarde",
            'restart_warn': "AVISO: O sistema será reiniciado.\nFeche todos os aplicativos."
        },
        'ru': {
            'title': "Переключатель WM (SLiM)",
            'error_root': "Запустите от root (sudo).",
            'error_user': "Не удалось определить графического пользователя.",
            'error_wms': "Не обнаружено установленных WM.",
            'current': "Пользователь: {} | Текущий WM: {}",
            'select': "Выберите WM (будет записано точно в ~/.xsession)",
            'dmrc': "Также обновить ~/.dmrc (опционально, не нужно для SLiM)",
            'apply': "Применить",
            'error_write': "Не удалось записать:\n{}",
            'success': "Изменения успешно сохранены!\nНовый WM: {}",
            'restart_title': "Требуется перезагрузка",
            'restart_msg': "Вам необходимо перезагрузиться, чтобы изменения вступили в силу.",
            'restart_now': "Перезагрузить Сейчас",
            'restart_later': "Перезагрузить Позже",
            'restart_warn': "ПРЕДУПРЕЖДЕНИЕ: Система будет перезагружена.\nЗакройте все приложения."
        },
        'ja': {
            'title': "WM スイッチャー (SLiM)",
            'error_root': "root で実行してください (sudo)。",
            'error_user': "グラフィカルユーザーを検出できませんでした。",
            'error_wms': "インストールされた WM が検出されませんでした。",
            'current': "ユーザー: {} | 現在の WM: {}",
            'select': "WM を選択 (~/.xsession に正確に書き込まれます)",
            'dmrc': "~/.dmrc も更新 (オプション、SLiM には不要)",
            'apply': "適用",
            'error_write': "書き込みできませんでした:\n{}",
            'success': "変更が正常に保存されました！\n新しい WM: {}",
            'restart_title': "再起動が必要です",
            'restart_msg': "変更を有効にするには再起動が必要です。",
            'restart_now': "今すぐ再起動",
            'restart_later': "後で再起動",
            'restart_warn': "警告: システムが再起動します。\nすべてのアプリケーションを閉じてください。"
        },
        'zh': {
            'title': "窗口管理器切换器 (SLiM)",
            'error_root': "请以 root 权限运行 (sudo)。",
            'error_user': "无法检测到图形用户。",
            'error_wms': "未检测到已安装的窗口管理器。",
            'current': "用户: {} | 当前 WM: {}",
            'select': "选择窗口管理器 (将直接写入 ~/.xsession)",
            'dmrc': "同时更新 ~/.dmrc (可选，SLiM 不需要)",
            'apply': "应用",
            'error_write': "无法写入:\n{}",
            'success': "更改已成功保存！\n新 WM: {}",
            'restart_title': "需要重启",
            'restart_msg': "您需要重启以使更改生效。",
            'restart_now': "立即重启",
            'restart_later': "稍后重启",
            'restart_warn': "警告: 系统将重新启动。\n请关闭所有应用程序。"
        }
    }

    for prefix in translations:
        if lang.startswith(prefix):
            return translations[prefix]
    return translations['en']

TR = get_translations()

# Key: EXACT string that goes in ~/.xsession
# Value: (icon, real executable for detection, optional .dmrc name)
WMS = {
    "openbox-session": ("openbox.png", "openbox", "openbox"),
    "mate-session"   : ("mate.png", "mate-session", "mate"),
    "startxfce4"     : ("xfce4_xicon3.png", "startxfce4", "xfce"),
    "startfluxbox"   : ("fluxbox.png", "fluxbox", "fluxbox"),
    "jwm"            : ("jwm.png", "jwm", "jwm"),
    "icewm-session"  : ("icewm-logo.png", "icewm-session", "icewm"),
    "startlxde"      : ("lxde.png", "lxsession", "LXDE"),
    "bspwm"          : ("bspwm_logo.png", "bspwm", "bspwm"),
    "dwm"            : ("dwm_logo.png", "dwm", "dwm"),
    "startkde"       : ("kde.png", "plasmashell", "plasma"),
    "Hyprland"       : ("hyprland.png", "Hyprland", "Hyprland"),
}

IMGDIR = "/usr/share/pixmaps/wmswitcher"
APP_ICON = "/usr/share/pixmaps/wmswitcher/wmswitcher.png"

def run(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def which(p): return shutil.which(p)

def detect_display_user():
    su = os.getenv("SUDO_USER")
    if su and su != "root": return su
    for p in ("Xorg","X","Xwayland"):
        r = run(["bash","-lc", f"ps -o user= -p $(pidof {p} 2>/dev/null) | head -n1"])
        u = r.stdout.strip()
        if u and u!="root": return u
    if which("loginctl"):
        r = run(["bash","-lc","loginctl list-sessions --no-legend | awk '{print $3}' | head -n1"])
        u = r.stdout.strip()
        if u and u!="root": return u
    cu = getpass.getuser()
    if cu!="root": return cu
    r = run(["bash","-lc","users"])
    for u in r.stdout.split():
        if u!="root": return u
    return None

def get_home(user): return pwd.getpwnam(user).pw_dir
def chown_user(path, user):
    info = pwd.getpwnam(user); os.chown(path, info.pw_uid, info.pw_gid)

def read_xsession(path):
    if not os.path.exists(path): return None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"): continue
            s = s.replace("exec ", "", 1).strip()
            return s
    return None

def write_xsession_plain(user, wm_key):
    home = get_home(user)
    path = os.path.join(home, ".xsession")
    os.makedirs(home, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{wm_key}\n")  
    chown_user(path, user)
    return path

def maybe_write_dmrc(user, wm_key):
    session = WMS.get(wm_key, (None,None,wm_key))[2]
    if not session: return
    home = get_home(user); dmrc = os.path.join(home, ".dmrc")
    with open(dmrc, "w", encoding="utf-8") as f:
        f.write("[Desktop]\n")
        f.write(f"Session={session}\n")
    chown_user(dmrc, user)

def available_wms():
    found=[]
    for wm_key,(icon,exe,_s) in WMS.items():
        if which(exe) or which(wm_key):
            found.append(wm_key)
    return sorted(found)

class App:
    def __init__(self, root):
        self.root = root
        self.root.title(TR['title'])
        self.root.resizable(False, False)
        
        if os.path.exists(APP_ICON):
            try:
                self.root.iconphoto(True, PhotoImage(file=APP_ICON))
            except Exception as e:
                print(f"Could not load icon: {e}")
        

        self.center_window()
        
        if os.geteuid()!=0:
            messagebox.showerror("Error", TR['error_root'])
            root.destroy(); return

        self.user = detect_display_user()
        if not self.user or self.user=="root":
            messagebox.showerror("Error", TR['error_user'])
            root.destroy(); return

        self.home = get_home(self.user)
        self.xsession = os.path.join(self.home, ".xsession")
        if not os.path.exists(self.xsession):
            open(self.xsession,"a").close(); chown_user(self.xsession, self.user)

        self.current = read_xsession(self.xsession) or "(unknown)"
        self.wms = available_wms()
        if not self.wms:
            messagebox.showerror("Error", TR['error_wms']); root.destroy(); return

        self.build()

    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'+{x}+{y}')

    def build(self):
        main = ttk.Frame(self.root, padding=10); main.pack(fill=tk.BOTH, expand=True)
        

        if os.path.exists(APP_ICON):
            try:
                img = PhotoImage(file=APP_ICON).subsample(2)
                icon_label = ttk.Label(main, image=img)
                icon_label.image = img  
                icon_label.pack(pady=(0, 10))
            except Exception as e:
                print(f"Could not load icon for GUI: {e}")

        ttk.Label(main, text=TR['current'].format(self.user, self.current)).pack(anchor="w", pady=(0,6))

        lf = ttk.LabelFrame(main, text=TR['select']); lf.pack(fill=tk.BOTH, pady=6)
        self.var = tk.StringVar(value=self.current if self.current in self.wms else self.wms[0])


        container = ttk.Frame(lf)
        container.pack(fill=tk.BOTH, expand=True)


        max_width = max(len(wm) for wm in self.wms)
        
        for wm in self.wms:
            row = ttk.Frame(container)
            row.pack(fill=tk.X, pady=2)
            

            rb = ttk.Radiobutton(row, text=wm, variable=self.var, value=wm)
            rb.pack(side=tk.LEFT, anchor="w")
            

            ttk.Label(row, width=max_width-len(wm)).pack(side=tk.LEFT)
            
            
            icon = os.path.join(IMGDIR, WMS[wm][0])
            if os.path.exists(icon):
                try:
                    img = PhotoImage(file=icon).subsample(2)
                    lbl = ttk.Label(row, image=img)
                    lbl.image = img
                    lbl.pack(side=tk.RIGHT, padx=5)
                except Exception as e:
                    print(f"Could not load icon {icon}: {e}")

        self.chk_dmrc = tk.BooleanVar(value=False)
        ttk.Checkbutton(main, text=TR['dmrc'], variable=self.chk_dmrc).pack(anchor="w", pady=(6,0))

        ttk.Button(main, text=TR['apply'], command=self.apply).pack(pady=10, ipadx=12, ipady=4)

    def apply(self):
        wm = self.var.get()
        try:
            path = write_xsession_plain(self.user, wm)
            if self.chk_dmrc.get():
                maybe_write_dmrc(self.user, wm)
        except Exception as e:
            messagebox.showerror("Error", TR['error_write'].format(e)); return
        
        # Show success message and restart dialog
        self.show_restart_dialog(wm)

    def show_restart_dialog(self, wm):
        """Show the restart dialog with options"""
        # Create custom dialog
        dialog = tk.Toplevel(self.root)
        dialog.title(TR['restart_title'])
        dialog.transient(self.root)
        dialog.resizable(False, False)
        
        # Center dialog
        dialog.update_idletasks()
        width = dialog.winfo_width()
        height = dialog.winfo_height()
        x = (dialog.winfo_screenwidth() // 2) - (width // 2)
        y = (dialog.winfo_screenheight() // 2) - (height // 2)
        dialog.geometry(f'+{x}+{y}')
        
        # Add content
        main = ttk.Frame(dialog, padding=10)
        main.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main, text=TR['success'].format(wm)).pack(pady=(0, 10))
        ttk.Label(main, text=TR['restart_msg']).pack(pady=(0, 15))
        
        btn_frame = ttk.Frame(main)
        btn_frame.pack()
        
        def restart_now():
            messagebox.showwarning(TR['restart_title'], TR['restart_warn'])
            try:
                run(["systemctl", "reboot"])
            except Exception as e:
                messagebox.showerror("Error", f"Could not restart: {e}")
            dialog.destroy()
            self.root.destroy()
        
        ttk.Button(btn_frame, text=TR['restart_now'], command=restart_now).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text=TR['restart_later'], command=dialog.destroy).pack(side=tk.LEFT, padx=5)
        
        dialog.grab_set()
        dialog.wait_window()

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
